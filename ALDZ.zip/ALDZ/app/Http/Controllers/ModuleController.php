<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\View\View;
class ModuleController extends Controller
{
    private const MODULES = [
        'aktivite' => ['title'=>'Aktivite Arkadaşı','description'=>'Koşu, kahve, yürüyüş ve ortak ilgi alanları için buluşmalar.','icon'=>'✦'],
        'ev-arkadasi' => ['title'=>'Ev Arkadaşı','description'=>'Emlak ilanı değil; yaşam tarzı ve gider paylaşımı uyumu.','icon'=>'⌂'],
        'ucretsiz-esya' => ['title'=>'Ücretsiz Eşya','description'=>'Kullanmadığın eşyaları ücretsiz paylaş. Satış ve ücret talebi yasaktır.','icon'=>'♡'],
        'deneyim' => ['title'=>'Deneyim Topluluğu','description'=>'Sorular, gerçek yaşam deneyimleri ve topluluk yanıtları.','icon'=>'☷'],
        'etkinlikler' => ['title'=>'Etkinlikler','description'=>'Birlikte plan yap, katılımı yönet ve etkinlik grubunda buluş.','icon'=>'◎'],
        'yaratici-kose' => ['title'=>'Yaratıcı Köşe','description'=>'Hikâye, şiir, fikir ve karşılıklı onaylı ortak üretim.','icon'=>'✎'],
        'seyahat' => ['title'=>'Şehir ve Seyahat','description'=>'Benzer tarihlerde aynı destinasyona giden insanları keşfet.','icon'=>'↗'],
    ];
    public function show(Request $request, string $module): View
    {
        abort_unless(isset(self::MODULES[$module]), 404);
        return view('modules.show', ['moduleKey'=>$module, 'module'=>self::MODULES[$module]]);
    }
}
