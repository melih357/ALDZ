<?php
namespace App\Http\Controllers;
abstract class Controller
{
    // Modül denetleyicileri burada ortak davranışlar için genişletilir.
}
