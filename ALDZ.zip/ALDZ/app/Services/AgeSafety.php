<?php
namespace App\Services;
use App\Models\User;
use Illuminate\Auth\Access\AuthorizationException;
/** Central rule: users in different age bands must not discover or contact one another. */
final class AgeSafety
{
    public function canInteract(User $actor, User $target): bool
    {
        return $actor->status === 'active' && $target->status === 'active'
            && $actor->age_band === $target->age_band
            && !$actor->blocks()->where('blocked_id', $target->id)->exists()
            && !$target->blocks()->where('blocked_id', $actor->id)->exists();
    }
    public function assertCanInteract(User $actor, User $target): void
    {
        if (!$this->canInteract($actor, $target)) {
            throw new AuthorizationException('Bu kullanıcıyla iletişim kurulamıyor.');
        }
    }
}
