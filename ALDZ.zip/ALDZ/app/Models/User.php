<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
class User extends Authenticatable
{
    use HasFactory, Notifiable;
    protected $fillable = ['name','username','email','password','birth_date','age_band','gender','status'];
    protected $hidden = ['password','remember_token','two_factor_secret','two_factor_recovery_codes'];
    protected function casts(): array { return ['email_verified_at'=>'datetime','birth_date'=>'date','password'=>'hashed','two_factor_confirmed_at'=>'datetime']; }
    public function profile() { return $this->hasOne(Profile::class); }
    public function blocks() { return $this->hasMany(UserBlock::class, 'blocker_id'); }
    public function hasAdultBand(): bool { return $this->age_band === 'adult'; }
}
