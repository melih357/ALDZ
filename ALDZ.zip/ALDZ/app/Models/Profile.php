<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Profile extends Model { protected $primaryKey='user_id'; public $incrementing=false; protected $fillable=['user_id','bio','city','avatar_path','visibility','preferences']; protected function casts(): array { return ['preferences'=>'array']; } public function user(){ return $this->belongsTo(User::class); } }
