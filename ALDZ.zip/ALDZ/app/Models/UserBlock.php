<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class UserBlock extends Model { protected $table='user_blocks'; public $timestamps=false; protected $fillable=['blocker_id','blocked_id','created_at']; }
