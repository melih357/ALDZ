# ALDZ V7 — Değişiklikler ve sınırlar

## Uygulananlar
- 13 yaş kayıt alt sınırı ve topluluk kuralları güncellendi.
- 13–17 ve 18+ hesaplar arasında profil, keşif, takip ve mesaj erişimi sınırlandırıldı.
- Etkinlik oluşturma ve katılma sunucu tarafında aynı yaş grubuna bağlandı.
- Etkinlik organizatörü bekleyen katılımları onaylayabilir/reddedebilir, etkinliği iptal edebilir.
- Etkinlik formu daraltılabilir; mobil için küçük ekran stilleri eklendi.
- Doğrudan mesajlar veritabanındaki conversations/messages tablolarına kaydediliyor.
- Yalnızca kabul edilmiş takip bağlantıları sohbet başlatabiliyor.
- Bildirim listesi ve tümünü okundu işaretleme işlevi eklendi.
- Önceden örnek olarak görünen sahte etkileşim sayaçları ve demo sohbetler kaldırıldı.
- Yeniden kullanılabilir navigasyon ve dinamik geri dönüş iyileştirildi.
- Service Worker yalnızca belirlenen statik dosyaları önbelleğe alır.

## Henüz eksik / test edilmemiş
- WAMP ve gerçek MySQL üzerinde uçtan uca tarayıcı testleri bu ortamda yapılmadı.
- Yaş doğrulaması yalnızca beyan edilen doğum tarihine dayanır; 13+ kamuya açılış için yeterli değildir.
- Moderasyon paneli, e-posta doğrulama, parola sıfırlama, yönetici 2FA, veri dışa aktarma tamamlanmadı.
- Topluluk üyelikleri, ev arkadaşı, eşya, soru-cevap, yaratıcı köşe ve seyahat başvuruları yapılmadı.
- Doğrudan mesaj, gönderim sonrası otomatik güncellenir; WebSocket/push özelliği yoktur.
- Laravel ve bağımsız PHP uygulaması birleştirilmedi.
- Üretim dağıtımı, KVKK ve güvenlik testleri bekliyor.
- Mevcut hesaplar 13+ gereksinimine göre yeniden doğrulanmıyor.

**Bu ZIP kapalı test amaçlıdır, yayına hazır tam ürün değildir.**
