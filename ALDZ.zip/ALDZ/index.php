<?php
// localhost/ALDZ/ -> localhost/ALDZ/frontend/
header('Location: ./frontend/', true, 302);
exit;
