# ALDZ V22 - Tek dosyadan veritabani kurulumu

**Tek SQL dosyasi:** `database.sql` (proje ana klasorunde). V14-V20 ayri SQL
guncellemeleri kaldirildi. Bu dosya hem yeni kurulum hem de mevcut eski
kurulumlarda eksik sutunlarin tamamlanmasi icin tasarlanmistir.

**Kurulum icin** `KURULUM_DATABASE_V22.txt` belgesini okuyun.
**Var olan kayitlar:** `database.sql` veri yedegi DEGILDIR. Yeni kurulum bos
veritabani kurar; eski veritabani uzerinde tablolari koruyarak semayi gunceller.
SQL dosyasini calistirmadan once phpMyAdmin'den yedek alin.

# ALDZ — Birlikte daha güzel

Laravel tabanlı sosyal platform için kapalı test geliştirme başlangıcı.

## İçerik

- `database.sql`: ortak kullanıcı/rol, profil, yaş grubu, engelleme, mesajlaşma, bildirim, yedi modül, şikâyet/moderasyon, itiraz, denetim ve hesap talepleri tabloları.
- `app/Services/AgeSafety.php`: yaş grubu, aktif hesap ve karşılıklı engelleme için ortak iletişim kuralı başlangıcı.
- `resources/views`: Türkçe duyarlı ana sayfa ve modül bilgilendirme sayfaları.
- `public/manifest.json`, `public/sw.js`, `public/offline.html`: PWA başlangıç altyapısı. Önbellek yalnızca statik kaynakları hedefler; özel HTML ve mesajlar önbelleğe alınmaz.
- `KURULUM.bat`, `BASLAT.bat`, `TANI_KOY.bat`: ortam kontrolü ve yerel çalıştırma betikleri.
- `TEST_RAPORU.md`: gerçek doğrulama durumu.

## Kurulum özeti

1. WAMP PHP 8.2+ sürümünü seçin ve WAMP MySQL'i başlatın.
2. `KURULUM.bat` çalıştırın. Betik PATH veya standart WAMP klasöründen PHP bulur; Composer yoksa resmi `composer.phar` dosyasını indirmeyi dener ve bağımlılıkları yükler.
3. phpMyAdmin'de `database.sql` dosyasını içe aktarın. Projede yalnızca bir veritabanı şema dosyası vardır: kök dizindeki `database.sql`. Başka dosya içe aktarmayın.
4. `.env` dosyasındaki `DB_*` değerlerini düzenleyin.
5. WAMP Apache ve MySQL servislerini başlatın. `http://localhost/ALDZ/frontend` adresini açın. Laravel bağımlılıkları yüklenmediyse önce `KURULUM.bat` çalıştırın. Alternatif geliştirme sunucusu için `BASLAT.bat` kullanabilirsiniz.

Detaylar için `KURULUM_DATABASE_V22.txt` dosyasına bakın.

## Mimari ve güvenlik notları

- `database.sql` tek şema kaynağıdır. `BASLAT.bat` veritabanını sıfırlamaz veya migration çalıştırmaz; SQL dosyasını phpMyAdmin üzerinden yalnızca bir kez içe aktarın.
- 13 yaş altı kayıt reddi ve her istekte yaş doğrulaması uygulama doğrulaması ile zorunlu kılınmalıdır. Yaş grubu alanı tek başına yeterli değildir. `age_band`, kayıt sırasında doğum tarihinden sunucuda hesaplanmalı ve kullanıcı tarafından serbestçe seçilememelidir.
- Aktivite, ev arkadaşı, etkinlik ve seyahat keşif sorgularında `age_band` ve cinsiyet tercihi aynı SQL sorgusunda uygulanmalıdır. Sadece arayüzde gizlemek güvenlik kontrolü değildir.
- Kadınlara özel ilanlarda `gender_preference='woman'` filtresi ve başvuru sırasında aynı sunucu tarafı kontrol gerekir. Cinsiyet tercihi ile yaş grubu birbirinden bağımsız kontrollerdir.
- Ücretsiz eşya ilanı için fiyat alanı yoktur. Metinlerde fiyat/ücret tekliflerini engellemek için yalnızca kelime filtresi yeterli değildir; moderasyon ve bildirim iş akışı gerekir.
- 2FA paketi Composer üzerinden tanımlanmıştır ancak personel paneline tam entegrasyonu bu teslimde tamamlanmış değildir.
- Bu paket üretim için hazır değildir. Açık internete yayınlamayın ve gerçek kullanıcı verisi kullanmayın.

## Kapsam dışı / tamamlanması gerekenler

Gerçek kayıt ve giriş akışları, e-posta doğrulama ve parola sıfırlama, personel 2FA, tüm modüllerin CRUD ve başvuru akışları, etkinlik dolduğunda atomik grup sohbeti oluşturma, gerçek zamanlı mesajlaşma, görsel yükleme doğrulaması, bildirim tercihleri, arama sorguları, moderasyon/itiraz ekranları, veri dışa aktarma ve hesap silme iş akışları, migration/SQL temiz kurulum entegrasyon testleri, tarayıcı/PWA testleri ve güvenlik testleri henüz uçtan uca tamamlanıp doğrulanmamıştır.

## Lisans ve üçüncü taraflar

Laravel ve Composer bağımlılıklarının lisans koşullarını proje dağıtımından önce kontrol edin. Google Fonts ağ bağlantısı gerektirir; çevrimdışı font garantisi verilmez.

## phpMyAdmin SQL hatası

`#1064` hatasında sorgu `<?php` ile başlıyorsa SQL olmayan bir PHP dosyası seçilmiştir. Bu pakette veritabanı şeması için yalnızca kök dizindeki `database.sql` kullanılmalıdır. SQL dosyasının ilk satırları `-- ALDZ | Birlikte daha güzel.` ve `SET NAMES utf8mb4;` şeklindedir.


Kurulumda hata olursa `KURULUM_LOG.txt` dosyasini inceleyin. `vendor/autoload.php` yoksa uygulama Composer bagimliliklari kurulana kadar acilmaz. PHP 8.2+ ve gerekli PHP uzantilari zorunludur.


## Takaset gibi WAMP uzerinden hizli onizleme
`body` klasorunu `C:\wamp64\www` dizinine kopyalayin, WAMP Apache acikken `http://localhost/ALDZ/` adresini ziyaret edin. Bu yol, yalnizca tanitim sayfalari icin Composer veya MySQL gerektirmeyen bagimsiz PHP onizlemesini acar. Tum asil Laravel kaynaklari korunmustur. Ayrintilar `KOLAY_KURULUM.txt` dosyasindadir.
