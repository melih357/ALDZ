@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ALDZ TANI KOY - ortam raporu
echo =============================
where php || echo PHP bulunamadi
php -v 2>&1
where composer || echo Composer bulunamadi
composer --version 2>&1
if exist .env (echo .env mevcut) else echo .env eksik
if exist vendor\autoload.php (echo Composer vendor mevcut) else echo vendor eksik
if exist database.sql (echo SQL dosyasi mevcut) else echo SQL dosyasi eksik
if exist public\manifest.json (echo PWA manifest mevcut) else echo manifest eksik
if exist public\sw.js (echo Service worker mevcut) else echo service worker eksik
if exist vendor\autoload.php php artisan about 2>&1
pause
