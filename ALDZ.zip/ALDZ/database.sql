-- ALDZ V22 | TEK VERITABANI DOSYASI | MySQL 8 / MariaDB 10.6+ | UTF-8
-- Bu dosya hem temiz kurulum hem de eski V14-V21 veritabanini veri silmeden
-- guncellemek icindir. SADECE BU .sql DOSYASINI phpMyAdmin'de ice aktarin.
-- UYARI: Import oncesinde mevcut veritabaninizin SQL yedegini mutlaka alin.
-- CREATE DATABASE IF NOT EXISTS ve CREATE TABLE IF NOT EXISTS veri silmez.
-- Var olan veritabani baska adla kurulduysa CREATE DATABASE/USE satirlarindaki
-- `aldz` adini uygulamanizin kullandigi veritabani adiyla degistirin.
-- Bu dosya uygulama verilerini (kayitli kullanicilar, mesajlar) ICERMEZ;
-- tum tablolar, iliskiler ve surumler arasi sema guncellemelerini icerir.

-- ALDZ | Birlikte daha güzel. | V22 Birlesik sema
-- MySQL 8.0+ / MariaDB 10.6+ | UTF-8 | Kapalı test başlangıç şeması
-- Güvenlik: Bu dosyada varsayılan personel hesabı veya parola bulunmaz.
SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET FOREIGN_KEY_CHECKS = 0;
CREATE DATABASE IF NOT EXISTS `aldz` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `aldz`;

CREATE TABLE IF NOT EXISTS roles (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(40) NOT NULL UNIQUE,
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL,
 username VARCHAR(30) NOT NULL UNIQUE, email VARCHAR(190) NOT NULL UNIQUE,
 email_verified_at TIMESTAMP NULL, password VARCHAR(255) NOT NULL,
 birth_date DATE NOT NULL, age_band ENUM('minor','adult') NOT NULL,
 gender ENUM('woman','man','nonbinary','undisclosed') NOT NULL DEFAULT 'undisclosed',
 status ENUM('pending','active','suspended','deactivated','deletion_pending') NOT NULL DEFAULT 'pending',
 must_change_password BOOLEAN NOT NULL DEFAULT FALSE, two_factor_secret TEXT NULL,
 two_factor_recovery_codes TEXT NULL, two_factor_confirmed_at TIMESTAMP NULL,
 remember_token VARCHAR(100) NULL, created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 INDEX idx_users_band_status(age_band,status), INDEX idx_users_name(name)
 -- Minimum yaş kontrolü uygulama katmanında sunucu tarafında yapılır.
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS role_user (
 user_id BIGINT UNSIGNED NOT NULL, role_id BIGINT UNSIGNED NOT NULL, created_at TIMESTAMP NULL,
 PRIMARY KEY(user_id,role_id), FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(role_id) REFERENCES roles(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS profiles (
 user_id BIGINT UNSIGNED PRIMARY KEY, bio VARCHAR(500) NULL, city VARCHAR(100) NULL,
 avatar_path VARCHAR(255) NULL, cover_path VARCHAR(255) NULL, visibility ENUM('public','members','private') NOT NULL DEFAULT 'members',
 preferences JSON NULL, created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_profiles_city(city)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS interests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(80) NOT NULL UNIQUE, created_at TIMESTAMP NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS interest_user (
 user_id BIGINT UNSIGNED NOT NULL, interest_id BIGINT UNSIGNED NOT NULL,
 PRIMARY KEY(user_id,interest_id), FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(interest_id) REFERENCES interests(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS user_blocks (
 blocker_id BIGINT UNSIGNED NOT NULL, blocked_id BIGINT UNSIGNED NOT NULL, created_at TIMESTAMP NULL,
 PRIMARY KEY(blocker_id,blocked_id), CHECK(blocker_id <> blocked_id),
 FOREIGN KEY(blocker_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(blocked_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS relationships (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, requester_id BIGINT UNSIGNED NOT NULL,
 addressee_id BIGINT UNSIGNED NOT NULL, status ENUM('pending','accepted','rejected','cancelled') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL, UNIQUE KEY uq_relationship(requester_id,addressee_id),
 FOREIGN KEY(requester_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(addressee_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS conversations (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, kind ENUM('direct','event_group','activity_group','support') NOT NULL DEFAULT 'direct',
 context_type VARCHAR(60) NULL, context_id BIGINT UNSIGNED NULL, title VARCHAR(150) NULL,
 created_by BIGINT UNSIGNED NULL, created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL, INDEX idx_conversation_context(context_type,context_id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS conversation_participants (
 conversation_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL,
 status ENUM('pending','active','left','removed') NOT NULL DEFAULT 'active', joined_at TIMESTAMP NULL,
 last_read_at TIMESTAMP NULL, PRIMARY KEY(conversation_id,user_id),
 FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS messages (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, conversation_id BIGINT UNSIGNED NOT NULL,
 sender_id BIGINT UNSIGNED NOT NULL, body TEXT NOT NULL, message_type ENUM('text','system') NOT NULL DEFAULT 'text',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL, deleted_at TIMESTAMP NULL,
 FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
 FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_messages_conversation_time(conversation_id,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS message_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, conversation_id BIGINT UNSIGNED NOT NULL,
 requester_id BIGINT UNSIGNED NOT NULL, recipient_id BIGINT UNSIGNED NOT NULL,
 status ENUM('pending','accepted','rejected','cancelled') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL, UNIQUE KEY uq_message_request(requester_id,recipient_id),
 FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
 FOREIGN KEY(requester_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(recipient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS notifications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 type VARCHAR(80) NOT NULL, title VARCHAR(160) NOT NULL, body VARCHAR(500) NULL,
 data JSON NULL, read_at TIMESTAMP NULL, created_at TIMESTAMP NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_notifications_unread(user_id,read_at,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS activity_listings (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 title VARCHAR(160) NOT NULL, description TEXT NOT NULL, activity_type VARCHAR(80) NOT NULL,
 city VARCHAR(100) NOT NULL, starts_at DATETIME NOT NULL, ends_at DATETIME NULL,
 capacity SMALLINT UNSIGNED NOT NULL DEFAULT 2, age_band ENUM('minor','adult') NOT NULL,
 gender_preference ENUM('any','woman','man','nonbinary') NOT NULL DEFAULT 'any',
 visibility ENUM('members','private') NOT NULL DEFAULT 'members',
 status ENUM('open','full','closed','cancelled','completed') NOT NULL DEFAULT 'open',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_activity_discovery(city,age_band,status,starts_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS activity_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, activity_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL, status ENUM('pending','accepted','rejected','cancelled') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL, UNIQUE KEY uq_activity_request(activity_id,user_id),
 FOREIGN KEY(activity_id) REFERENCES activity_listings(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_activity_requests_status(activity_id,status)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS roommate_listings (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 title VARCHAR(160) NOT NULL, description TEXT NOT NULL, city VARCHAR(100) NOT NULL, area VARCHAR(100) NULL,
 move_from DATE NULL, move_until DATE NULL, budget_share DECIMAL(10,2) NULL,
 gender_preference ENUM('any','woman','man','nonbinary') NOT NULL DEFAULT 'any',
 age_band ENUM('minor','adult') NOT NULL, lifestyle JSON NULL,
 status ENUM('open','closed','cancelled') NOT NULL DEFAULT 'open', created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_roommate_discovery(city,age_band,status)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS roommate_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, listing_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL,
 message VARCHAR(1000) NULL, status ENUM('pending','accepted','rejected','cancelled') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL, UNIQUE KEY uq_roommate_request(listing_id,user_id),
 FOREIGN KEY(listing_id) REFERENCES roommate_listings(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS giveaway_listings (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 title VARCHAR(160) NOT NULL, description TEXT NOT NULL, category VARCHAR(80) NOT NULL,
 condition_label ENUM('new','good','used','needs_repair') NOT NULL, city VARCHAR(100) NOT NULL,
 image_path VARCHAR(255) NULL, delivery_method ENUM('pickup','public_place','other') NOT NULL DEFAULT 'public_place',
 status ENUM('available','reserved','delivered','closed','removed') NOT NULL DEFAULT 'available',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_giveaway_discovery(city,category,status)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS giveaway_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, listing_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL,
 message VARCHAR(1000) NULL, status ENUM('pending','accepted','rejected','cancelled','delivered') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL, UNIQUE KEY uq_giveaway_request(listing_id,user_id),
 FOREIGN KEY(listing_id) REFERENCES giveaway_listings(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS community_posts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 category VARCHAR(80) NOT NULL, post_type ENUM('question','experience','advice','discussion','knowledge') NOT NULL,
 title VARCHAR(200) NOT NULL, body TEXT NOT NULL, is_anonymous BOOLEAN NOT NULL DEFAULT FALSE,
 status ENUM('published','hidden','removed','draft') NOT NULL DEFAULT 'published', created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_posts_feed(category,status,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS post_comments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, post_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL,
 parent_id BIGINT UNSIGNED NULL, body TEXT NOT NULL, status ENUM('published','hidden','removed') NOT NULL DEFAULT 'published',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(post_id) REFERENCES community_posts(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(parent_id) REFERENCES post_comments(id) ON DELETE SET NULL, INDEX idx_comments_post(post_id,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS post_votes (
 post_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, value TINYINT NOT NULL,
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL, PRIMARY KEY(post_id,user_id), CHECK(value IN (-1,1)),
 FOREIGN KEY(post_id) REFERENCES community_posts(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS saved_posts (
 post_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, created_at TIMESTAMP NULL,
 PRIMARY KEY(post_id,user_id), FOREIGN KEY(post_id) REFERENCES community_posts(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 title VARCHAR(180) NOT NULL, description TEXT NOT NULL, category VARCHAR(80) NOT NULL,
 starts_at DATETIME NOT NULL, ends_at DATETIME NULL, city VARCHAR(100) NOT NULL, venue_general VARCHAR(180) NULL,
 capacity SMALLINT UNSIGNED NOT NULL, age_band ENUM('minor','adult') NOT NULL,
 gender_preference ENUM('any','woman','man','nonbinary') NOT NULL DEFAULT 'any',
 approval_required BOOLEAN NOT NULL DEFAULT FALSE, visibility ENUM('members','private') NOT NULL DEFAULT 'members',
 status ENUM('open','full','cancelled','completed') NOT NULL DEFAULT 'open',
 group_conversation_id BIGINT UNSIGNED NULL, created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(group_conversation_id) REFERENCES conversations(id) ON DELETE SET NULL,
 INDEX idx_events_discovery(city,age_band,status,starts_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS event_participants (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, event_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL,
 status ENUM('pending','confirmed','waitlisted','rejected','cancelled','removed') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL, UNIQUE KEY uq_event_participant(event_id,user_id),
 FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_event_participants_status(event_id,status)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS creative_works (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 title VARCHAR(200) NOT NULL, body LONGTEXT NOT NULL, work_type ENUM('story','poem','lyrics','idea','short_text','collaboration') NOT NULL,
 status ENUM('draft','published','hidden','removed') NOT NULL DEFAULT 'draft', created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_creative_feed(work_type,status,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS creative_collaborations (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, work_id BIGINT UNSIGNED NOT NULL,
 owner_id BIGINT UNSIGNED NOT NULL, invited_user_id BIGINT UNSIGNED NOT NULL,
 contribution LONGTEXT NULL, status ENUM('invited','accepted','rejected','completed') NOT NULL DEFAULT 'invited',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(work_id) REFERENCES creative_works(id) ON DELETE CASCADE,
 FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(invited_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS travel_profiles (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 destination VARCHAR(120) NOT NULL, country VARCHAR(100) NULL, starts_on DATE NOT NULL, ends_on DATE NOT NULL,
 city_from VARCHAR(100) NULL, interests JSON NULL, budget_band VARCHAR(40) NULL,
 age_band ENUM('minor','adult') NOT NULL, gender_preference ENUM('any','woman','man','nonbinary') NOT NULL DEFAULT 'any',
 description TEXT NULL, status ENUM('open','closed','cancelled') NOT NULL DEFAULT 'open',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_travel_discovery(destination,age_band,status,starts_on,ends_on)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS travel_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, travel_profile_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL,
 message VARCHAR(1000) NULL, status ENUM('pending','accepted','rejected','cancelled') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL, UNIQUE KEY uq_travel_request(travel_profile_id,user_id),
 FOREIGN KEY(travel_profile_id) REFERENCES travel_profiles(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS reports (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, reporter_id BIGINT UNSIGNED NOT NULL,
 target_type VARCHAR(80) NOT NULL, target_id BIGINT UNSIGNED NOT NULL, category VARCHAR(80) NOT NULL,
 description TEXT NULL, status ENUM('new','reviewing','need_info','actioned','no_action','appealed','resolved') NOT NULL DEFAULT 'new',
 assigned_to BIGINT UNSIGNED NULL, created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(reporter_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(assigned_to) REFERENCES users(id) ON DELETE SET NULL, INDEX idx_reports_queue(status,created_at), INDEX idx_reports_target(target_type,target_id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS moderation_actions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, report_id BIGINT UNSIGNED NULL,
 target_user_id BIGINT UNSIGNED NULL, moderator_id BIGINT UNSIGNED NOT NULL,
 action_type ENUM('warning','content_removed','temporary_restriction','suspend','restore','no_action') NOT NULL,
 reason VARCHAR(1000) NOT NULL, expires_at TIMESTAMP NULL, created_at TIMESTAMP NULL,
 FOREIGN KEY(report_id) REFERENCES reports(id) ON DELETE SET NULL,
 FOREIGN KEY(target_user_id) REFERENCES users(id) ON DELETE SET NULL,
 FOREIGN KEY(moderator_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS moderation_appeals (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, action_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL,
 reason TEXT NOT NULL, status ENUM('pending','reviewing','accepted','rejected') NOT NULL DEFAULT 'pending',
 reviewer_id BIGINT UNSIGNED NULL, decision_note TEXT NULL, created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 FOREIGN KEY(action_id) REFERENCES moderation_actions(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(reviewer_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, actor_id BIGINT UNSIGNED NULL,
 action VARCHAR(120) NOT NULL, target_type VARCHAR(80) NULL, target_id BIGINT UNSIGNED NULL,
 metadata JSON NULL, ip_hash CHAR(64) NULL, created_at TIMESTAMP NULL,
 FOREIGN KEY(actor_id) REFERENCES users(id) ON DELETE SET NULL, INDEX idx_audit_actor_time(actor_id,created_at), INDEX idx_audit_target(target_type,target_id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS account_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 request_type ENUM('deletion','export') NOT NULL, status ENUM('pending','processing','completed','rejected','failed') NOT NULL DEFAULT 'pending',
 requested_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, completed_at TIMESTAMP NULL, notes VARCHAR(1000) NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_account_requests(status,request_type)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_schema_version (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, version VARCHAR(40) NOT NULL UNIQUE, created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL
) ENGINE=InnoDB;
INSERT IGNORE INTO body_schema_version(version,created_at,updated_at) VALUES ('ALDZ_AUTH_V1',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS personal_access_tokens (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, tokenable_type VARCHAR(255) NOT NULL, tokenable_id BIGINT UNSIGNED NOT NULL,
 name VARCHAR(100) NOT NULL, token CHAR(64) NOT NULL UNIQUE, abilities TEXT NULL,
 last_used_at TIMESTAMP NULL, expires_at TIMESTAMP NULL, created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
 INDEX idx_tokens_owner(tokenable_type,tokenable_id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS password_reset_tokens (
 email VARCHAR(190) PRIMARY KEY, token VARCHAR(255) NOT NULL, created_at TIMESTAMP NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS sessions (
 id VARCHAR(255) PRIMARY KEY, user_id BIGINT UNSIGNED NULL, ip_address VARCHAR(45) NULL,
 user_agent TEXT NULL, payload LONGTEXT NOT NULL, last_activity INT NOT NULL,
 INDEX idx_sessions_user(user_id), INDEX idx_sessions_activity(last_activity)
) ENGINE=InnoDB;
INSERT IGNORE INTO roles(name,created_at,updated_at) VALUES
 ('system_admin',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP),('moderator',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP),('support',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP),('member',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);
INSERT IGNORE INTO interests(name) VALUES ('Yürüyüş'),('Koşu'),('Kahve'),('Kitap'),('Müzik'),('Oyun'),('Seyahat'),('Yemek'),('Fotoğraf'),('Yazarlık');
SET FOREIGN_KEY_CHECKS = 1;

-- ALDZ Social V2: same single import file, safe to re-import (CREATE IF NOT EXISTS).
CREATE TABLE IF NOT EXISTS social_preferences (
 user_id BIGINT UNSIGNED PRIMARY KEY,
 account_private TINYINT(1) NOT NULL DEFAULT 0,
 follow_visibility ENUM('everyone','following','mutual','only_me') NOT NULL DEFAULT 'everyone',
 language_code ENUM('tr','en','es','ar','it') NOT NULL DEFAULT 'tr',
 appearance ENUM('social') NOT NULL DEFAULT 'social',
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS social_follows (
 follower_id BIGINT UNSIGNED NOT NULL,
 following_id BIGINT UNSIGNED NOT NULL,
 status ENUM('pending','accepted') NOT NULL DEFAULT 'accepted',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (follower_id,following_id),
 FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS social_posts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 caption TEXT NOT NULL,
 media_path VARCHAR(255) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_social_posts_feed(created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS social_post_likes (
 post_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (post_id,user_id),
 FOREIGN KEY(post_id) REFERENCES social_posts(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS social_post_comments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 post_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 body VARCHAR(1000) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(post_id) REFERENCES social_posts(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_social_comments(post_id,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS social_stories (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 media_path VARCHAR(255) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 expires_at TIMESTAMP NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_stories_expire(expires_at)
) ENGINE=InnoDB;

-- ALDZ V14: tüm ilan türleri için tek, türlendirilmiş ilan tablosu
CREATE TABLE IF NOT EXISTS body_listings (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 type ENUM('activity','roommate','freeitems','experience','creative','travel','shares','samegender','skills','jobs','partners') NOT NULL,
 title VARCHAR(140) NOT NULL,
 description TEXT NOT NULL,
 city VARCHAR(100) NOT NULL,
 image_path VARCHAR(255) NULL,
 extra_info VARCHAR(250) NULL,
 category_details TEXT NULL,
 min_age TINYINT UNSIGNED NOT NULL DEFAULT 18,
 max_age TINYINT UNSIGNED NOT NULL DEFAULT 99,
 age_band ENUM('minor','adult') NOT NULL DEFAULT 'adult',
 approval_required TINYINT(1) NOT NULL DEFAULT 1,
 chat_mode ENUM('open','after_ready') NOT NULL DEFAULT 'open',
 chat_ready TINYINT(1) NOT NULL DEFAULT 0,
 chat_writers ENUM('all','owner') NOT NULL DEFAULT 'all',
 event_date DATETIME NULL,
 status ENUM('active','closed','completed') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_listing_type_status (type,status,created_at),
 INDEX idx_listing_owner (user_id,created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS body_listing_cvs (
 listing_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 cv_text TEXT NULL,
 cv_pdf LONGBLOB NULL,
 cv_filename VARCHAR(150) NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY(listing_id,user_id),
 FOREIGN KEY(listing_id) REFERENCES body_listings(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS body_listing_members (
 listing_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 status ENUM('pending','accepted','rejected','left') NOT NULL DEFAULT 'pending',
 requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY(listing_id,user_id),
 FOREIGN KEY(listing_id) REFERENCES body_listings(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_member_status(listing_id,status)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_listing_messages (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 listing_id BIGINT UNSIGNED NOT NULL,
 sender_id BIGINT UNSIGNED NOT NULL,
 body VARCHAR(2000) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(listing_id) REFERENCES body_listings(id) ON DELETE CASCADE,
 FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_chat_listing_time(listing_id,created_at)
) ENGINE=InnoDB;

-- ALDZ V18: halka açık ilan soru-cevap ve katılımcı değerlendirmeleri

CREATE TABLE IF NOT EXISTS body_listing_questions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, listing_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, body VARCHAR(1000) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (listing_id) REFERENCES body_listings(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_listing_questions(listing_id,id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_listing_answers (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, question_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, body VARCHAR(1500) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (question_id) REFERENCES body_listing_questions(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_question_answers(question_id,id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_listing_reviews (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, listing_id BIGINT UNSIGNED NOT NULL, reviewer_id BIGINT UNSIGNED NOT NULL, reviewed_user_id BIGINT UNSIGNED NOT NULL, rating TINYINT UNSIGNED NOT NULL, safe_experience TINYINT(1) NOT NULL, body VARCHAR(1000) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_listing_reviewer(listing_id,reviewer_id), FOREIGN KEY (listing_id) REFERENCES body_listings(id) ON DELETE CASCADE, FOREIGN KEY (reviewer_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY (reviewed_user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_reviewed_user(reviewed_user_id,created_at)
) ENGINE=InnoDB;

-- ================================================================
-- UYUMLULUK GUNCELLEMELERI (ESKI KURULUMLAR ICIN)
-- Asagidaki islemler sadece eksik alan varsa uygulanir. Ayni dosya
-- yeniden calistirildiginda veri silinmez / duplicate column hatasi verilmez.
-- Not: MySQL/MariaDB PREPARE, DO 0 komutunu destekler.
-- ================================================================

-- V16 kategoriye ozel ilan ayrintilari
SELECT COUNT(*) INTO @body_col_exists FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'body_listings' AND COLUMN_NAME = 'category_details';
SET @body_ddl = IF(@body_col_exists = 0, 'ALTER TABLE body_listings ADD COLUMN category_details TEXT NULL AFTER extra_info', 'DO 0');
PREPARE body_upgrade_stmt FROM @body_ddl;
EXECUTE body_upgrade_stmt;
DEALLOCATE PREPARE body_upgrade_stmt;

-- Eski semada yas grubu alani bulunmuyorsa, veri donusumu gereklidir.
SELECT COUNT(*) INTO @body_ageband_existed FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'body_listings' AND COLUMN_NAME = 'age_band';

-- V17 ilan uyumlulugu: min_age
SELECT COUNT(*) INTO @body_col_exists FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'body_listings' AND COLUMN_NAME = 'min_age';
SET @body_ddl = IF(@body_col_exists = 0, 'ALTER TABLE body_listings ADD COLUMN min_age TINYINT UNSIGNED NOT NULL DEFAULT 18', 'DO 0');
PREPARE body_upgrade_stmt FROM @body_ddl;
EXECUTE body_upgrade_stmt;
DEALLOCATE PREPARE body_upgrade_stmt;

-- V17 ilan uyumlulugu: max_age
SELECT COUNT(*) INTO @body_col_exists FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'body_listings' AND COLUMN_NAME = 'max_age';
SET @body_ddl = IF(@body_col_exists = 0, 'ALTER TABLE body_listings ADD COLUMN max_age TINYINT UNSIGNED NOT NULL DEFAULT 99', 'DO 0');
PREPARE body_upgrade_stmt FROM @body_ddl;
EXECUTE body_upgrade_stmt;
DEALLOCATE PREPARE body_upgrade_stmt;

-- V17 ilan uyumlulugu: age_band
SELECT COUNT(*) INTO @body_col_exists FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'body_listings' AND COLUMN_NAME = 'age_band';
SET @body_ddl = IF(@body_col_exists = 0, 'ALTER TABLE body_listings ADD COLUMN age_band ENUM(''minor'',''adult'') NOT NULL DEFAULT ''adult''', 'DO 0');
PREPARE body_upgrade_stmt FROM @body_ddl;
EXECUTE body_upgrade_stmt;
DEALLOCATE PREPARE body_upgrade_stmt;

-- V17 ilan uyumlulugu: approval_required
SELECT COUNT(*) INTO @body_col_exists FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'body_listings' AND COLUMN_NAME = 'approval_required';
SET @body_ddl = IF(@body_col_exists = 0, 'ALTER TABLE body_listings ADD COLUMN approval_required TINYINT(1) NOT NULL DEFAULT 1', 'DO 0');
PREPARE body_upgrade_stmt FROM @body_ddl;
EXECUTE body_upgrade_stmt;
DEALLOCATE PREPARE body_upgrade_stmt;

-- V17 ilan uyumlulugu: chat_mode
SELECT COUNT(*) INTO @body_col_exists FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'body_listings' AND COLUMN_NAME = 'chat_mode';
SET @body_ddl = IF(@body_col_exists = 0, 'ALTER TABLE body_listings ADD COLUMN chat_mode ENUM(''open'',''after_ready'') NOT NULL DEFAULT ''open''', 'DO 0');
PREPARE body_upgrade_stmt FROM @body_ddl;
EXECUTE body_upgrade_stmt;
DEALLOCATE PREPARE body_upgrade_stmt;

-- V17 ilan uyumlulugu: chat_ready
SELECT COUNT(*) INTO @body_col_exists FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'body_listings' AND COLUMN_NAME = 'chat_ready';
SET @body_ddl = IF(@body_col_exists = 0, 'ALTER TABLE body_listings ADD COLUMN chat_ready TINYINT(1) NOT NULL DEFAULT 0', 'DO 0');
PREPARE body_upgrade_stmt FROM @body_ddl;
EXECUTE body_upgrade_stmt;
DEALLOCATE PREPARE body_upgrade_stmt;

-- V17 ilan uyumlulugu: chat_writers
SELECT COUNT(*) INTO @body_col_exists FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'body_listings' AND COLUMN_NAME = 'chat_writers';
SET @body_ddl = IF(@body_col_exists = 0, 'ALTER TABLE body_listings ADD COLUMN chat_writers ENUM(''all'',''owner'') NOT NULL DEFAULT ''all''', 'DO 0');
PREPARE body_upgrade_stmt FROM @body_ddl;
EXECUTE body_upgrade_stmt;
DEALLOCATE PREPARE body_upgrade_stmt;

-- Yalnizca V17 oncesinde age_band olmayan ilanlarin yas bilgilerini aktar.
SET @body_ddl = IF(@body_ageband_existed = 0,
 'UPDATE body_listings l JOIN users u ON u.id=l.user_id SET l.age_band=u.age_band, l.min_age=IF(u.age_band=''minor'',13,18), l.max_age=IF(u.age_band=''minor'',17,99)',
 'DO 0');
PREPARE body_upgrade_stmt FROM @body_ddl;
EXECUTE body_upgrade_stmt;
DEALLOCATE PREPARE body_upgrade_stmt;

-- V18: tamamlandi durumu olan enum; V19/V20: yeni ilan turleri.
SELECT COUNT(*) INTO @body_enum_ok FROM information_schema.COLUMNS
 WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='body_listings'
 AND COLUMN_NAME='status' AND COLUMN_TYPE LIKE '%completed%';
SET @body_ddl = IF(@body_enum_ok = 0,
 'ALTER TABLE body_listings MODIFY COLUMN status ENUM(''active'',''closed'',''completed'') NOT NULL DEFAULT ''active''',
 'DO 0');
PREPARE body_upgrade_stmt FROM @body_ddl;
EXECUTE body_upgrade_stmt;
DEALLOCATE PREPARE body_upgrade_stmt;

SELECT COUNT(*) INTO @body_enum_ok FROM information_schema.COLUMNS
 WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='body_listings'
 AND COLUMN_NAME='type' AND COLUMN_TYPE LIKE '%partners%' AND COLUMN_TYPE LIKE '%skills%' AND COLUMN_TYPE LIKE '%creative%' AND COLUMN_TYPE LIKE '%travel%' AND COLUMN_TYPE LIKE '%freeitems%' AND COLUMN_TYPE LIKE '%samegender%';
SET @body_ddl = IF(@body_enum_ok = 0,
 'ALTER TABLE body_listings MODIFY COLUMN type ENUM(''activity'',''roommate'',''freeitems'',''experience'',''creative'',''travel'',''shares'',''samegender'',''skills'',''jobs'',''partners'') NOT NULL',
 'DO 0');
PREPARE body_upgrade_stmt FROM @body_ddl;
EXECUTE body_upgrade_stmt;
DEALLOCATE PREPARE body_upgrade_stmt;

INSERT IGNORE INTO body_schema_version(version,created_at,updated_at)
 VALUES ('ALDZ_DATABASE_V22',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);

-- ALDZ V23: mevcut kullanıcıları ve ilanları silmeden yeni alanları ekle.
SELECT COUNT(*) INTO @body_v23_cover FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='profiles' AND COLUMN_NAME='cover_path';
SET @body_v23_ddl=IF(@body_v23_cover=0,'ALTER TABLE profiles ADD COLUMN cover_path VARCHAR(255) NULL AFTER avatar_path','DO 0');
PREPARE v23stmt FROM @body_v23_ddl; EXECUTE v23stmt; DEALLOCATE PREPARE v23stmt;
SELECT COUNT(*) INTO @body_v23_follow FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='social_preferences' AND COLUMN_NAME='follow_visibility';
SET @body_v23_ddl=IF(@body_v23_follow=0,'ALTER TABLE social_preferences ADD COLUMN follow_visibility ENUM(''everyone'',''following'',''mutual'',''only_me'') NOT NULL DEFAULT ''everyone'' AFTER account_private','DO 0');
PREPARE v23stmt FROM @body_v23_ddl; EXECUTE v23stmt; DEALLOCATE PREPARE v23stmt;
CREATE TABLE IF NOT EXISTS body_communities (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 owner_id BIGINT UNSIGNED NOT NULL,
 name VARCHAR(100) NOT NULL,
 description VARCHAR(1000) NOT NULL DEFAULT '',
 age_band ENUM('minor','adult') NOT NULL,
 mode ENUM('all','admins') NOT NULL DEFAULT 'all',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_com_age(age_band,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_community_members (
 community_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 role ENUM('owner','admin','member') NOT NULL DEFAULT 'member',
 joined_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(community_id,user_id),
 FOREIGN KEY(community_id) REFERENCES body_communities(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_community_messages (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 community_id BIGINT UNSIGNED NOT NULL,
 sender_id BIGINT UNSIGNED NOT NULL,
 body VARCHAR(2000) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(community_id) REFERENCES body_communities(id) ON DELETE CASCADE,
 FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_com_messages(community_id,id)
) ENGINE=InnoDB;


-- ALDZ V24: Çoklu medya, yorum ayarları, repostlar. Mevcut sosyal_posts korunur.
CREATE TABLE IF NOT EXISTS body_post_media (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 post_id BIGINT UNSIGNED NOT NULL,
 media_path VARCHAR(255) NOT NULL,
 media_kind ENUM('photo','video') NOT NULL DEFAULT 'photo',
 position SMALLINT UNSIGNED NOT NULL DEFAULT 0,
 FOREIGN KEY (post_id) REFERENCES social_posts(id) ON DELETE CASCADE,
 INDEX idx_body_post_media (post_id, position)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_post_options (
 post_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
 comments_enabled TINYINT(1) NOT NULL DEFAULT 1,
 FOREIGN KEY (post_id) REFERENCES social_posts(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_post_reposts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 post_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 visibility ENUM('everyone','followers') NOT NULL DEFAULT 'followers',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uniq_body_repost (post_id,user_id),
 FOREIGN KEY (post_id) REFERENCES social_posts(id) ON DELETE CASCADE,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_body_repost_date(created_at)
) ENGINE=InnoDB;


-- ALDZ V25: private direct-message media, custom stickers, reactions and call signaling.
CREATE TABLE IF NOT EXISTS body_message_attachments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 message_id BIGINT UNSIGNED NOT NULL,
 storage_key VARCHAR(90) NOT NULL UNIQUE,
 original_name VARCHAR(180) NOT NULL,
 mime VARCHAR(90) NOT NULL,
 byte_size INT UNSIGNED NOT NULL,
 kind ENUM('image','file','voice','sticker') NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(message_id) REFERENCES messages(id) ON DELETE CASCADE,
 INDEX idx_body_attach_message(message_id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_message_reactions (
 message_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 emoji VARCHAR(20) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(message_id,user_id),
 FOREIGN KEY(message_id) REFERENCES messages(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_custom_stickers (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 owner_id BIGINT UNSIGNED NOT NULL,
 storage_key VARCHAR(90) NOT NULL UNIQUE,
 mime VARCHAR(90) NOT NULL,
 name VARCHAR(90) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_body_stickers_owner(owner_id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_direct_calls (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 conversation_id BIGINT UNSIGNED NOT NULL,
 caller_id BIGINT UNSIGNED NOT NULL,
 callee_id BIGINT UNSIGNED NOT NULL,
 kind ENUM('audio','video') NOT NULL,
 status ENUM('ringing','accepted','declined','ended') NOT NULL DEFAULT 'ringing',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
 FOREIGN KEY(caller_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(callee_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_body_calls_state(conversation_id,status,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS body_call_signals (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 call_id BIGINT UNSIGNED NOT NULL,
 sender_id BIGINT UNSIGNED NOT NULL,
 signal_type ENUM('offer','answer','ice') NOT NULL,
 payload MEDIUMTEXT NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(call_id) REFERENCES body_direct_calls(id) ON DELETE CASCADE,
 FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_body_call_signal(call_id,id)
) ENGINE=InnoDB;

-- ALDZ V26: video lengths and single-view message photos.
-- Apply safely to existing databases; do not delete any records.
SET @v26db = DATABASE();
SET @v26has = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@v26db AND TABLE_NAME='body_post_options' AND COLUMN_NAME='video_length');
SET @v26sql = IF(@v26has=0, 'ALTER TABLE body_post_options ADD COLUMN video_length ENUM(''short'',''long'') NULL DEFAULT NULL', 'SELECT 1');
PREPARE body_v26_stmt FROM @v26sql; EXECUTE body_v26_stmt; DEALLOCATE PREPARE body_v26_stmt;
SET @v26has = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@v26db AND TABLE_NAME='body_message_attachments' AND COLUMN_NAME='view_once');
SET @v26sql = IF(@v26has=0, 'ALTER TABLE body_message_attachments ADD COLUMN view_once TINYINT(1) NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE body_v26_stmt FROM @v26sql; EXECUTE body_v26_stmt; DEALLOCATE PREPARE body_v26_stmt;
SET @v26has = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@v26db AND TABLE_NAME='body_message_attachments' AND COLUMN_NAME='viewed_at');
SET @v26sql = IF(@v26has=0, 'ALTER TABLE body_message_attachments ADD COLUMN viewed_at DATETIME NULL DEFAULT NULL', 'SELECT 1');
PREPARE body_v26_stmt FROM @v26sql; EXECUTE body_v26_stmt; DEALLOCATE PREPARE body_v26_stmt;

-- ALDZ V31: DEMO VERILER (45 kategori ilani ve 5 etkinlik).
-- Sadece ornekler; gercek bulusma, is ve ortaklik teklifleri degildir.
-- Var olan kullanicilar/ilanlar silinmez. Ayni dosya yeniden calistirilirsa kayitlar cogalmaz.
-- Demo hesaplarin parolasi kullanilabilir bir parola karmasi degildir.
INSERT INTO users (name,username,email,password,birth_date,age_band,gender,status,created_at,updated_at) SELECT 'ALDZ Demo 1', 'body_demo_01', 'aldz-demo-01@example.invalid', '!DEMO_LOGIN_DISABLED!', '1995-06-15', 'adult', 'woman', 'active', NOW(), NOW() WHERE NOT EXISTS (SELECT 1 FROM users WHERE username='body_demo_01');
INSERT INTO profiles (user_id,bio,city,visibility,created_at,updated_at) SELECT id,'Bu hesap yalnızca ALDZ arayüzünü örneklemek içindir. Gerçek kullanıcı değildir.','İstanbul','public',NOW(),NOW() FROM users WHERE username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM profiles WHERE user_id=users.id);
INSERT INTO users (name,username,email,password,birth_date,age_band,gender,status,created_at,updated_at) SELECT 'ALDZ Demo 2', 'body_demo_02', 'aldz-demo-02@example.invalid', '!DEMO_LOGIN_DISABLED!', '1995-06-15', 'adult', 'man', 'active', NOW(), NOW() WHERE NOT EXISTS (SELECT 1 FROM users WHERE username='body_demo_02');
INSERT INTO profiles (user_id,bio,city,visibility,created_at,updated_at) SELECT id,'Bu hesap yalnızca ALDZ arayüzünü örneklemek içindir. Gerçek kullanıcı değildir.','Ankara','public',NOW(),NOW() FROM users WHERE username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM profiles WHERE user_id=users.id);
INSERT INTO users (name,username,email,password,birth_date,age_band,gender,status,created_at,updated_at) SELECT 'ALDZ Demo 3', 'body_demo_03', 'aldz-demo-03@example.invalid', '!DEMO_LOGIN_DISABLED!', '1995-06-15', 'adult', 'woman', 'active', NOW(), NOW() WHERE NOT EXISTS (SELECT 1 FROM users WHERE username='body_demo_03');
INSERT INTO profiles (user_id,bio,city,visibility,created_at,updated_at) SELECT id,'Bu hesap yalnızca ALDZ arayüzünü örneklemek içindir. Gerçek kullanıcı değildir.','İzmir','public',NOW(),NOW() FROM users WHERE username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM profiles WHERE user_id=users.id);
INSERT INTO users (name,username,email,password,birth_date,age_band,gender,status,created_at,updated_at) SELECT 'ALDZ Demo 4', 'body_demo_04', 'aldz-demo-04@example.invalid', '!DEMO_LOGIN_DISABLED!', '1995-06-15', 'adult', 'man', 'active', NOW(), NOW() WHERE NOT EXISTS (SELECT 1 FROM users WHERE username='body_demo_04');
INSERT INTO profiles (user_id,bio,city,visibility,created_at,updated_at) SELECT id,'Bu hesap yalnızca ALDZ arayüzünü örneklemek içindir. Gerçek kullanıcı değildir.','Bursa','public',NOW(),NOW() FROM users WHERE username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM profiles WHERE user_id=users.id);
INSERT INTO users (name,username,email,password,birth_date,age_band,gender,status,created_at,updated_at) SELECT 'ALDZ Demo 5', 'body_demo_05', 'aldz-demo-05@example.invalid', '!DEMO_LOGIN_DISABLED!', '1995-06-15', 'adult', 'man', 'active', NOW(), NOW() WHERE NOT EXISTS (SELECT 1 FROM users WHERE username='body_demo_05');
INSERT INTO profiles (user_id,bio,city,visibility,created_at,updated_at) SELECT id,'Bu hesap yalnızca ALDZ arayüzünü örneklemek içindir. Gerçek kullanıcı değildir.','Antalya','public',NOW(),NOW() FROM users WHERE username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM profiles WHERE user_id=users.id);
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'activity','[DEMO] Hafta sonu sahil yürüyüşü','Bu bir örnek activity ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İstanbul / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"activity_kind":"Yürüyüş"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='activity' AND b.title='[DEMO] Hafta sonu sahil yürüyüşü');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'activity','[DEMO] Kahve ve masa oyunları','Bu bir örnek activity ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Ankara / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"activity_kind":"Kahve"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='activity' AND b.title='[DEMO] Kahve ve masa oyunları');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'activity','[DEMO] Parkta açık hava sporu','Bu bir örnek activity ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İzmir / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"activity_kind":"Spor"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='activity' AND b.title='[DEMO] Parkta açık hava sporu');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'activity','[DEMO] Yeni başlayanlarla kutu oyunu','Bu bir örnek activity ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Bursa / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"activity_kind":"Oyun"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='activity' AND b.title='[DEMO] Yeni başlayanlarla kutu oyunu');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'activity','[DEMO] Müze gezisi arkadaşları','Bu bir örnek activity ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Antalya / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"activity_kind":"Kültür"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='activity' AND b.title='[DEMO] Müze gezisi arkadaşları');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'roommate','[DEMO] 2+1 ev için oda arkadaşı','Bu bir örnek roommate ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İstanbul / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"house_type":"2+1","room_kind":"Ayrı oda","monthly_rent":"12000","furnished":"Eşyalı"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='roommate' AND b.title='[DEMO] 2+1 ev için oda arkadaşı');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'roommate','[DEMO] 1+1 daire için yaşam uyumu','Bu bir örnek roommate ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Ankara / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"house_type":"1+1","room_kind":"Ayrı oda","monthly_rent":"12000","furnished":"Eşyalı"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='roommate' AND b.title='[DEMO] 1+1 daire için yaşam uyumu');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'roommate','[DEMO] 3+1 evde ayrı oda paylaşımı','Bu bir örnek roommate ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İzmir / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"house_type":"3+1","room_kind":"Ayrı oda","monthly_rent":"12000","furnished":"Eşyalı"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='roommate' AND b.title='[DEMO] 3+1 evde ayrı oda paylaşımı');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'roommate','[DEMO] 2+1 eşyalı evde oda','Bu bir örnek roommate ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Bursa / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"house_type":"2+1","room_kind":"Ayrı oda","monthly_rent":"12000","furnished":"Eşyalı"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='roommate' AND b.title='[DEMO] 2+1 eşyalı evde oda');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'roommate','[DEMO] Yeni ev kurmak için ortak arayışı','Bu bir örnek roommate ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Antalya / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"house_type":"1+1","room_kind":"Ayrı oda","monthly_rent":"12000","furnished":"Eşyalı"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='roommate' AND b.title='[DEMO] Yeni ev kurmak için ortak arayışı');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'freeitems','[DEMO] Okunmuş romanlar ücretsiz','Bu bir örnek freeitems ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İstanbul / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"item_category":"Kitap","item_condition":"Az kullanılmış","delivery":"Elden teslim"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='freeitems' AND b.title='[DEMO] Okunmuş romanlar ücretsiz');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'freeitems','[DEMO] İkinci el çalışma masası','Bu bir örnek freeitems ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Ankara / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"item_category":"Mobilya","item_condition":"Az kullanılmış","delivery":"Elden teslim"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='freeitems' AND b.title='[DEMO] İkinci el çalışma masası');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'freeitems','[DEMO] Temiz çocuk kıyafetleri','Bu bir örnek freeitems ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İzmir / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"item_category":"Giyim","item_condition":"Az kullanılmış","delivery":"Elden teslim"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='freeitems' AND b.title='[DEMO] Temiz çocuk kıyafetleri');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'freeitems','[DEMO] Kullanılabilir mutfak eşyaları','Bu bir örnek freeitems ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Bursa / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"item_category":"Ev eşyası","item_condition":"Az kullanılmış","delivery":"Elden teslim"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='freeitems' AND b.title='[DEMO] Kullanılabilir mutfak eşyaları');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'freeitems','[DEMO] Eski ama çalışan masa lambası','Bu bir örnek freeitems ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Antalya / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"item_category":"Elektronik","item_condition":"Az kullanılmış","delivery":"Elden teslim"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='freeitems' AND b.title='[DEMO] Eski ama çalışan masa lambası');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'creative','[DEMO] Şiir atölyesi için ortak çalışma','Bu bir örnek creative ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İstanbul / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"creative_kind":"Şiir","creative_stage":"Ortak arıyorum"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='creative' AND b.title='[DEMO] Şiir atölyesi için ortak çalışma');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'creative','[DEMO] Akustik şarkı çalışması','Bu bir örnek creative ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Ankara / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"creative_kind":"Şarkı","creative_stage":"Ortak arıyorum"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='creative' AND b.title='[DEMO] Akustik şarkı çalışması');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'creative','[DEMO] Roman taslağı için okur görüşü','Bu bir örnek creative ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İzmir / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"creative_kind":"Kitap / Roman","creative_stage":"Ortak arıyorum"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='creative' AND b.title='[DEMO] Roman taslağı için okur görüşü');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'creative','[DEMO] Dijital çizim kolektifi','Bu bir örnek creative ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Bursa / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"creative_kind":"Çizim","creative_stage":"Ortak arıyorum"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='creative' AND b.title='[DEMO] Dijital çizim kolektifi');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'creative','[DEMO] Kısa film senaryo ekibi','Bu bir örnek creative ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Antalya / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"creative_kind":"Senaryo","creative_stage":"Ortak arıyorum"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='creative' AND b.title='[DEMO] Kısa film senaryo ekibi');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'travel','[DEMO] Tarihi yarımada gezi planı','Bu bir örnek travel ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İstanbul / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"travel_kind":"Şehir gezisi","travel_destination":"Şehir merkezi"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='travel' AND b.title='[DEMO] Tarihi yarımada gezi planı');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'travel','[DEMO] Doğa rotası keşfi','Bu bir örnek travel ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Ankara / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"travel_kind":"Doğa gezisi","travel_destination":"Şehir merkezi"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='travel' AND b.title='[DEMO] Doğa rotası keşfi');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'travel','[DEMO] Günübirlik şehir turu','Bu bir örnek travel ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İzmir / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"travel_kind":"Günübirlik","travel_destination":"Şehir merkezi"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='travel' AND b.title='[DEMO] Günübirlik şehir turu');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'travel','[DEMO] Kültür ve müze rotası','Bu bir örnek travel ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Bursa / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"travel_kind":"Kültür turu","travel_destination":"Şehir merkezi"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='travel' AND b.title='[DEMO] Kültür ve müze rotası');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'travel','[DEMO] Yeni yerler görme planı','Bu bir örnek travel ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Antalya / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"travel_kind":"Uzun seyahat","travel_destination":"Şehir merkezi"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='travel' AND b.title='[DEMO] Yeni yerler görme planı');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'samegender','[DEMO] Halı saha takımı için oyuncular','Bu bir örnek samegender ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İstanbul / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"meeting_kind":"Halı saha"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='samegender' AND b.title='[DEMO] Halı saha takımı için oyuncular');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'samegender','[DEMO] Kütüphanede çalışma grubu','Bu bir örnek samegender ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Ankara / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"meeting_kind":"Ders çalışma"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='samegender' AND b.title='[DEMO] Kütüphanede çalışma grubu');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'samegender','[DEMO] Yürüyüş ve sohbet ekibi','Bu bir örnek samegender ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İzmir / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"meeting_kind":"Yürüyüş"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='samegender' AND b.title='[DEMO] Yürüyüş ve sohbet ekibi');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'samegender','[DEMO] Sinema arkadaşları','Bu bir örnek samegender ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Bursa / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"meeting_kind":"Sinema"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='samegender' AND b.title='[DEMO] Sinema arkadaşları');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'samegender','[DEMO] Haftalık masa oyunu ekibi','Bu bir örnek samegender ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Antalya / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"meeting_kind":"Oyun"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='samegender' AND b.title='[DEMO] Haftalık masa oyunu ekibi');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'skills','[DEMO] İngilizce konuşma pratiği','Bu bir örnek skills ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İstanbul / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"skill_mode":"Karşılıklı öğrenme","skill_topic":"İngilizce / yabancı dil","skill_format":"Çevrimiçi"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='skills' AND b.title='[DEMO] İngilizce konuşma pratiği');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'skills','[DEMO] Temel otomobil bakımı hakkında öğrenme','Bu bir örnek skills ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Ankara / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"skill_mode":"Karşılıklı öğrenme","skill_topic":"Otomobil ve araç bakımı","skill_format":"Çevrimiçi"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='skills' AND b.title='[DEMO] Temel otomobil bakımı hakkında öğrenme');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'skills','[DEMO] Başlangıç seviyesinde yazılım','Bu bir örnek skills ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İzmir / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"skill_mode":"Karşılıklı öğrenme","skill_topic":"Bilgisayar / yazılım","skill_format":"Çevrimiçi"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='skills' AND b.title='[DEMO] Başlangıç seviyesinde yazılım');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'skills','[DEMO] Matematik çalışma arkadaşlığı','Bu bir örnek skills ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Bursa / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"skill_mode":"Karşılıklı öğrenme","skill_topic":"Ders / sınav","skill_format":"Çevrimiçi"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='skills' AND b.title='[DEMO] Matematik çalışma arkadaşlığı');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'skills','[DEMO] Gitar öğrenme paylaşımı','Bu bir örnek skills ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Antalya / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"skill_mode":"Karşılıklı öğrenme","skill_topic":"Sanat / müzik","skill_format":"Çevrimiçi"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='skills' AND b.title='[DEMO] Gitar öğrenme paylaşımı');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'jobs','[DEMO] Kafe için yarı zamanlı ekip örneği','Bu bir örnek jobs ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İstanbul / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"job_mode":"Çalışan arıyorum","job_field":"Örnek sektör","job_work":"Yarı zamanlı"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='jobs' AND b.title='[DEMO] Kafe için yarı zamanlı ekip örneği');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'jobs','[DEMO] Grafik tasarım proje işi örneği','Bu bir örnek jobs ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Ankara / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"job_mode":"Çalışan arıyorum","job_field":"Örnek sektör","job_work":"Proje / freelance"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='jobs' AND b.title='[DEMO] Grafik tasarım proje işi örneği');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'jobs','[DEMO] Yazılım staj fırsatı örneği','Bu bir örnek jobs ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İzmir / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"job_mode":"Çalışan arıyorum","job_field":"Örnek sektör","job_work":"Staj"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='jobs' AND b.title='[DEMO] Yazılım staj fırsatı örneği');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'jobs','[DEMO] Mağaza çalışanı arayışı örneği','Bu bir örnek jobs ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Bursa / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"job_mode":"Çalışan arıyorum","job_field":"Örnek sektör","job_work":"Tam zamanlı"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='jobs' AND b.title='[DEMO] Mağaza çalışanı arayışı örneği');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'jobs','[DEMO] Uzaktan içerik editörü örneği','Bu bir örnek jobs ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Antalya / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"job_mode":"Çalışan arıyorum","job_field":"Örnek sektör","job_work":"Uzaktan"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='jobs' AND b.title='[DEMO] Uzaktan içerik editörü örneği');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'partners','[DEMO] Mobil uygulama için teknik ortak','Bu bir örnek partners ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İstanbul / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"partner_sector":"Mobil uygulama / yazılım","partner_stage":"Fikir aşamasında","partner_count":"2","partner_support":"Birden fazla alanda destek","partner_budget":"Henüz belirlenmedi","partner_collab":"Hibrit / fark etmez","partner_detail_timing":"Ortaklık koşulları netleşince"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='partners' AND b.title='[DEMO] Mobil uygulama için teknik ortak');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'partners','[DEMO] Yeni pizzacı fikri için ortak','Bu bir örnek partners ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Ankara / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"partner_sector":"Yeme-içme / kafe / restoran","partner_stage":"Fikir aşamasında","partner_count":"2","partner_support":"Birden fazla alanda destek","partner_budget":"Henüz belirlenmedi","partner_collab":"Hibrit / fark etmez","partner_detail_timing":"Ortaklık koşulları netleşince"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='partners' AND b.title='[DEMO] Yeni pizzacı fikri için ortak');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'partners','[DEMO] E-ticaret girişimi için ortak','Bu bir örnek partners ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','İzmir / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"partner_sector":"E-ticaret","partner_stage":"Fikir aşamasında","partner_count":"2","partner_support":"Birden fazla alanda destek","partner_budget":"Henüz belirlenmedi","partner_collab":"Hibrit / fark etmez","partner_detail_timing":"Ortaklık koşulları netleşince"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='partners' AND b.title='[DEMO] E-ticaret girişimi için ortak');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'partners','[DEMO] Yerel eğitim projesi için ortak','Bu bir örnek partners ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Bursa / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"partner_sector":"Eğitim","partner_stage":"Fikir aşamasında","partner_count":"2","partner_support":"Birden fazla alanda destek","partner_budget":"Henüz belirlenmedi","partner_collab":"Hibrit / fark etmez","partner_detail_timing":"Ortaklık koşulları netleşince"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='partners' AND b.title='[DEMO] Yerel eğitim projesi için ortak');
INSERT INTO body_listings (user_id,type,title,description,city,extra_info,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers,status,created_at,updated_at) SELECT u.id,'partners','[DEMO] Küçük atölye fikri için ortak','Bu bir örnek partners ilanıdır. ALDZ arayüzünün ve kategoriye özel alanların denenmesi için oluşturulmuştur. Gerçek başvuru veya buluşma değildir.','Antalya / İl geneli','ÖRNEK İLAN — BAŞVURU YAPMAYIN','{"partner_sector":"Üretim / atölye","partner_stage":"Fikir aşamasında","partner_count":"2","partner_support":"Birden fazla alanda destek","partner_budget":"Henüz belirlenmedi","partner_collab":"Hibrit / fark etmez","partner_detail_timing":"Ortaklık koşulları netleşince"}',18,110,'adult',1,'after_ready','owner','active',NOW(),NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM body_listings b WHERE b.user_id=u.id AND b.type='partners' AND b.title='[DEMO] Küçük atölye fikri için ortak');
INSERT INTO events (user_id,title,description,category,starts_at,ends_at,city,venue_general,capacity,age_band,approval_required,visibility,status,created_at,updated_at) SELECT u.id,'[DEMO] Sahil yürüyüşü örnek buluşması','Bu tamamen örnek bir etkinliktir. Gerçek buluşma düzenlenmeyecektir.','outdoors',DATE_ADD(NOW(),INTERVAL 15 DAY),DATE_ADD(NOW(),INTERVAL 15 DAY)+INTERVAL 2 HOUR,'İstanbul','ÖRNEK KONUM — GERÇEK BULUŞMA YOK',10,'adult',1,'members','open',NOW(),NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM events e WHERE e.user_id=u.id AND e.title='[DEMO] Sahil yürüyüşü örnek buluşması');
INSERT INTO events (user_id,title,description,category,starts_at,ends_at,city,venue_general,capacity,age_band,approval_required,visibility,status,created_at,updated_at) SELECT u.id,'[DEMO] Kahve sohbeti örnek etkinliği','Bu tamamen örnek bir etkinliktir. Gerçek buluşma düzenlenmeyecektir.','social',DATE_ADD(NOW(),INTERVAL 22 DAY),DATE_ADD(NOW(),INTERVAL 22 DAY)+INTERVAL 2 HOUR,'Ankara','ÖRNEK KONUM — GERÇEK BULUŞMA YOK',10,'adult',1,'members','open',NOW(),NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM events e WHERE e.user_id=u.id AND e.title='[DEMO] Kahve sohbeti örnek etkinliği');
INSERT INTO events (user_id,title,description,category,starts_at,ends_at,city,venue_general,capacity,age_band,approval_required,visibility,status,created_at,updated_at) SELECT u.id,'[DEMO] Kitap kulübü örnek toplantısı','Bu tamamen örnek bir etkinliktir. Gerçek buluşma düzenlenmeyecektir.','books',DATE_ADD(NOW(),INTERVAL 29 DAY),DATE_ADD(NOW(),INTERVAL 29 DAY)+INTERVAL 2 HOUR,'İzmir','ÖRNEK KONUM — GERÇEK BULUŞMA YOK',10,'adult',1,'members','open',NOW(),NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM events e WHERE e.user_id=u.id AND e.title='[DEMO] Kitap kulübü örnek toplantısı');
INSERT INTO events (user_id,title,description,category,starts_at,ends_at,city,venue_general,capacity,age_band,approval_required,visibility,status,created_at,updated_at) SELECT u.id,'[DEMO] Şehir içi fotoğraf turu örneği','Bu tamamen örnek bir etkinliktir. Gerçek buluşma düzenlenmeyecektir.','creative',DATE_ADD(NOW(),INTERVAL 36 DAY),DATE_ADD(NOW(),INTERVAL 36 DAY)+INTERVAL 2 HOUR,'Bursa','ÖRNEK KONUM — GERÇEK BULUŞMA YOK',10,'adult',1,'members','open',NOW(),NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM events e WHERE e.user_id=u.id AND e.title='[DEMO] Şehir içi fotoğraf turu örneği');
INSERT INTO events (user_id,title,description,category,starts_at,ends_at,city,venue_general,capacity,age_band,approval_required,visibility,status,created_at,updated_at) SELECT u.id,'[DEMO] Masa oyunu buluşması örneği','Bu tamamen örnek bir etkinliktir. Gerçek buluşma düzenlenmeyecektir.','games',DATE_ADD(NOW(),INTERVAL 43 DAY),DATE_ADD(NOW(),INTERVAL 43 DAY)+INTERVAL 2 HOUR,'Antalya','ÖRNEK KONUM — GERÇEK BULUŞMA YOK',10,'adult',1,'members','open',NOW(),NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM events e WHERE e.user_id=u.id AND e.title='[DEMO] Masa oyunu buluşması örneği');


-- ALDZ V32: Her medya tipinde 5 DEMO; gerçek gönderi veya video içeriği değildir.
-- Tekrar içe aktarmada mükerrer kayıt oluşturmaz; eski kullanıcı kayıtlarını silmez.
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] Fotoğraf 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/photo-01.jpg',NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] Fotoğraf 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/photo-01.jpg','photo',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_01' AND p.caption='[DEMO] Fotoğraf 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,NULL FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_01' AND p.caption='[DEMO] Fotoğraf 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] Fotoğraf 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/photo-02.jpg',NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] Fotoğraf 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/photo-02.jpg','photo',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_02' AND p.caption='[DEMO] Fotoğraf 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,NULL FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_02' AND p.caption='[DEMO] Fotoğraf 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] Fotoğraf 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/photo-03.jpg',NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] Fotoğraf 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/photo-03.jpg','photo',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_03' AND p.caption='[DEMO] Fotoğraf 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,NULL FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_03' AND p.caption='[DEMO] Fotoğraf 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] Fotoğraf 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/photo-04.jpg',NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] Fotoğraf 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/photo-04.jpg','photo',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_04' AND p.caption='[DEMO] Fotoğraf 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,NULL FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_04' AND p.caption='[DEMO] Fotoğraf 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] Fotoğraf 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/photo-05.jpg',NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] Fotoğraf 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/photo-05.jpg','photo',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_05' AND p.caption='[DEMO] Fotoğraf 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,NULL FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_05' AND p.caption='[DEMO] Fotoğraf 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] ALDZ Kısa 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/short-01.mp4',NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] ALDZ Kısa 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/short-01.mp4','video',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_01' AND p.caption='[DEMO] ALDZ Kısa 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,'short' FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_01' AND p.caption='[DEMO] ALDZ Kısa 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] ALDZ Kısa 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/short-02.mp4',NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] ALDZ Kısa 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/short-02.mp4','video',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_02' AND p.caption='[DEMO] ALDZ Kısa 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,'short' FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_02' AND p.caption='[DEMO] ALDZ Kısa 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] ALDZ Kısa 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/short-03.mp4',NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] ALDZ Kısa 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/short-03.mp4','video',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_03' AND p.caption='[DEMO] ALDZ Kısa 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,'short' FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_03' AND p.caption='[DEMO] ALDZ Kısa 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] ALDZ Kısa 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/short-04.mp4',NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] ALDZ Kısa 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/short-04.mp4','video',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_04' AND p.caption='[DEMO] ALDZ Kısa 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,'short' FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_04' AND p.caption='[DEMO] ALDZ Kısa 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] ALDZ Kısa 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/short-05.mp4',NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] ALDZ Kısa 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/short-05.mp4','video',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_05' AND p.caption='[DEMO] ALDZ Kısa 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,'short' FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_05' AND p.caption='[DEMO] ALDZ Kısa 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] ALDZ Uzun 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/long-01.mp4',NOW() FROM users u WHERE u.username='body_demo_01' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] ALDZ Uzun 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/long-01.mp4','video',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_01' AND p.caption='[DEMO] ALDZ Uzun 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,'long' FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_01' AND p.caption='[DEMO] ALDZ Uzun 1 — Arkadaşlık ve İstanbul. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] ALDZ Uzun 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/long-02.mp4',NOW() FROM users u WHERE u.username='body_demo_02' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] ALDZ Uzun 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/long-02.mp4','video',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_02' AND p.caption='[DEMO] ALDZ Uzun 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,'long' FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_02' AND p.caption='[DEMO] ALDZ Uzun 2 — Birlikte yürüyüş. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] ALDZ Uzun 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/long-03.mp4',NOW() FROM users u WHERE u.username='body_demo_03' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] ALDZ Uzun 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/long-03.mp4','video',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_03' AND p.caption='[DEMO] ALDZ Uzun 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,'long' FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_03' AND p.caption='[DEMO] ALDZ Uzun 3 — Yaratıcı buluşma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] ALDZ Uzun 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/long-04.mp4',NOW() FROM users u WHERE u.username='body_demo_04' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] ALDZ Uzun 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/long-04.mp4','video',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_04' AND p.caption='[DEMO] ALDZ Uzun 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,'long' FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_04' AND p.caption='[DEMO] ALDZ Uzun 4 — Dayanışma. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);
INSERT INTO social_posts (user_id,caption,media_path,created_at) SELECT u.id,'[DEMO] ALDZ Uzun 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.','uploads/demo_media/long-05.mp4',NOW() FROM users u WHERE u.username='body_demo_05' AND NOT EXISTS (SELECT 1 FROM social_posts p WHERE p.user_id=u.id AND p.caption='[DEMO] ALDZ Uzun 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.');
INSERT INTO body_post_media (post_id,media_path,media_kind,position) SELECT p.id,'uploads/demo_media/long-05.mp4','video',0 FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_05' AND p.caption='[DEMO] ALDZ Uzun 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' AND NOT EXISTS (SELECT 1 FROM body_post_media m WHERE m.post_id=p.id);
INSERT INTO body_post_options (post_id,comments_enabled,video_length) SELECT p.id,0,'long' FROM social_posts p JOIN users u ON u.id=p.user_id WHERE u.username='body_demo_05' AND p.caption='[DEMO] ALDZ Uzun 5 — Topluluk heyecanı. Bu içerik yalnızca ALDZ arayüz testi içindir; gerçek kullanıcı paylaşımı değildir.' ON DUPLICATE KEY UPDATE video_length=VALUES(video_length);


-- ALDZ V34: kayıt sözleşmesi kabul geçmişi (kurulum ve mevcut veritabanlarında güvenli oluşturma)
CREATE TABLE IF NOT EXISTS user_terms_acceptances (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 terms_version VARCHAR(40) NOT NULL,
 accepted_at DATETIME NOT NULL,
 ip_hash CHAR(64) NULL,
 user_agent_hash CHAR(64) NULL,
 INDEX idx_user_terms_user (user_id,accepted_at),
 CONSTRAINT fk_terms_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ALDZ V36: Kombin gönderi türü, stil ve parça açıklamaları (kayıtları silmez).
SET @body_v36_db = DATABASE();
SET @body_v36_has = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@body_v36_db AND TABLE_NAME='body_post_options' AND COLUMN_NAME='post_category');
SET @body_v36_stmt = IF(@body_v36_has=0, 'ALTER TABLE body_post_options ADD COLUMN post_category VARCHAR(20) NOT NULL DEFAULT ''standard''', 'SELECT 1');
PREPARE body_v36_cmd FROM @body_v36_stmt; EXECUTE body_v36_cmd; DEALLOCATE PREPARE body_v36_cmd;
SET @body_v36_has = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@body_v36_db AND TABLE_NAME='body_post_options' AND COLUMN_NAME='outfit_style');
SET @body_v36_stmt = IF(@body_v36_has=0, 'ALTER TABLE body_post_options ADD COLUMN outfit_style VARCHAR(80) NULL', 'SELECT 1');
PREPARE body_v36_cmd FROM @body_v36_stmt; EXECUTE body_v36_cmd; DEALLOCATE PREPARE body_v36_cmd;
SET @body_v36_has = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@body_v36_db AND TABLE_NAME='body_post_options' AND COLUMN_NAME='outfit_details');
SET @body_v36_stmt = IF(@body_v36_has=0, 'ALTER TABLE body_post_options ADD COLUMN outfit_details VARCHAR(500) NULL', 'SELECT 1');
PREPARE body_v36_cmd FROM @body_v36_stmt; EXECUTE body_v36_cmd; DEALLOCATE PREPARE body_v36_cmd;
