@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo ALDZ - WAMP icin hizli acilis
echo.
echo WAMP Apache servisiniz acik olmalidir.
echo Proje C:\wamp64\www\ALDZ icinde bulunmalidir.
echo.
start "" "http://localhost/ALDZ/"
echo Tarayicida http://localhost/ALDZ/ adresi acildi.
echo Acilmiyorsa WAMP'i baslatin ve klasor yolunu kontrol edin.
pause
