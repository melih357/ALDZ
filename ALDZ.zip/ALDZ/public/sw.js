const CACHE = 'aldz-static-v1';
const BASE = new URL('./', self.registration.scope).pathname;
const STATIC = ['manifest.json','css/aldz.css','js/aldz.js','icons/aldz-192.png','offline.html'].map(path => BASE + path);
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(STATIC)).then(() => self.skipWaiting())); });
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', event => {
  const request = event.request; const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  // Never cache authenticated HTML, messages, APIs, admin pages or POST-like user data.
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(() => caches.match(BASE + 'offline.html'))); return;
  }
  if (['style','script','image'].includes(request.destination) || url.pathname.endsWith('/manifest.json')) {
    event.respondWith(caches.match(request).then(cached => cached || fetch(request).then(response => {
      if (response.ok && !response.headers.get('Cache-Control')?.includes('private')) { const copy=response.clone(); caches.open(CACHE).then(cache=>cache.put(request,copy)); }
      return response;
    })));
  }
});
