# ALDZ V8 - Sayfa açılışı ve navigasyon düzeltmeleri

- `social.php` Keşfet, Profilim ve Ayarlar için tek seferde tüm sorguları yapmıyor. Ayarlar sayfası gereksiz fotoğraf/gönderi sorgularından bağımsız; profil dışındaki sayfalarda profil sayaç sorguları atlandı.
- Ayarlar, profil, keşfet ve hikâye sayfaları için sorgu hatalarında beyaz ekran yerine bilgilendirme paneli oluşturuldu. Ayrıntı sunucu logunda tutulur.
- Profil sayfası açılırken genel keşfet akışının yeniden çizilmesi engellendi.
- `social.php?view=settings#privacy` bağlantısının doğru başlığa gitmesi için `id=privacy` eklendi.
- Hamburger menü durumu için erişilemeyen localStorage durumunda JavaScript'in durması engellendi.
- V8 PWA servis çalışanı önbellek sürümü güncellendi.
- ZIP içindeki SQL dosyası ve mevcut kullanıcı kayıtları değiştirilmedi.

**Sınır:** Bu sürümde gerçek WAMP + MySQL oturumu ile uçtan uca kullanım testi yapılmadı. Dışa açık üretim kullanımı için ayrıca kontrol gerekir.
