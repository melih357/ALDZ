# ALDZ V19 — Değişiklikler

- Aynı Çevreden: aynı cinsiyette sosyal buluşma kategorisi, tür, tarih, bölge, kişi sayısı.
- Birbirimize Öğretelim: yardım arama, yardım sunma, konu/seviye/iletişim biçimi.
- İş & Fırsatlar: iş arayan/çalışan arayan, sektör, çalışma türü ve deneyim. 18+ sınırı.
- İş arayan ilanında CV metni **veya** PDF zorunlu; çalışana başvuranlarda da CV metni veya PDF zorunlu.
- CV metni/PDF veritabanında özel tabloda tutulur; yalnızca ilan sahibi ve izinli katılımcılar erişebilir.
- Aynı cinsiyet ilanlarında ilan sahibinin ve katılımcının beyanları eşleşir; sosyal yaş ayrımı devam eder.
- Mevcut ilan, soru-cevap, onay ve sohbet akışları yeni kategorilere bağlandı.

## Sınırlar

Gerçek kimlik/cinsiyet doğrulaması yapılmaz. Bu nedenle güvenlik garantisi verilmez. İş başvurularında ayrımcılığı önleme, işveren doğrulaması ve hukuki uygunluk ayrıca ele alınmalıdır.
