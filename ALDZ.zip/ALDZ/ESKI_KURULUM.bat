@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title ALDZ - Kurulum ve Composer

set "LOG=%~dp0KURULUM_LOG.txt"
set "PHP_EXE="
echo ALDZ kurulum gunlugu - %DATE% %TIME%>"%LOG%"
echo [BILGI] Calisma klasoru: %CD%>>"%LOG%"
echo [BILGI] composer.json kontrol ediliyor...>>"%LOG%"

if not exist "%~dp0composer.json" (
  echo [HATA] composer.json bu klasorde bulunamadi.
  echo ZIP icindeki ALDZ klasorunun tum icerigini C:\wamp64\www\ALDZ icine cikartin.
  echo Beklenen: C:\wamp64\www\ALDZ\composer.json
  echo [HATA] composer.json bulunamadi.>>"%LOG%"
  pause
  exit /b 1
)
if not exist "%~dp0artisan" (
  echo [HATA] artisan dosyasi bulunamadi. Yanlis klasordesiniz.
  echo [HATA] artisan bulunamadi.>>"%LOG%"
  pause
  exit /b 1
)

rem Find the first usable WAMP PHP >= 8.2, then PATH PHP.
for /d %%D in ("C:\wamp64\bin\php\php*") do (
  if exist "%%~fD\php.exe" (
    "%%~fD\php.exe" -r "exit(version_compare(PHP_VERSION,'8.2.0','>=') ? 0 : 1);" >nul 2>&1
    if not errorlevel 1 set "PHP_EXE=%%~fD\php.exe"
  )
)
if not defined PHP_EXE for /d %%D in ("C:\wamp\bin\php\php*") do (
  if exist "%%~fD\php.exe" (
    "%%~fD\php.exe" -r "exit(version_compare(PHP_VERSION,'8.2.0','>=') ? 0 : 1);" >nul 2>&1
    if not errorlevel 1 set "PHP_EXE=%%~fD\php.exe"
  )
)
if not defined PHP_EXE (
  for /f "delims=" %%P in ('where php 2^>nul') do (
    "%%P" -r "exit(version_compare(PHP_VERSION,'8.2.0','>=') ? 0 : 1);" >nul 2>&1
    if not errorlevel 1 if not defined PHP_EXE set "PHP_EXE=%%P"
  )
)
if not defined PHP_EXE (
  echo [HATA] PHP 8.2+ bulunamadi. WAMP menusu > PHP > Version kismina bakip PHP 8.2 veya ustunu secin.
  echo [HATA] PHP 8.2+ bulunamadi.>>"%LOG%"
  pause
  exit /b 1
)

echo [BILGI] Kullanilan PHP: "%PHP_EXE%"
echo [BILGI] Kullanilan PHP: "%PHP_EXE%">>"%LOG%"
"%PHP_EXE%" -v >>"%LOG%" 2>&1
"%PHP_EXE%" -m > "%TEMP%\ALDZ_php_modules.txt" 2>&1
echo [BILGI] PHP uzantilari:
type "%TEMP%\ALDZ_php_modules.txt"
type "%TEMP%\ALDZ_php_modules.txt" >>"%LOG%"

set "MISSING_EXT="
for %%E in (openssl pdo_mysql mbstring tokenizer xml ctype fileinfo) do (
  findstr /i /x "%%E" "%TEMP%\ALDZ_php_modules.txt" >nul
  if errorlevel 1 set "MISSING_EXT=!MISSING_EXT! %%E"
)
if defined MISSING_EXT (
  echo [HATA] Eksik PHP uzantilari:!MISSING_EXT!
  echo WAMP > PHP > PHP extensions menusunden etkinlestirin, sonra yeniden calistirin.
  echo [HATA] Eksik uzantilari:!MISSING_EXT!>>"%LOG%"
  pause
  exit /b 1
)

if not exist "%~dp0.env" (
  if not exist "%~dp0.env.example" (
    echo [HATA] .env.example bulunamadi.
    echo [HATA] .env.example bulunamadi.>>"%LOG%"
    pause
    exit /b 1
  )
  copy /y "%~dp0.env.example" "%~dp0.env" >>"%LOG%" 2>&1
  if errorlevel 1 goto env_error
  echo [BILGI] .env olusturuldu.>>"%LOG%"
)

set "COMPOSER_PHAR=%~dp0composer.phar"
if not exist "%COMPOSER_PHAR%" (
  echo [BILGI] Composer indiriliyor. Internet baglantisi gerekli...
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -UseBasicParsing -Uri 'https://getcomposer.org/download/latest-stable/composer.phar' -OutFile '%COMPOSER_PHAR%'; if ((Get-Item '%COMPOSER_PHAR%').Length -lt 100000) { throw 'Indirilen composer.phar dosyasi beklenenden kucuk.' }; exit 0 } catch { $_ | Out-String | Add-Content -Path '%LOG%'; exit 1 }" >>"%LOG%" 2>&1
  if errorlevel 1 goto download_error
)

echo [BILGI] Composer surumu kontrol ediliyor...
"%PHP_EXE%" "%COMPOSER_PHAR%" --version >>"%LOG%" 2>&1
if errorlevel 1 goto composer_phar_error

echo [BILGI] Composer install calisiyor; ilk kurulum birkac dakika surebilir.
echo [BILGI] composer install baslatildi>>"%LOG%"
"%PHP_EXE%" "%COMPOSER_PHAR%" install --no-interaction --prefer-dist --no-progress --no-scripts >>"%LOG%" 2>&1
if errorlevel 1 goto composer_error

if not exist "%~dp0vendor\autoload.php" (
  echo [HATA] Composer calisti ama vendor\autoload.php olusmadi.
  echo Gunluk dosyasi: "%LOG%"
  echo [HATA] vendor\autoload.php olusmadi.>>"%LOG%"
  pause
  exit /b 1
)

rem Run Laravel package discovery only after vendor is present.
"%PHP_EXE%" artisan package:discover --ansi >>"%LOG%" 2>&1
if errorlevel 1 (
  echo [UYARI] Laravel package:discover hata verdi. Ayrinti KURULUM_LOG.txt dosyasinda.
  echo [UYARI] package:discover hata verdi.>>"%LOG%"
)

findstr /b /c:"APP_KEY=base64:" "%~dp0.env" >nul
if errorlevel 1 (
  "%PHP_EXE%" artisan key:generate --force >>"%LOG%" 2>&1
  if errorlevel 1 goto key_error
)

echo.
echo [BASARILI] Composer bagimliliklari yuklendi.
echo [BASARILI] vendor\autoload.php bulundu.
echo Simdi http://localhost/ALDZ/frontend adresini acin.
echo Gunluk: "%LOG%"
echo [BASARILI] vendor/autoload.php mevcut>>"%LOG%"
pause
exit /b 0

:download_error
echo [HATA] Composer indirilemedi. Internet baglantisini kontrol edin.
echo Hata ayrintisi: "%LOG%"
pause
exit /b 1
:composer_phar_error
echo [HATA] composer.phar calistirilamadi. KURULUM_LOG.txt dosyasini gonderin.
pause
exit /b 1
:composer_error
echo [HATA] Composer bagimliliklarini yukleyemedi.
echo KURULUM_LOG.txt dosyasindaki son 30 satiri gonderin.
pause
exit /b 1
:key_error
echo [HATA] APP_KEY olusturulamadi. KURULUM_LOG.txt dosyasini kontrol edin.
pause
exit /b 1
:env_error
echo [HATA] .env dosyasi olusturulamadi.
pause
exit /b 1
