<?php
namespace Tests\Feature;
use Tests\TestCase;
class HomePageTest extends TestCase
{
    public function test_home_page_returns_success(): void
    {
        $response = $this->get('/');
        $response->assertOk();
        $response->assertSee('Hayat,');
    }
}
