@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist vendor\autoload.php (echo [HATA] Bagimliliklar yok. Once KURULUM.bat calistirin.& pause & exit /b 1)
if not exist .env (echo [HATA] .env yok. Once KURULUM.bat calistirin.& pause & exit /b 1)
set "PHP_EXE="
for /f "delims=" %%P in ('where php 2^>nul') do if not defined PHP_EXE set "PHP_EXE=%%P"
if not defined PHP_EXE for /d %%D in ("C:\wamp64\bin\php\php*") do if exist "%%~fD\php.exe" set "PHP_EXE=%%~fD\php.exe"
if not defined PHP_EXE (echo [HATA] PHP bulunamadi. Once KURULUM.bat calistirin.& pause & exit /b 1)
findstr /r /c:"^APP_KEY=base64:..*" .env >nul
if errorlevel 1 (
  "%PHP_EXE%" artisan key:generate --force
  if errorlevel 1 (echo [HATA] Laravel anahtari olusturulamadi.& pause & exit /b 1)
) else echo [BILGI] Mevcut APP_KEY korundu.
echo Not: Veritabani semasi database.sql dosyasindan yuklenir; burada migration calistirilmaz.
echo ALDZ yerel sunucusu baslatiliyor: http://127.0.0.1:8000
echo Durdurmak icin CTRL+C kullanin.
"%PHP_EXE%" artisan serve --host=127.0.0.1 --port=8000
