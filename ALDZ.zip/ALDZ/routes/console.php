<?php
use Illuminate\Support\Facades\Artisan;
Artisan::command('body:about', function () { $this->info('ALDZ kapalı test sürümü'); });
