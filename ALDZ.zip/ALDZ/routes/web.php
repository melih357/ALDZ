<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ModuleController;
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/saglik', fn () => response()->json(['app'=>'ALDZ','status'=>'ok','mode'=>config('app.env')==='production'?'production':'closed-beta']))->name('health.public');
Route::middleware(['web'])->group(function () {
    Route::get('/moduller/{module}', [ModuleController::class, 'show'])->whereIn('module', ['aktivite','ev-arkadasi','ucretsiz-esya','deneyim','etkinlikler','yaratici-kose','seyahat'])->name('modules.show');
});
