@extends('layouts.app')
@section('title', $module['title'].' — ALDZ')
@section('content')
<section class="wrap module-detail"><a class="back-link" href="{{ route('home') }}">← Ana sayfaya dön</a><div class="detail-symbol">{{ $module['icon'] }}</div><div class="eyebrow">ALDZ MODÜLÜ</div><h1>{{ $module['title'] }}</h1><p class="lead">{{ $module['description'] }}</p><div class="notice-panel"><strong>Bu modülün ekran iskeleti hazır.</strong><p>Bu teslimde veritabanı şeması ve mimari başlangıç dosyaları bulunur. İlan oluşturma, başvuru, mesajlaşma ve rol tabanlı işlemler henüz uçtan uca uygulanıp test edilmiş değildir; bu nedenle bu sayfa işlem yapılabiliyormuş gibi davranmaz.</p></div><a class="btn btn-primary" href="{{ route('home') }}#kesfet">Diğer modüller <span>↗</span></a></section>
@endsection
