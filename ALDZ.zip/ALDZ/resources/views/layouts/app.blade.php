<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#101522"><meta name="aldz-base" content="{{ rtrim(request()->getBaseUrl(), '/') }}/"><meta name="description" content="ALDZ — Birlikte daha güzel.">
  <link rel="manifest" href="{{ asset('manifest.json') }}"><link rel="icon" href="{{ asset('icons/aldz-192.png') }}" type="image/svg+xml">
  <link rel="stylesheet" href="{{ asset('css/aldz.css') }}"><title>@yield('title', 'ALDZ — Birlikte daha güzel')</title>
</head>
<body>
<header class="topbar"><a class="brand" href="{{ route('home') }}"><span class="brand-mark">B</span><span>ALDZ<small>Birlikte daha güzel.</small></span></a><nav class="topnav"><a href="{{ route('home') }}#kesfet">Keşfet</a><a href="{{ route('home') }}#guvenlik">Güvenlik</a><span class="beta">KAPALI TEST</span></nav></header>
<main>@yield('content')</main>
<footer class="footer"><span>ALDZ © {{ date('Y') }}</span><span>Güvenli topluluklar, gerçek bağlantılar.</span></footer>
<div id="offline-toast" class="offline-toast" hidden>Bağlantı yok. Sunucu işlemleri şu anda kullanılamaz.</div>
<script src="{{ asset('js/aldz.js') }}" defer></script>
</body></html>
