@extends('layouts.app')
@section('title','ALDZ — Birlikte daha güzel')
@section('content')
<section class="hero wrap">
 <div class="hero-copy"><div class="eyebrow"><span class="pulse"></span> DAHA FAZLA GERÇEK BAĞLANTI</div>
 <h1>Hayat, <em>birlikte</em><br>güzelleşir.</h1><p class="lead">Ortak ilgi alanlarını keşfet. Bir aktiviteye katıl. Bir etkinlik başlat. Yeni insanlarla, sana uygun ve güvenli bir şekilde tanış.</p>
 <div class="hero-actions"><a class="btn btn-primary" href="#kesfet">ALDZ'yi keşfet <span>↗</span></a><a class="btn btn-ghost" href="#guvenlik">Güvenlik yaklaşımımız</a></div>
 <div class="trust-line"><span>✓ Yaş grubu koruması</span><span>✓ Gizlilik odaklı</span><span>✓ Ücretsiz paylaşım</span></div>
 </div><div class="hero-art" aria-label="ALDZ toplulukları temsili grafik"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><div class="orb orb-a">✦</div><div class="orb orb-b">♫</div><div class="orb orb-c">↗</div><div class="orb orb-d">♡</div><div class="core"><div class="core-logo">B</div><strong>Birlikte.</strong><small>aynı frekansta</small></div><div class="art-caption">ORTAK İLGİ · GERÇEK HAYAT</div></div>
</section>
<section id="kesfet" class="wrap section"><div class="section-head"><div><div class="eyebrow">ALDZ DÜNYASI</div><h2>Sana göre bir topluluk var.</h2></div><p>Bir yerden başla. Gerisi ortak ilgi alanlarında buluşur.</p></div>
<div class="module-grid">
<a class="module-card card-purple" href="{{ route('modules.show','aktivite') }}"><span class="module-icon">✦</span><span class="card-number">01 / AKTİVİTE</span><h3>Birlikte yap</h3><p>Kahve, yürüyüş, spor ve daha fazlası için ekip bul.</p><span class="card-arrow">↗</span></a>
<a class="module-card card-green" href="{{ route('modules.show','ev-arkadasi') }}"><span class="module-icon">⌂</span><span class="card-number">02 / YAŞAM</span><h3>Ev arkadaşı</h3><p>Yaşam tarzı ve ortak giderlerde uyum yakala.</p><span class="card-arrow">↗</span></a>
<a class="module-card card-orange" href="{{ route('modules.show','ucretsiz-esya') }}"><span class="module-icon">♡</span><span class="card-number">03 / PAYLAŞIM</span><h3>Ücretsiz paylaş</h3><p>Kullanmadığın eşyaya yeni bir hayat ver.</p><span class="card-arrow">↗</span></a>
<a class="module-card card-blue" href="{{ route('modules.show','deneyim') }}"><span class="module-icon">☷</span><span class="card-number">04 / TOPLULUK</span><h3>Deneyimlerini anlat</h3><p>Sor, yanıtla, deneyimlerden birlikte öğren.</p><span class="card-arrow">↗</span></a>
<a class="module-card card-pink" href="{{ route('modules.show','etkinlikler') }}"><span class="module-icon">◎</span><span class="card-number">05 / BULUŞMA</span><h3>Etkinlik oluştur</h3><p>Bir plan yap, insanları bir araya getir.</p><span class="card-arrow">↗</span></a>
<a class="module-card card-yellow" href="{{ route('modules.show','yaratici-kose') }}"><span class="module-icon">✎</span><span class="card-number">06 / ÜRETİM</span><h3>Birlikte üret</h3><p>Şiir, hikâye ve fikirleri ortak eserlere dönüştür.</p><span class="card-arrow">↗</span></a>
<a class="module-card card-teal" href="{{ route('modules.show','seyahat') }}"><span class="module-icon">↗</span><span class="card-number">07 / KEŞİF</span><h3>Şehir ve seyahat</h3><p>Yolunu benzer tarihlerde yola çıkanlarla kesiştir.</p><span class="card-arrow">↗</span></a>
</div></section>
<section id="guvenlik" class="security-band"><div class="wrap security-inner"><div><div class="eyebrow">GÜVEN TASARIMIN PARÇASI</div><h2>Önce güven.<br><em>Sonra bağlantı.</em></h2></div><div class="security-points"><div><b>01</b><span><strong>Yaş grubu izolasyonu</strong><small>13–17 ve 18+ kullanıcılar ayrı tutulur.</small></span></div><div><b>02</b><span><strong>Kontrol sende</strong><small>Engelleme, gizlilik ve bildirim araçları.</small></span></div><div><b>03</b><span><strong>Topluluk denetimi</strong><small>Şikâyet, moderasyon ve itiraz akışı.</small></span></div></div></div></section>
<section class="wrap beta-note"><span class="beta-icon">i</span><div><strong>Kapalı test sürümü</strong><p>Bu paket geliştirme başlangıcıdır. Kayıt, giriş ve modül işlemleri tamamlanıp test edilmeden gerçek kullanıcılarla yayına alınmamalıdır.</p></div></section>
@endsection
