# ALDZ – GitHub ve WAMP kurulumu

Bu paket GitHub deposuna yuklenebilecek kaynak kodu icerir. GitHub uzerinde depoyu **Private** secin; Public yaparsaniz kaynak kodu herkes gorebilir.

## GitHub'a yukleme
1. ZIP'i ayiklayin. `ALDZ` klasorunu acin.
2. GitHub'da yeni bir **Private** repository acin (orn. `aldz`).
3. `uploading an existing file` ile **ALDZ klasorunun icindekileri** yukleyin (ZIP'i tek dosya olarak yuklemek yerine).
4. `.env`, gercek kullanici medyasi, sifreler ve veritabani yedeklerini yuklemeyin.

## WAMP'de sifirdan kurulum
1. `ALDZ` klasorunu `C:\wamp64\www\ALDZ` icine yerlestirin.
2. phpMyAdmin ile ana dizindeki `database.sql` dosyasini ice aktarin; veritabani adi `aldz`.
3. `http://localhost/ALDZ/frontend/` adresini acin.
4. Ortam ayarlarini `.env.example` ve `private/db.php` ile yapilandirin.

## Var olan BODY kurulumundan gecis
- Ilk once veritabanini ve yuklenen dosyalari yedekleyin.
- Eski `body` veritabaninizdaki kayitlar yeni `aldz` adina **otomatik tasinmaz**. Veri tasimak icin disari aktarip `aldz` altina ice aktarin; yeni bos `database.sql` dosyasini mevcut verilerin ustune rastgele uygulamayin.
- Mevcut veritabaninin ic tablo adlari ve PHP `body_*` yardimci fonksiyonlari veri ve uygulama uyumlulugu icin korunmustur; bunlar gosterilen marka adi degildir.
- Daha onceki PWA kurulumunda eski uygulamayi kaldirip ALDZ PWA'yi tekrar kurmak gerekebilir.

Not: Paket statik soz dizimi/icerik kontrollerinden gecirilmistir; PHP/MySQL/WAMP uzerinde canli entegrasyon testleri bu ortamda yapilmamistir.
