<?php
declare(strict_types=1);
function body_db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    // WAMP defaults; configure DB credentials with environment variables as needed.
    $host = getenv('ALDZ_DB_HOST') ?: '127.0.0.1';
    $port = getenv('ALDZ_DB_PORT') ?: '3306';
    $name = getenv('ALDZ_DB_NAME') ?: 'aldz';
    $user = getenv('ALDZ_DB_USER') ?: 'root';
    $password = getenv('ALDZ_DB_PASSWORD');
    if ($password === false) $password = '';
    $dsn = 'mysql:host='.$host.';port='.$port.';dbname='.$name.';charset=utf8mb4';
    $pdo = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}
