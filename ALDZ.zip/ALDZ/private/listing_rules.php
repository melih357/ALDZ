<?php
declare(strict_types=1);
function body_listing_age(array $u): int {return (int)(new DateTimeImmutable((string)$u['birth_date']))->diff(new DateTimeImmutable('today'))->y;}
function body_listing_allowed(array $listing,array $user): bool {
 $age=body_listing_age($user);
 return ($listing['age_band']??'')===($user['age_band']??'') && $age>=(int)$listing['min_age'] && $age<=(int)$listing['max_age'];
}
function body_listing_city($v):string{return mb_strtolower(trim(preg_replace('/\s*\/.*$/u','',(string)$v)));}
function body_listing_flash(string $message):void {$_SESSION['listing_flash']=$message;}

/** Same-gender social activities must match the creator's recorded gender. */
function body_listing_gender_allowed(array $listing, array $viewer, ?PDO $db=null): bool {
 if(($listing['type']??'')!=='samegender')return true;
 $gender=(string)($viewer['gender']??'undisclosed');
 if(!in_array($gender,['woman','man'],true))return false;
 $ownerGender=(string)($listing['owner_gender']??'');
 if($ownerGender===''){
  if(!$db)$db=body_db();
  $q=$db->prepare('SELECT gender FROM users WHERE id=?');$q->execute([(int)$listing['user_id']]);
  $ownerGender=(string)($q->fetchColumn()?:'undisclosed');
 }
 return $gender===$ownerGender;
}
