<?php
declare(strict_types=1);
/** A notification is persisted for the recipient only. No payload from the sender is rendered as HTML. */
function body_emit_notification(PDO $db, int $recipient, int $actor, string $type, string $title, string $message): void {
 if($recipient<=0 || $recipient===$actor)return;
 $q=$db->prepare('INSERT INTO notifications(user_id,type,title,body,created_at) VALUES(?,?,?,?,NOW())');
 $q->execute([$recipient,$type,mb_substr($title,0,160),mb_substr($message,0,500)]);
}
