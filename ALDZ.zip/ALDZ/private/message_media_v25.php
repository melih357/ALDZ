<?php
declare(strict_types=1);
require_once __DIR__.'/body_upload_validation.php';
require_once __DIR__.'/social_helpers.php';
function body_chat_peer(PDO $db,int $chat,int $me): int {
 $q=$db->prepare("SELECT cp2.user_id FROM conversations c JOIN conversation_participants cp1 ON cp1.conversation_id=c.id AND cp1.user_id=? AND cp1.status='active' JOIN conversation_participants cp2 ON cp2.conversation_id=c.id AND cp2.user_id<>? AND cp2.status='active' WHERE c.id=? AND c.kind='direct' LIMIT 1");
 $q->execute([$me,$me,$chat]);return (int)$q->fetchColumn();
}
function body_chat_allowed(PDO $db,int $chat,int $me): bool {
 $peer=body_chat_peer($db,$chat,$me);
 if(!$peer || !body_same_age_band($peer,$me) || !social_can_view($peer,$me) || !social_can_view($me,$peer))return false;
 $q=$db->prepare("SELECT 1 FROM social_follows WHERE ((follower_id=? AND following_id=?) OR (follower_id=? AND following_id=?)) AND status='accepted' LIMIT 1");
 $q->execute([$peer,$me,$me,$peer]);return (bool)$q->fetchColumn();
}
function body_private_file_path(string $key): string {
 if(!preg_match('/^[a-f0-9]{40}\.(jpg|png|webp|pdf|txt|ogg|webm|mp3|m4a|wav|mp4)$/D',$key))throw new RuntimeException('Geçersiz dosya.');
 return __DIR__.'/media_v25/'.$key;
}
function body_save_private(array $file,string $kind): array {
 if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK || !is_uploaded_file((string)($file['tmp_name']??'')))throw new RuntimeException('Dosya yüklenemedi.');
 $limit=($kind==='video'?48:($kind==='voice'?4:($kind==='sticker'?2:8)))*1024*1024;
 if((int)$file['size']<1 || (int)$file['size']>$limit)throw new RuntimeException('Dosya boyutu sınırı aşıldı.');
 $mime=body_detect_mime($file['tmp_name']);
 $allowed=['image'=>['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'], 'sticker'=>['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'], 'video'=>['video/mp4'=>'mp4','video/webm'=>'webm'], 'file'=>['application/pdf'=>'pdf','text/plain'=>'txt','image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'], 'voice'=>['audio/wav'=>'wav','audio/x-wav'=>'wav','audio/webm'=>'webm','video/webm'=>'webm','audio/ogg'=>'ogg','application/ogg'=>'ogg','audio/mpeg'=>'mp3','audio/mp4'=>'m4a','audio/x-m4a'=>'m4a']];
 $ext=$allowed[$kind][$mime]??null;
 if(!$ext)throw new RuntimeException('Bu dosya türü kabul edilmiyor.');
 if(in_array($kind,['image','sticker'],true) && !@getimagesize($file['tmp_name']))throw new RuntimeException('Geçersiz görsel.');
 $name=bin2hex(random_bytes(20)).'.'.$ext;
 $dir=__DIR__.'/media_v25';if(!is_dir($dir)&&!mkdir($dir,0700,true))throw new RuntimeException('Özel dosya klasörü oluşturulamadı.');
 if(!move_uploaded_file($file['tmp_name'],$dir.'/'.$name))throw new RuntimeException('Dosya kaydedilemedi.');
 @chmod($dir.'/'.$name,0600);
 $original=mb_substr(basename(str_replace('\\','/',(string)($file['name']??'dosya'))),0,180);
 return ['key'=>$name,'mime'=>$mime,'size'=>(int)$file['size'],'name'=>$original,'path'=>$dir.'/'.$name];
}
function body_chat_messages(PDO $db,int $chat,int $me): array {
 $q=$db->prepare("SELECT m.id,m.sender_id,m.body,m.created_at,a.id AS attachment_id,a.kind AS attachment_kind,a.mime AS attachment_mime,a.original_name AS attachment_name,a.view_once,a.viewed_at,(SELECT GROUP_CONCAT(CONCAT(r.emoji,':',r.user_id) SEPARATOR '|') FROM body_message_reactions r WHERE r.message_id=m.id) AS reactions FROM messages m LEFT JOIN body_message_attachments a ON a.message_id=m.id WHERE m.conversation_id=? AND m.deleted_at IS NULL ORDER BY m.id DESC LIMIT 100");
 $q->execute([$chat]);$rows=array_reverse($q->fetchAll());
 foreach($rows as &$row){$row['id']=(int)$row['id'];$row['sender_id']=(int)$row['sender_id'];if($row['attachment_id']){$row['attachment_id']=(int)$row['attachment_id'];$row['attachment_url']='message_file_v25.php?id='.$row['attachment_id'];if(!empty($row['view_once']) && !empty($row['viewed_at']))$row['attachment_url']=null;} $row['reactions']=$row['reactions']??'';}unset($row);
 return $rows;
}
