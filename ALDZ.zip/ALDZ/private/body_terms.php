<?php
/** ALDZ terms document identifier. Change on substantive updates. */
const ALDZ_TERMS_VERSION = '2026-11-05.1';
