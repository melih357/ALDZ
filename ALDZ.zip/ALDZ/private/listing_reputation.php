<?php
declare(strict_types=1);
/** Only participation-based community reviews; not identity verification. */
function body_reputation(PDO $db,int $userId): array {
 $q=$db->prepare('SELECT COUNT(*) AS total, COUNT(DISTINCT listing_id) AS distinct_listings, COUNT(DISTINCT reviewer_id) AS distinct_reviewers, ROUND(AVG(rating),1) AS average, SUM(CASE WHEN safe_experience=1 THEN 1 ELSE 0 END) AS positive_safe FROM body_listing_reviews WHERE reviewed_user_id=?');
 $q->execute([$userId]);$s=$q->fetch(PDO::FETCH_ASSOC)?:[];
 $n=(int)($s['total']??0);$unique=(int)($s['distinct_listings']??0);$uniqueReviewers=(int)($s['distinct_reviewers']??0);$avg=(float)($s['average']??0);$safe=(int)($s['positive_safe']??0);
 $badge='';if($unique>=5 && $uniqueReviewers>=5 && $n>=5 && $avg>=4.5 && $safe/$n>=0.8)$badge='Toplulukça yüksek puanlı';elseif($unique>=3 && $uniqueReviewers>=3 && $n>=3 && $avg>=4.0 && $safe/$n>=0.7)$badge='Olumlu topluluk değerlendirmesi';
 return ['count'=>$n,'listings'=>$unique,'average'=>$avg,'safe'=>$safe,'badge'=>$badge];
}
