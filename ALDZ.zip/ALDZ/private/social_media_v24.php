<?php
declare(strict_types=1);
require_once __DIR__.'/body_upload_validation.php';
function body42_ini_bytes(string $value): int {
 $value=trim($value);if($value==='')return 0;
 $unit=strtolower(substr($value,-1));$amount=(float)$value;
 if($unit==='g')return (int)($amount*1024*1024*1024);
 if($unit==='m')return (int)($amount*1024*1024);
 if($unit==='k')return (int)($amount*1024);
 return (int)$amount;
}
function body42_upload_error(int $error): string {
 return match($error){
  UPLOAD_ERR_INI_SIZE,UPLOAD_ERR_FORM_SIZE=>'Dosya PHP yükleme sınırını aşıyor. WAMP PHP ayarlarında upload_max_filesize=256M ve post_max_size=300M yapıp Apache hizmetini yeniden başlat.',
  UPLOAD_ERR_PARTIAL=>'Video eksik yüklendi. Bağlantıyı kontrol edip tekrar dene.',
  UPLOAD_ERR_NO_FILE=>'Video veya fotoğraf seçilmedi.',
  UPLOAD_ERR_NO_TMP_DIR=>'Sunucuda geçici yükleme klasörü bulunamadı.',
  UPLOAD_ERR_CANT_WRITE=>'Sunucu yüklenen dosyayı diske yazamadı; klasör izinlerini ve boş alanı kontrol et.',
  UPLOAD_ERR_EXTENSION=>'Bir PHP eklentisi yüklemeyi engelledi.',
  default=>'Medya yükleme hatası (kod: '.$error.').'
 };
}
const ALDZ_VIDEO_MAX_BYTES = 1073741824; // 1 GiB; bounded for storage and abuse control
function body24_upload(string $key, bool $video=false, string $videoLength="short"): array {
 $f=$_FILES[$key]??null;
 if(!is_array($f))throw new RuntimeException('Medya seçilemedi.');
 if(($f['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)throw new RuntimeException(body42_upload_error((int)($f['error']??UPLOAD_ERR_NO_FILE)));
 $max=$video?ALDZ_VIDEO_MAX_BYTES:8*1024*1024;
 if((int)$f['size']<=0||(int)$f['size']>$max)throw new RuntimeException($video?('Video en fazla 1 GB olabilir. Daha büyük videoları sıkıştır.'):'Fotoğraf en fazla 8 MB olmalı.');
 $mime=body_detect_mime($f['tmp_name']);
 $ext=($video?['video/mp4'=>'mp4','video/webm'=>'webm']:['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'])[$mime]??null;
 if(!$ext)throw new RuntimeException('Desteklenmeyen medya türü. JPG, PNG, WEBP, MP4 veya WEBM kullan.');
 if(!$video&&!@getimagesize($f['tmp_name']))throw new RuntimeException('Görsel doğrulanamadı.');
 if($video){$seconds=body_video_duration($f['tmp_name'],$mime);if($seconds===null)throw new RuntimeException('Video süresi okunamadı. MP4 kullan veya sunucuya FFprobe kurup ALDZ_FFPROBE yolunu tanımla.');
 if($videoLength==='short' && $seconds>300)throw new RuntimeException('Kısa video en fazla 5 dakika olabilir.');
 if($videoLength==='long' && $seconds<300)throw new RuntimeException('Uzun video en az 5 dakika olmalı.');}
 $dir=__DIR__.'/../frontend/uploads';if(!is_dir($dir)&&!mkdir($dir,0755,true))throw new RuntimeException('Yükleme klasörü oluşturulamadı.');
 $name=bin2hex(random_bytes(18)).'.'.$ext;
 if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$name))throw new RuntimeException('Dosya yüklenemedi.');
 return ['path'=>'uploads/'.$name,'kind'=>$video?'video':'photo'];
}
function body24_media(PDO $db,int $post):array {
 $q=$db->prepare('SELECT media_path,media_kind FROM body_post_media WHERE post_id=? ORDER BY position,id');$q->execute([$post]);return $q->fetchAll();
}
function body24_mentions(string $caption, PDO $db, int $by, int $post):void {
 if(!preg_match_all('/(?<![\pL\pN_.])@([a-z][a-z0-9._]{3,29})/ui',$caption,$matches))return;
 foreach(array_unique($matches[1]) as $username){
  $q=$db->prepare("SELECT id FROM users WHERE username=? AND status='active'");$q->execute([$username]);$id=(int)$q->fetchColumn();
  if($id && $id!==$by && social_can_view($by,$id))social_notify($id,$by,'mention','Bir gönderide etiketlendin.');
 }
}
function body24_caption(string $caption):string {
 $safe=htmlspecialchars($caption,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
 return preg_replace_callback('/(?<![\pL\pN_.])@([a-z][a-z0-9._]{3,29})/ui',static function($m){return '<a href="find.php?q='.rawurlencode($m[1]).'">'.$m[0].'</a>';},$safe);
}
function body24_compose(string $csrf,string $back):void { ?>
<section class="panel body24-composer"><details><summary>＋ Fotoğraf, ALDZ Kısa, ALDZ Uzun veya Kombin paylaş</summary>
<form action="social_action.php" method="post" enctype="multipart/form-data" id="body42-upload-form" data-php-upload-max="<?=body42_ini_bytes((string)ini_get('upload_max_filesize'))?>" data-php-post-max="<?=body42_ini_bytes((string)ini_get('post_max_size'))?>">
<input type="hidden" name="csrf" value="<?=body_e($csrf)?>"><input type="hidden" name="action" value="post24"><input type="hidden" name="back" value="<?=body_e($back)?>"><input type="hidden" name="staged_video" id="body44-staged-video" value="">
<label>Gönderi türü<select name="media_type" id="body24-type"><option value="photo">Fotoğraf (en çok 8 görsel)</option><option value="outfit">Kombin paylaş (en çok 8 görsel)</option><option value="video_short">ALDZ Kısa · En çok 5 dakika</option><option value="video_long">ALDZ Uzun · En az 5 dakika</option></select></label>
<p class="body24-hint">Videolar 1 GB’a kadar parça parça yüklenir; ALDZ Kısa en fazla 5 dakika, ALDZ Uzun en az 5 dakika. MP4 önerilir. Yükleme sırasında sayfadan ayrılmayın.</p>
<label>Medya dosyaları<input type="file" name="media[]" id="body24-files" accept="image/jpeg,image/png,image/webp" multiple required></label><p id="body42-upload-feedback" class="body24-hint" role="status" aria-live="polite"></p><progress id="body44-upload-progress" value="0" max="100" hidden style="width:100%;max-width:420px"></progress>
<div id="body36-outfit-fields" class="body36-outfit-fields" hidden><label>Kombin stili<select name="outfit_style"><option value="">Stil seç (isteğe bağlı)</option><option value="Günlük">Günlük</option><option value="Sokak stili">Sokak stili</option><option value="Klasik">Klasik</option><option value="Spor">Spor</option><option value="Özel gün">Özel gün</option><option value="Diğer">Diğer</option></select></label><label>Kombin parçaları / detaylar<textarea name="outfit_details" rows="2" maxlength="500" placeholder="Ceket, ayakkabı, pantolon, renkler... (isteğe bağlı)"></textarea></label></div>
<label>Açıklama ve @kullanıcıadı etiketleri<textarea name="caption" rows="3" maxlength="2000" placeholder="Birlikte daha güzel… @arkadas"></textarea></label>
<label class="body24-check"><input type="checkbox" name="comments_enabled" value="1" checked> Yorumlar açık</label>
<button class="button" type="submit">Paylaş</button></form></details></section>
<?php }
function body24_share_contacts(PDO $db,int $mid):array {
 static $cache=[];
 if(isset($cache[$mid]))return $cache[$mid];
 $q=$db->prepare("SELECT DISTINCT u.id,u.name,u.username FROM social_follows f JOIN users u ON u.id=CASE WHEN f.follower_id=? THEN f.following_id ELSE f.follower_id END AND u.status='active' WHERE (f.follower_id=? OR f.following_id=?) AND f.status='accepted' AND u.id<>? ORDER BY u.name LIMIT 150");
 $q->execute([$mid,$mid,$mid,$mid]);
 return $cache[$mid]=array_values(array_filter($q->fetchAll(),static fn($u)=>body_same_age_band($mid,(int)$u['id'])&&social_can_view($mid,(int)$u['id'])&&social_can_view((int)$u['id'],$mid)));
}
function body24_post(PDO $db,array $p,int $mid,string $back,string $csrf,?array $repost=null):void {
 $id=(int)$p['id'];$owner=(int)$p['user_id'];$canOwner=$owner===$mid;
 $media=body24_media($db,$id);if(!$media)$media=[['media_path'=>$p['media_path'],'media_kind'=>'photo']];
 $video=$media[0]['media_kind']==='video';
 $lengthLabel='';$outfitStyle='';$outfitDetails='';$postCategory='standard';try{$catStmt=$db->prepare('SELECT post_category,outfit_style,outfit_details FROM body_post_options WHERE post_id=?');$catStmt->execute([$id]);$catRow=$catStmt->fetch(PDO::FETCH_ASSOC);if($catRow){$postCategory=(string)($catRow['post_category']??'standard');$outfitStyle=(string)($catRow['outfit_style']??'');$outfitDetails=(string)($catRow['outfit_details']??'');}}catch(Throwable $ignored){}if($video){try{$v=$db->prepare('SELECT video_length FROM body_post_options WHERE post_id=?');$v->execute([$id]);$lengthLabel=$v->fetchColumn()==='long'?'ALDZ Uzun':'ALDZ Kısa';}catch(Throwable $e){$lengthLabel='Video';}}
 $opt=$db->prepare('SELECT comments_enabled FROM body_post_options WHERE post_id=?');$opt->execute([$id]);$found=$opt->fetchColumn();$commentsEnabled=$found===false||((int)$found===1);
 $liked=!empty($p['liked']);
 ?>
<article class="panel body24-post" id="post-<?=$id?>">
<?php if($repost):?><div class="body24-repost-label">↻ <a href="social.php?view=profile&amp;user=<?=(int)$repost['user_id']?>">@<?=body_e($repost['username'])?></a> yeniden paylaştı</div><?php endif;?>
<?php $isDemo=str_starts_with((string)$p['caption'],'[DEMO]'); if($isDemo): ?><div class="aldz-demo-label" role="note">ÖRNEK İÇERİK · Gerçek kullanıcı paylaşımı değildir</div><?php endif; ?>
<header class="body24-post-top"><a href="social.php?view=profile&amp;user=<?=$owner?>"><strong>@<?=body_e($p['username'])?></strong></a><small><?=body_e($p['created_at'])?> · <?=$video?body_e($lengthLabel):($postCategory==='outfit'?'Kombin':'Fotoğraf')?></small></header>
<div class="body24-media" aria-label="Gönderi medyaları">
<?php foreach($media as $m):?>
 <div class="body24-media-item"><?php if($m['media_kind']==='video'):?><video controls preload="metadata" playsinline src="<?=body_e($m['media_path'])?>"></video><?php else:?><img loading="lazy" src="<?=body_e($m['media_path'])?>" alt="Paylaşılan fotoğraf"><?php endif;?></div>
<?php endforeach; ?></div>
<?php if(count($media)>1):?><small class="body24-hint">Fotoğraflar arasında yana kaydır · <?=count($media)?> fotoğraf</small><?php endif;?>
<p class="body24-caption"><?=nl2br(body24_caption((string)$p['caption']))?></p><?php if($postCategory==='outfit'): ?><div class="body36-outfit-detail"><strong>✦ Kombin</strong><?php if($outfitStyle!==''): ?><span><?=body_e($outfitStyle)?></span><?php endif; ?><?php if($outfitDetails!==''): ?><p><?=nl2br(body_e($outfitDetails))?></p><?php endif; ?></div><?php endif; ?>
<?php if(!$isDemo): ?><div class="body24-actions">
<form method="post" action="social_action.php"><input type="hidden" name="csrf" value="<?=body_e($csrf)?>"><input type="hidden" name="back" value="<?=body_e($back)?>"><input type="hidden" name="action" value="like"><input type="hidden" name="target" value="<?=$id?>"><button type="submit"><?=$liked?'♥':'♡'?> <?= (int)$p['likes'] ?> Beğeni</button></form>
<button type="button" class="copy-link" data-url="social.php?view=profile&amp;user=<?=$owner?>#post-<?=$id?>">Bağlantıyı kopyala</button>
<?php if(!$canOwner):?><?php $repostCheck=$db->prepare('SELECT visibility FROM body_post_reposts WHERE post_id=? AND user_id=? LIMIT 1');$repostCheck->execute([$id,$mid]);$myRepost=$repostCheck->fetchColumn(); ?>
<?php if($video): ?>
<form method="post" action="social_action.php" class="body41-video-repost"><input type="hidden" name="csrf" value="<?=body_e($csrf)?>"><input type="hidden" name="back" value="<?=body_e($back)?>"><input type="hidden" name="action" value="repost24"><input type="hidden" name="target" value="<?=$id?>"><input type="hidden" name="visibility" value="<?=body_e($myRepost!==false?(string)$myRepost:'followers')?>"><button type="submit" <?= $myRepost!==false?'disabled aria-disabled="true" title="Video zaten repostlandı; ayarlar menüsünden güncelleyebilir veya kaldırabilirsin."':'' ?>>↻ <?=$myRepost!==false?'Video repostlandı ✓':'Videoyu repostla'?></button></form>
<?php endif; ?>
<details class="body24-inline"><summary>↻ <?=$video?'Repost ayarları':($myRepost!==false?'Repost yapıldı':'Repost')?></summary><form action="social_action.php" method="post"><input type="hidden" name="csrf" value="<?=body_e($csrf)?>"><input type="hidden" name="back" value="<?=body_e($back)?>"><input type="hidden" name="action" value="repost24"><input type="hidden" name="target" value="<?=$id?>"><select name="visibility"><option value="followers">Yalnızca takipçilerim</option><option value="everyone">Herkes (herkese açık gönderilerde onay gerektirmez)</option></select><button type="submit"><?=$myRepost!==false?'Repostu güncelle':'Yeniden paylaş'?></button><?php if($myRepost!==false):?><button type="submit" name="remove" value="1">Repostu kaldır</button><?php endif;?></form></details><?php endif;?>
<details class="body24-inline aldz-friend-share"><summary>Arkadaşa gönder</summary><form action="social_action.php" method="post"><input type="hidden" name="csrf" value="<?=body_e($csrf)?>"><input type="hidden" name="back" value="<?=body_e($back)?>"><input type="hidden" name="action" value="share24"><input type="hidden" name="target" value="<?=$id?>">
<p class="aldz-share-tip">Takip bağlantın olan kişileri seç veya isimle ara.</p><label>Arkadaş ara<input type="search" class="aldz-friend-search" placeholder="İsim veya @kullanıcıadı" autocomplete="off"></label><div class="aldz-friend-list" role="group" aria-label="Paylaşılacak arkadaş">
<?php foreach(body24_share_contacts($db,$mid) as $friend): if(!social_can_view($owner,(int)$friend['id']) || !social_can_view($owner,$mid))continue; ?><label class="aldz-friend-option" data-search="<?=body_e(mb_strtolower($friend['name'].' '.$friend['username'],'UTF-8'))?>"><input type="radio" name="recipient" value="<?=body_e($friend['username'])?>" required><span class="aldz-friend-avatar"><?=body_e(mb_substr($friend['name'],0,1))?></span><span><strong><?=body_e($friend['name'])?></strong><small>@<?=body_e($friend['username'])?></small></span></label><?php endforeach; ?>
</div><p class="aldz-share-empty" hidden>Bu aramayla eşleşen arkadaş bulunamadı.</p><button type="submit">Mesaj olarak gönder</button></form></details>
</div>
<?php endif; ?><?php if(!$isDemo && $canOwner):?><form method="post" class="body24-comments-toggle" action="social_action.php"><input type="hidden" name="csrf" value="<?=body_e($csrf)?>"><input type="hidden" name="back" value="<?=body_e($back)?>"><input type="hidden" name="action" value="comments24"><input type="hidden" name="target" value="<?=$id?>"><input type="hidden" name="enabled" value="<?=$commentsEnabled?0:1?>"><button type="submit">Yorumları <?=$commentsEnabled?'kapat':'aç'?></button></form><?php endif;?>
<?php if($isDemo): ?><p class="body24-hint">Demo paylaşımda beğeni, repost ve yorum kapalıdır.</p><?php elseif($commentsEnabled):?>
<div class="body24-comments"><b><?= (int)$p['comments'] ?> yorum</b>
<?php $cq=$db->prepare('SELECT c.body,u.name,u.username FROM social_post_comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.created_at DESC LIMIT 5');$cq->execute([$id]);foreach(array_reverse($cq->fetchAll()) as $c):?><p><b>@<?=body_e($c['username'])?></b> <?=body_e($c['body'])?></p><?php endforeach;?></div>
<form class="body24-comment-form" method="post" action="social_action.php"><input type="hidden" name="csrf" value="<?=body_e($csrf)?>"><input type="hidden" name="back" value="<?=body_e($back)?>"><input type="hidden" name="action" value="comment"><input type="hidden" name="target" value="<?=$id?>"><input name="body" maxlength="1000" required placeholder="Yorum ekle…"><button type="submit">Gönder</button></form>
<?php else:?><p class="body24-hint">Bu gönderide yorumlar kapalı.</p><?php endif;?></article>
<?php }
