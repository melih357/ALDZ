<?php
declare(strict_types=1);
require_once __DIR__.'/social_media_v24.php';
function body44_dir():string {
 $dir=__DIR__.'/video_staging';
 if(!is_dir($dir) && !mkdir($dir,0700,true) && !is_dir($dir))throw new RuntimeException('Geçici video klasörü oluşturulamadı.');
 return $dir;
}
function body44_paths(string $id):array {
 if(!preg_match('/^[a-f0-9]{48}$/D',$id))throw new RuntimeException('Geçersiz yükleme kimliği.');
 $base=body44_dir().'/'.$id;
 return [$base.'.json',$base.'.part'];
}
/** Read metadata from an already opened and locked descriptor.
 * Opening the same locked file again can fail on Windows/WAMP.
 */
function body44_locked_state($fp,int $uid):array {
 if(!is_resource($fp))throw new RuntimeException('Yükleme kaydı okunamadı.');
 rewind($fp);
 $raw=stream_get_contents($fp);
 $state=is_string($raw)?json_decode($raw,true):null;
 if(!is_array($state))throw new RuntimeException('Yükleme kaydı geçersiz. Video yeniden yüklenmeli.');
 if((int)($state['uid']??0)!==$uid)throw new RuntimeException('Video başka bir kullanıcıya ait.');
 if(time()-(int)($state['created']??0)>86400)throw new RuntimeException('Video yüklemesinin süresi doldu.');
 return $state;
}
function body44_validate_file(string $path,string $kind):void {
 $mime=body_detect_mime($path);
 if(!in_array($mime,['video/mp4','video/webm'],true))throw new RuntimeException('Yalnızca gerçek MP4 veya WEBM videoları yüklenebilir.');
 $seconds=body_video_duration($path,$mime);
 if($seconds===null)throw new RuntimeException('Video süresi okunamadı. MP4 video kullan veya sunucuya FFprobe kur.');
 if($kind==='video_short' && $seconds>300)throw new RuntimeException('ALDZ Kısa en fazla 5 dakika olabilir.');
 if($kind==='video_long' && $seconds<300)throw new RuntimeException('ALDZ Uzun en az 5 dakika olmalı.');
}
function body44_consume(string $id,int $uid,string $kind):array {
 [$meta,$part]=body44_paths($id);
 if(!is_file($meta))throw new RuntimeException('Video oturum kaydı bulunamadı. Video yeniden yüklenmeli.');
 $fp=@fopen($meta,'r+b');if(!$fp)throw new RuntimeException('Video oturum dosyası açılamadı. Klasör izinlerini kontrol et.');
 if(!flock($fp,LOCK_EX)){fclose($fp);throw new RuntimeException('Video oturumu kilitlenemedi.');}
 try {
  $state=body44_locked_state($fp,$uid);
  if(($state['kind']??'')!==$kind || empty($state['ready']) || !is_file($part) || filesize($part)!==(int)$state['size'])throw new RuntimeException('Video henüz tam yüklenmedi.');
  body44_validate_file($part,$kind);
  $mime=body_detect_mime($part);$ext=$mime==='video/webm'?'webm':'mp4';
  $dir=__DIR__.'/../frontend/uploads';if(!is_dir($dir)&&!mkdir($dir,0755,true))throw new RuntimeException('Medya klasörü oluşturulamadı.');
  $name=bin2hex(random_bytes(18)).'.'.$ext;
  if(!rename($part,$dir.'/'.$name))throw new RuntimeException('Video kaydedilemedi; disk alanını veya dosya izinlerini kontrol et.');
  return ['path'=>'uploads/'.$name,'kind'=>'video'];
 }finally{flock($fp,LOCK_UN);fclose($fp);}
}
