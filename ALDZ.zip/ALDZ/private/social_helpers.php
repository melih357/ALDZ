<?php
declare(strict_types=1);
require_once __DIR__.'/auth.php';
function social_prefs(int $userId): array {
    $q=body_db()->prepare('SELECT * FROM social_preferences WHERE user_id=?'); $q->execute([$userId]);
    return $q->fetch() ?: ['account_private'=>0,'language_code'=>'tr','appearance'=>'social'];
}
function body_same_age_band(int $a, int $b): bool {
    if ($a <= 0 || $b <= 0) return false;
    // IN (?, ?) yields only one row when both IDs are identical.
    // The current user must be able to access their own profile.
    if ($a === $b) {
        $self = body_db()->prepare("SELECT status FROM users WHERE id=? LIMIT 1");
        $self->execute([$a]);
        return $self->fetchColumn() === 'active';
    }
    $q=body_db()->prepare("SELECT id,birth_date,status FROM users WHERE id IN (?,?)");
    $q->execute([$a,$b]); $rows=$q->fetchAll();
    if (count($rows)!==2) return false;
    $bands=[];
    foreach ($rows as $r) {
        if ($r['status']!=='active') return false;
        $age=(new DateTimeImmutable((string)$r['birth_date']))->diff(new DateTimeImmutable('today'))->y;
        $bands[]=$age>=18?'adult':'minor';
    }
    return $bands[0]===$bands[1];
}
function social_can_view(int $owner, int $viewer): bool {
    if ($owner === $viewer) return true;
    if (!body_same_age_band($owner,$viewer)) return false;
    $q=body_db()->prepare('SELECT 1 FROM user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1');
    $q->execute([$owner,$viewer,$viewer,$owner]);if($q->fetchColumn())return false;
    $prefs=social_prefs($owner); if (!$prefs['account_private']) return true;
    if ($viewer===0) return false;
    $q=body_db()->prepare("SELECT 1 FROM social_follows WHERE follower_id=? AND following_id=? AND status='accepted'");$q->execute([$viewer,$owner]);return (bool)$q->fetchColumn();
}
/** Public social profile/media visibility. Does not modify age-gated listings,
 * direct messaging, meeting participation or following permissions. */
function body38_can_view_content(int $owner, int $viewer): bool {
    if ($owner <= 0 || $viewer <= 0) return false;
    if ($owner === $viewer) return true;
    $db=body_db();
    $q=$db->prepare("SELECT status FROM users WHERE id=? LIMIT 1");
    $q->execute([$owner]);
    if ($q->fetchColumn() !== 'active') return false;
    $q=$db->prepare('SELECT 1 FROM user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1');
    $q->execute([$owner,$viewer,$viewer,$owner]);
    if ($q->fetchColumn()) return false;
    $prefs=social_prefs($owner);
    if (empty($prefs['account_private'])) return true;
    $q=$db->prepare("SELECT 1 FROM social_follows WHERE follower_id=? AND following_id=? AND status='accepted' LIMIT 1");
    $q->execute([$viewer,$owner]);
    return (bool)$q->fetchColumn();
}
function social_upload(string $field): string {
    require_once __DIR__.'/body_upload_validation.php';
    if (empty($_FILES[$field]) || !is_array($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Bir görsel yüklemelisin.');
    $file=$_FILES[$field];if($file['size']>5*1024*1024)throw new RuntimeException('Görsel en fazla 5 MB olabilir.');
    $mime=body_detect_mime($file['tmp_name']);
    $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;
    if(!$ext || !@getimagesize($file['tmp_name']))throw new RuntimeException('Yalnızca JPG, PNG veya WEBP görselleri kabul edilir.');
    $dir=__DIR__.'/../frontend/uploads';if(!is_dir($dir)&&!mkdir($dir,0755,true))throw new RuntimeException('Yükleme klasörü oluşturulamadı.');
    $name=bin2hex(random_bytes(18)).'.'.$ext;
    if(!move_uploaded_file($file['tmp_name'],$dir.'/'.$name))throw new RuntimeException('Görsel kaydedilemedi.');
    return 'uploads/'.$name;
}
function social_notify(int $to,int $by,string $kind,string $message): void {
    if($to===$by)return;
    $q=body_db()->prepare('INSERT INTO notifications(user_id,type,title,body,created_at) VALUES(?,?,?,?,NOW())');
    $q->execute([$to,$kind,'ALDZ bildirimi',$message]);
}
