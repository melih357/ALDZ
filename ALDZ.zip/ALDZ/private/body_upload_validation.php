<?php
declare(strict_types=1);
/** Inspect actual file bytes without requiring the optional PHP fileinfo extension. */
function body_detect_mime(string $path): string {
    $im=@getimagesize($path);
    if(is_array($im) && in_array($im['mime']??'', ['image/jpeg','image/png','image/webp'], true))return $im['mime'];
    $fh=@fopen($path,'rb');if(!$fh)throw new RuntimeException('Dosya okunamadı.');
    $head=fread($fh,4096);fclose($fh);
    if(str_starts_with($head,'%PDF-'))return 'application/pdf';
    if(str_starts_with($head,'OggS'))return 'audio/ogg';
    if(strlen($head)>44 && substr($head,0,4)==='RIFF' && substr($head,8,4)==='WAVE' && substr($head,12,4)==='fmt ')return 'audio/wav';
    if(str_starts_with($head,"\x1a\x45\xdf\xa3"))return 'video/webm';
    if(strlen($head)>12 && substr($head,4,4)==='ftyp'){
        $major=substr($head,8,4);
        if(in_array($major,['M4A ','M4B ','M4P '],true))return 'audio/mp4';
        return 'video/mp4';
    }
    if(str_starts_with($head,'ID3')||(strlen($head)>2 && ord($head[0])===255 && (ord($head[1])&224)===224))return 'audio/mpeg';
    if(!str_contains($head,"\0") && preg_match('//u',$head)===1 && strlen($head)<4096)return 'text/plain';
    return 'application/octet-stream';
}
/** For MP4, parse mvhd timescale/duration; ffprobe can inspect MP4 and WebM if configured. */
function body_video_duration(string $path,string $mime): ?float {
    $executable=getenv('ALDZ_FFPROBE') ?: '';
    if($executable===''){
        foreach(['ffprobe','ffprobe.exe'] as $candidate){
            // Prefer known install when provided. Avoid shell if exec disabled.
            $executable=$candidate;break;
        }
    }
    if(function_exists('exec') && !in_array('exec',array_map('trim',explode(',',ini_get('disable_functions')?:'')),true)){
        $line=@exec(escapeshellarg($executable).' -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 '.escapeshellarg($path).' 2>NUL',$out,$code);
        if($code===0 && is_numeric(trim((string)$line)) && (float)$line>0)return (float)$line;
    }
    if($mime!=='video/mp4')return null;
    $fh=@fopen($path,'rb');if(!$fh)return null;
    $size=filesize($path);$pos=0;
    // Parse root boxes, then moov children; support mvhd v0 and v1.
    $find=function($start,$end,$boxType)use($fh,$size){
        $at=$start;
        while($at+8<=$end){
            fseek($fh,$at);$h=fread($fh,16);if(strlen($h)<8)break;
            $len=unpack('N',substr($h,0,4))[1];$type=substr($h,4,4);$hdr=8;
            if($len===1){$hi=unpack('N',substr($h,8,4))[1];$lo=unpack('N',substr($h,12,4))[1];$len=$hi*4294967296+$lo;$hdr=16;}
            if($len===0)$len=$end-$at;
            if($len<$hdr || $at+$len>$end)break;
            if($type===$boxType)return [$at+$hdr,$at+$len];
            $at+=$len;
        }
        return null;
    };
    $moov=$find(0,$size,'moov');$mvhd=$moov?$find($moov[0],$moov[1],'mvhd'):null;
    if(!$mvhd){fclose($fh);return null;}
    fseek($fh,$mvhd[0]);$bytes=fread($fh,36);fclose($fh);
    if(strlen($bytes)<20)return null;
    $version=ord($bytes[0]);
    if($version===0){$scale=unpack('N',substr($bytes,12,4))[1];$ticks=unpack('N',substr($bytes,16,4))[1];}
    elseif($version===1 && strlen($bytes)>=32){$scale=unpack('N',substr($bytes,20,4))[1];$hi=unpack('N',substr($bytes,24,4))[1];$lo=unpack('N',substr($bytes,28,4))[1];$ticks=$hi*4294967296+$lo;}
    else return null;
    return $scale>0 && $ticks>0 ? $ticks/$scale : null;
}
