<?php
declare(strict_types=1);
function body_can_see_follow_list(PDO $db,int $owner,int $viewer): bool {
 if($owner===$viewer)return true;
 if(!body_same_age_band($owner,$viewer))return false;
 if(!social_can_view($owner,$viewer))return false;
 $q=$db->prepare('SELECT follow_visibility FROM social_preferences WHERE user_id=?');$q->execute([$owner]);$policy=(string)($q->fetchColumn()?:'everyone');
 if($policy==='only_me')return false;
 if($policy==='everyone')return true;
 $q=$db->prepare("SELECT follower_id,following_id FROM social_follows WHERE status='accepted' AND ((follower_id=? AND following_id=?) OR (follower_id=? AND following_id=?))");
 $q->execute([$owner,$viewer,$viewer,$owner]);$ownerFollows=false;$viewerFollows=false;
 foreach($q->fetchAll() as $row){if((int)$row['follower_id']===$owner)$ownerFollows=true;else $viewerFollows=true;}
 return $policy==='following'?$ownerFollows:($ownerFollows&&$viewerFollows);
}
