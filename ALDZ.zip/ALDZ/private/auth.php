<?php
declare(strict_types=1);
require_once __DIR__.'/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) {
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_name('ALDZSESSID');
    session_set_cookie_params(['lifetime'=>0,'path'=>rtrim(str_replace('\\','/',dirname(dirname($_SERVER['SCRIPT_NAME']??'/ALDZ/frontend/index.php'))),'/').'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);
    ini_set('session.use_strict_mode','1');
    session_start();
}
function body_e(string $value): string {return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');}
function body_csrf(): string {
    if (empty($_SESSION['body_csrf'])) $_SESSION['body_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['body_csrf'];
}
function body_valid_csrf(): bool {
    return isset($_POST['csrf']) && is_string($_POST['csrf']) && hash_equals(body_csrf(), $_POST['csrf']);
}
function body_user(): ?array {
    if (empty($_SESSION['body_user_id'])) return null;
    try {
        $q=body_db()->prepare('SELECT id,name,username,email,birth_date,age_band,gender,status FROM users WHERE id=? LIMIT 1');
        $q->execute([$_SESSION['body_user_id']]);
        $user=$q->fetch();
        if (!$user || $user['status'] !== 'active') { unset($_SESSION['body_user_id']);return null; }
        $dob=new DateTimeImmutable((string)$user['birth_date']);
        $years=$dob->diff(new DateTimeImmutable('today'))->y;
        $currentBand=$years>=18?'adult':'minor';
        if ($currentBand !== $user['age_band']) {
            $q=body_db()->prepare('UPDATE users SET age_band=?,updated_at=NOW() WHERE id=?');
            $q->execute([$currentBand,$user['id']]);
            $user['age_band']=$currentBand;
        }
        return $user;
    } catch (PDOException $e) { return null; }
}
function body_require_login(): array {
    $user=body_user();
    if (!$user) { header('Location: auth.php?mode=login',true,302);exit; }
    return $user;
}
function body_redirect(string $to): never {header('Location: '.$to,true,303);exit;}
