Temporary video chunks are stored here. Do not serve publicly.
