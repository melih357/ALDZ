<?php
declare(strict_types=1);
require_once __DIR__.'/../private/auth.php';
$currentUser = body_user();
$page = $_GET['page'] ?? 'home';
if(in_array($page,['experience','shares'],true)){body_redirect('index.php');}
if ($currentUser && in_array($page, ['profile','settings'], true)) {
    header('Location: social.php?view=' . ($page === 'profile' ? 'profile' : 'settings'), true, 302);
    exit;
}
$listingSections=['activity','roommate','freeitems','creative','travel','samegender','skills','jobs','partners'];
if($currentUser && $page==='communities'){body_redirect('communities.php');}
if($currentUser && in_array($page,$listingSections,true)){body_redirect('listings.php?type='.rawurlencode((string)$page));}
$allowed = ['home','events','communities','messages','activity','roommate','freeitems','creative','travel','samegender','skills','jobs','partners'];
if (!is_string($page) || !in_array($page, $allowed, true)) {
    $page = 'home';
}
if ($page !== 'home' && !$currentUser) {
    body_redirect('auth.php?mode=login');
}
function esc(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function is_active(string $page, array $keys): bool { return in_array($page, $keys, true); }
function side_link(string $label, string $url, string $icon, bool $active = false): string {
    return '<a class="side-link'.($active ? ' selected' : '').'" href="'.esc($url).'"><span class="side-icon">'.esc($icon).'</span><span>'.esc($label).'</span></a>';
}
$categoryTiles = [
    ['symbol'=>'♧','label'=>'Aktivite Arkadaşı','tint'=>'#ead6ff','color'=>'#7424ed','url'=>'?page=activity'],
    ['symbol'=>'⌂','label'=>'Ev Arkadaşı','tint'=>'#ffe2f4','color'=>'#e42d99','url'=>'?page=roommate'],
    ['symbol'=>'▣','label'=>'Ücretsiz Eşya','tint'=>'#ffecdb','color'=>'#f57420','url'=>'?page=freeitems'],
    ['symbol'=>'✎','label'=>'Yaratıcı Köşe','tint'=>'#f1ddff','color'=>'#9a35e8','url'=>'?page=creative'],
    ['symbol'=>'✈','label'=>'Şehir & Seyahat','tint'=>'#dff7ef','color'=>'#0eae8c','url'=>'?page=travel'],
    ['symbol'=>'⚽','label'=>'Aynı Çevreden','tint'=>'#e7e3ff','color'=>'#6b42d5','url'=>'?page=samegender'],
    ['symbol'=>'✦','label'=>'Birbirimize Öğretelim','tint'=>'#dff5ef','color'=>'#159b78','url'=>'?page=skills'],
    ['symbol'=>'▤','label'=>'İş & Fırsatlar','tint'=>'#fff0d8','color'=>'#ba6a20','url'=>'?page=jobs'],
    ['symbol'=>'🤝','label'=>'Proje & İş Ortaklığı','tint'=>'#e5f1ff','color'=>'#3b5cb2','url'=>'?page=partners'],
];
$titleMap = [
    'home'=>'Ana Sayfa','events'=>'Etkinlikler','communities'=>'Topluluklar',
    'messages'=>'Mesajlar','activity'=>'Aktivite Arkadaşı','roommate'=>'Ev Arkadaşı','freeitems'=>'Ücretsiz Eşya',
    'creative'=>'Yaratıcı Köşe','travel'=>'Şehir & Seyahat'
];
$currentTitle = $titleMap[$page] ?? 'ALDZ';
$eventRows=[];$eventFlash=$_SESSION['event_flash']??null;unset($_SESSION['event_flash']);
if ($page==='messages' && $currentUser) { body_redirect('messages.php'); }
if ($page==='notifications' && $currentUser) { body_redirect('notifications.php'); }
if ($page==='events' && $currentUser) {
 try {$eq=body_db()->prepare("SELECT e.*,u.name AS host_name,(SELECT COUNT(*) FROM event_participants ep WHERE ep.event_id=e.id AND ep.status='confirmed') AS attendee_count FROM events e JOIN users u ON u.id=e.user_id WHERE e.status='open' AND e.age_band=? AND e.starts_at > NOW() ORDER BY e.starts_at ASC LIMIT 40");$eq->execute([$currentUser['age_band']]);$eventRows=$eq->fetchAll();}catch(Throwable $e){$eventFlash='Etkinlikler yüklenemedi. Tek SQL dosyasının kurulu olduğundan emin ol.';}
}

?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#231439">
<title><?= esc($currentTitle) ?> — ALDZ</title>
<link rel="stylesheet" href="css/social.css"><link rel="stylesheet" href="css/aldz-v7.css"><link rel="stylesheet" href="css/shell-v13.css?v=23">
<link rel="stylesheet" href="css/aldz-v23.css?v=23"><link rel="stylesheet" href="css/aldz-v27.css?v=27"><link rel="stylesheet" href="css/aldz-i18n-v39.css?v=39"><link rel="stylesheet" href="css/home-layout-v43.css?v=43"></head>
<body class="aldz-app<?= $page === 'home' ? ' aldz-home' : '' ?>">
<?php require __DIR__.'/shell.php'; ?>
<div class="app-layout">
 <main class="content-area">
 <?php if ($page==='home'): ?>
    <section class="hero-picture" id="heroSlider" aria-roledescription="carousel" aria-label="ALDZ kampanya görselleri" tabindex="0">
      <div class="hero-slide campaign-friends active" aria-hidden="false">
       <div class="campaign-copy"><h2>Birlikte Daha Güzel</h2><p>Tanış, paylaş, keşfet. Gerçek bağlantılar ALDZ ile başlar.</p><a class="campaign-button" href="social.php?view=feed">Şimdi Keşfet <span aria-hidden="true">→</span></a></div>
       <div class="campaign-media"><img src="assets/campaign-friends.jpg" alt="ALDZ arkadaşlık ve sosyalleşme" loading="eager"></div>
      </div>
      <div class="hero-slide campaign-events" aria-hidden="true">
       <div class="campaign-copy"><h2>Yeni insanlarla yeni etkinlikler</h2><p>Yeni deneyimler ve ortak buluşmalar seni bekliyor.</p><a class="campaign-button" href="?page=events" tabindex="-1">Etkinlikleri Gör <span aria-hidden="true">→</span></a></div>
       <div class="campaign-media"><img src="assets/walk-event.jpg" alt="Yeni insanlarla yeni etkinlikler" loading="lazy"></div>
      </div>
      <div class="hero-slide campaign-community" aria-hidden="true">
       <div class="campaign-copy"><h2>Birlikte daha güçlü topluluklar</h2><p>İlgi alanlarını paylaşan insanlarla bir araya gel.</p><a class="campaign-button" href="communities.php" tabindex="-1">Topluluklara Katıl <span aria-hidden="true">→</span></a></div>
       <div class="campaign-media"><img src="assets/community-v10.jpg" alt="Birlikte daha güçlü topluluklar" loading="lazy"></div>
      </div>
      <div class="hero-slide campaign-shares" aria-hidden="true">
       <div class="campaign-copy"><h2>Paylaşınca daha güzel</h2><p>Fotoğraflar, deneyimler ve ilham veren yeni hikâyeler.</p><a class="campaign-button" href="social.php?view=feed" tabindex="-1">Paylaşımı Keşfet <span aria-hidden="true">→</span></a></div>
       <div class="campaign-media"><img src="assets/sharing-v10.jpg" alt="Paylaşınca daha güzel" loading="lazy"></div>
      </div>
      <div class="hero-dots" role="group" aria-label="Kampanya seçimi">
       <button type="button" data-slide="0" class="active" aria-label="1. kampanya" aria-pressed="true"></button>
       <button type="button" data-slide="1" class="" aria-label="2. kampanya" aria-pressed="false"></button>
       <button type="button" data-slide="2" class="" aria-label="3. kampanya" aria-pressed="false"></button>
       <button type="button" data-slide="3" class="" aria-label="4. kampanya" aria-pressed="false"></button>
      </div>
    </section>
    <div class="category-bar" id="categories"><?php foreach($categoryTiles as $c): ?><a href="<?= esc($c['url']) ?>" class="category-tile"><span style="--tile:<?= esc($c['tint']) ?>;--accent:<?= esc($c['color']) ?>"><?= esc($c['symbol']) ?></span><strong><?= esc($c['label']) ?></strong></a><?php endforeach; ?></div>
    <div class="home-columns">
      <section class="feed-col">
        <div class="section-summary-grid">
          <a class="summary-card large" href="social.php?view=feed"><h2>Keşfet</h2><p>Fotoğraflar, hikâyeler ve arkadaşlarından güncel paylaşımlar.</p><span>Keşfete Git →</span></a>
          <a class="summary-card" href="?page=events"><h2>Etkinlikler</h2><p>Yakındaki buluşmaları ayrı sayfada keşfet.</p><span>Etkinlikleri Aç</span></a>
          <a class="summary-card" href="communities.php"><h2>Topluluklar</h2><p>İlgi alanlarına göre topluluklara katıl.</p><span>Topluluklara Git</span></a>
          <a class="summary-card" href="social.php?view=feed"><h2>Ücretsiz Eşya</h2><p>Ücretsiz eşya ilanlarını incele.</p><span>İlanları İncele</span></a>
        </div>
        <article class="panel info-block"><h2>Gerçek paylaşımları keşfet</h2><p>Arkadaşlarının fotoğrafları ve hikâyeleri keşfet bölümünde yer alır. Örnek beğeni ve yorum sayıları kaldırıldı.</p><a class="pill" href="social.php?view=feed">Paylaşımları Gör</a></article>
      </section>
      <aside class="feed-right">
        <div class="panel right-panel"><div class="panel-head"><h3>Yaklaşan Etkinlikler</h3><a href="?page=events">Tümü →</a></div><p>Yaklaşan gerçek buluşmalar için etkinlikler sayfasını incele.</p></div>
        <div class="panel right-panel"><div class="panel-head"><h3>Topluluklar</h3><a href="communities.php">Gör →</a></div><p>Kendi odanı oluştur veya mevcut bir topluluğa katıl.</p></div>
      </aside>
    </div>
 <?php elseif ($page==='events'): ?>
    <div class="page-intro"><h1>Etkinlikler ve Buluşmalar</h1><p>13–17 ve 18+ grupları için birbirinden ayrı, güvenli buluşmalar.</p></div>
    <?php if($eventFlash): ?><div class="panel aldz-alert" role="status"><?= esc($eventFlash) ?></div><?php endif; ?>
    <section class="events-toolbar"><div><h2>Yaklaşan Buluşmalar</h2><p>Topluluğunla gerçek hayatta buluş. 13–17 ve 18+ yaş grupları birbirinden ayrı tutulur.</p></div><a class="event-create-jump" href="event_create.php" data-create-event>＋ Buluşma Oluştur</a></section>
    <section class="event-layout">
     <div class="event-results">
      <?php if(!$eventRows): ?><div class="panel info-block"><h2>Henüz yaklaşan etkinlik yok</h2><p>Etkinlik oluştur sayfasından ilk buluşmanı açabilirsin. Etkinlikler gerçek veritabanına kaydedilir.</p></div><?php endif; ?>
      <?php foreach($eventRows as $event):
       $requiresAdult=$event['age_band']==='adult';
       $isMinor=$currentUser && $currentUser['age_band']==='minor';
       $isOwner=$currentUser && (int)$event['user_id']===(int)$currentUser['id'];
       $canJoin=$event['age_band']===$currentUser['age_band'];
       $isDemoEvent=str_starts_with((string)($event['host_name']??''),'ALDZ Demo ');
      ?>
       <article class="panel event-live-card"><div class="event-live-head"><span class="age-pill <?= $requiresAdult?'adults':'general' ?>"><?= $requiresAdult?'18+ · Yalnızca yetişkinler':'13–17 · Yalnızca gençler' ?></span><small><?= esc($event['city']) ?> · <?= esc(date('d.m.Y H:i',strtotime($event['starts_at']))) ?></small></div><h2><?= esc($event['title']) ?></h2><p><?= nl2br(esc($event['description'])) ?></p><small>Oluşturan: <?= esc($event['host_name']) ?> · <?= (int)$event['attendee_count'] ?>/<?= (int)$event['capacity'] ?> kişi</small>
       <?php if($isOwner): ?><p class="muted">Bu buluşmanın organizatörüsün.</p><details><summary>Katılım isteklerini yönet / Etkinliği iptal et</summary><?php
        $rq=body_db()->prepare("SELECT ep.user_id,ep.status,u.name FROM event_participants ep JOIN users u ON u.id=ep.user_id WHERE ep.event_id=? AND ep.status IN ('pending','confirmed') ORDER BY ep.created_at DESC LIMIT 100");$rq->execute([$event['id']]);foreach($rq->fetchAll() as $participant): ?>
         <div class="participant-manage"><span><?= esc($participant['name']) ?> · <?= esc($participant['status']) ?></span>
          <?php if($participant['status']==='pending'): ?><form method="post" action="event_action.php"><input type="hidden" name="csrf" value="<?= esc(body_csrf()) ?>"><input type="hidden" name="action" value="decide"><input type="hidden" name="event_id" value="<?= (int)$event['id'] ?>"><input type="hidden" name="user_id" value="<?= (int)$participant['user_id'] ?>"><button name="decision" value="confirmed">Onayla</button><button name="decision" value="rejected">Reddet</button></form><?php endif; ?></div>
        <?php endforeach; ?><form method="post" action="event_action.php" onsubmit="return confirm('Etkinlik iptal edilsin mi?')"><input type="hidden" name="csrf" value="<?= esc(body_csrf()) ?>"><input type="hidden" name="action" value="cancel"><input type="hidden" name="event_id" value="<?= (int)$event['id'] ?>"><button type="submit">Etkinliği İptal Et</button></form></details>
       <?php elseif($isDemoEvent): ?><p class="event-restricted">DEMO — Bu etkinlik gerçek değildir; katılım kapalıdır.</p>
       <?php elseif(!$canJoin): ?><p class="event-restricted">Bu buluşma senin yaş grubuna açık değil.</p>
       <?php else: ?><form method="post" action="event_action.php"><input type="hidden" name="csrf" value="<?= esc(body_csrf()) ?>"><input type="hidden" name="action" value="join"><input type="hidden" name="event_id" value="<?= (int)$event['id'] ?>"><button class="pill" type="submit">Katıl / İsteği Gönder</button></form><?php endif; ?>
       </article>
      <?php endforeach; ?>
     </div>
    </section>


 <?php elseif ($page==='activity'): ?>
    <div class="page-intro"><h1>Aktivite Arkadaşı</h1><p>Bu kategori artık ayrı bir sayfa. Spor, yürüyüş, kahve ve buluşma eşleşmeleri burada.</p></div>
    <section class="page-grid two cards"><article class="panel info-block"><h3>Yakınındaki Aktiviteler</h3><ul><li>Sabah yürüyüşü</li><li>Hafta sonu kahvesi</li><li>Birlikte spor</li></ul></article><article class="panel info-block"><h3>Eşleşme Mantığı</h3><p>İlgi alanı, konum ve uygunluk durumuna göre eşleşme yapılacak.</p></article></section>
 <?php elseif ($page==='roommate'): ?>
    <div class="page-intro"><h1>Ev Arkadaşı</h1><p>Ev arkadaşı bölümü diğer kategorilerden bağımsız, tamamen ayrı bir alan olarak tasarlanır.</p></div>
    <section class="page-grid two cards"><article class="panel info-block"><h3>Aradığın Özellikler</h3><ul><li>Bütçe</li><li>Konum</li><li>Yaşam tarzı</li><li>Ev düzeni</li></ul></article><article class="panel info-block"><h3>İlan Yönetimi</h3><p>İlan oluşturma, başvuru alma ve görüşme aşamaları burada geliştirilecek.</p></article></section>
 <?php elseif ($page==='freeitems'): ?>
    <div class="page-intro"><h1>Ücretsiz Eşya</h1><p>Gösterilen ürünler örnektir; şu anda gerçek eşya talebi kabul edilmez.</p></div>
    <section class="page-grid two cards"><article class="panel feature-page-card"><img src="assets/coffee-event.jpg" alt=""><div><h2>Kahve Makinesi</h2><p>Beşiktaş · Ücretsiz</p><small>İhtiyacı olan birine veriliyor.</small></div><span class="pilot-caption">Örnek görünüm · Başvuru kapalı</span></article><article class="panel feature-page-card"><img src="assets/walk-event.jpg" alt=""><div><h2>Kamp Sandalyesi</h2><p>Üsküdar · Ücretsiz</p><small>Temiz durumda, teslim alınabilir.</small></div><span class="pilot-caption">Örnek görünüm · Başvuru kapalı</span></article></section>

 <?php elseif ($page==='creative'): ?>
    <div class="page-intro"><h1>Yaratıcı Köşe</h1><p>Şiir, hikâye, çizim ve yaratıcı fikirler için ayrı bölüm.</p></div>
    <section class="page-grid one cards"><article class="panel article-card"><h3>Kısa Hikâye Paylaşımı</h3><p>Kendi kısa hikâyeni ya da şiirini burada yayınlayabileceksin.</p></article><article class="panel article-card"><h3>Ortak Projeler</h3><p>Birlikte tasarım, yazı ya da içerik üretmek isteyen insanları bul.</p></article></section>
 <?php elseif ($page==='travel'): ?>
    <div class="page-intro"><h1>Şehir & Seyahat</h1><p>Aşağıdaki planlar tasarım örneğidir; gerçek katılım henüz açık değil.</p></div>
    <section class="page-grid two cards"><article class="panel feature-page-card"><img src="assets/walk-event.jpg" alt=""><div><h2>Kapadokya Hafta Sonu</h2><p>21–23 Haziran</p><small>Ortak seyahat planı oluştur.</small></div><span class="pilot-caption">Örnek görünüm · Başvuru kapalı</span></article><article class="panel feature-page-card"><img src="assets/coffee-event.jpg" alt=""><div><h2>İstanbul Sokak Lezzetleri</h2><p>Şehir keşfi</p><small>Birlikte gezip deneyimleyin.</small></div><span class="pilot-caption">Örnek görünüm · Başvuru kapalı</span></article></section>
 <?php else: ?>
    <p><a href="messages.php">Mesaj kutuna git</a></p>
 <?php endif; ?>
 </main>
 <aside class="social-rail">
    <div class="panel mini-panel"><div class="panel-head"><h3>Mesajlar</h3><a href="messages.php">Gör →</a></div><p>Mesajlarını güvenli gelen kutunda görüntüle.</p></div>
    <div class="panel promo"><img src="assets/logo-mark.png" alt=""><b>Kendi etkinliğini oluştur,<br>insanları bir araya getir!</b><a href="event_create.php">Etkinlik Oluştur →</a></div>
    
 </aside>
</div>
<div class="modal" id="demoModal" hidden><div class="modal-dialog"><button class="modal-close" aria-label="Kapat">✕</button><h2 id="modalTitle">Önizleme</h2><p>Bu bölümün görünümü hazır. Giriş ve kayıt aktiftir. Bu özellik henüz geliştirme aşamasındadır.</p><button class="pill modal-close">Tamam</button></div></div>
<link rel="manifest" href="manifest.json"><script src="js/social.js" defer></script><script src="js/shared-nav.js?v=16" defer></script><script src="js/shell-v10.js?v=13" defer></script><script>if("serviceWorker" in navigator){navigator.serviceWorker.register("sw.js").catch(()=>{});}</script>
<script src="js/aldz-i18n-v39.js?v=39" defer></script></body></html>
