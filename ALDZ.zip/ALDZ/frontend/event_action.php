<?php
declare(strict_types=1);
require_once __DIR__.'/../private/social_helpers.php';
$me=body_require_login();
if($_SERVER['REQUEST_METHOD']!=='POST'||!body_valid_csrf()){http_response_code(403);exit('İstek doğrulanamadı.');}
function fail_event(string $message, bool $reopen=false):never{$_SESSION['event_flash']=$message;body_redirect(($reopen?'event_create.php':'index.php?page=events'));}
$db=body_db();
try {
  if(($_POST['action']??'')==='create') {
    $title=trim((string)($_POST['title']??''));$description=trim((string)($_POST['description']??''));$city=trim((string)($_POST['city']??''));
    $time=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',(string)($_POST['starts_at']??''),new DateTimeZone('Europe/Istanbul'));
    $dateErrors=DateTimeImmutable::getLastErrors();if($dateErrors && ($dateErrors['warning_count'] || $dateErrors['error_count']))$time=false;
    $capacity=(int)($_POST['capacity']??0);$rule=(string)($_POST['age_rule']??'');
    if(!$title||mb_strlen($title)>180||!$description||mb_strlen($description)>2000||!$city||mb_strlen($city)>100||$capacity<2||$capacity>100||!$time||$time<=new DateTimeImmutable('now',new DateTimeZone('Europe/Istanbul'))||!in_array($rule,['minor','adult'],true)) throw new RuntimeException('Etkinlik adı, açıklama, şehir, katılımcı sayısı ve gelecekteki tarih/saat alanlarını kontrol et.');
    if($rule!==$me['age_band'])throw new RuntimeException('Yalnızca kendi yaş grubuna uygun buluşma oluşturabilirsin.');
    $age=$rule;
    $q=$db->prepare("INSERT INTO events(user_id,title,description,category,starts_at,city,capacity,age_band,approval_required,visibility,status,created_at,updated_at) VALUES(?,?,?,'community',?,?,?,?,?,'members','open',NOW(),NOW())");
    $q->execute([(int)$me['id'],$title,$description,$time->format('Y-m-d H:i:s'),$city,$capacity,$age,isset($_POST['approval_required'])?1:0]);
    fail_event('Buluşman oluşturuldu.');
  }
  if(($_POST['action']??'')==='join') {
    $id=(int)($_POST['event_id']??0);if($id<=0)throw new RuntimeException('Etkinlik seçilemedi.');
    $db->beginTransaction();
    $q=$db->prepare("SELECT e.id,e.user_id,e.age_band,e.capacity,e.approval_required,u.birth_date FROM events e JOIN users u ON u.id=e.user_id AND u.status='active' WHERE e.id=? AND e.status='open' AND e.starts_at>NOW() FOR UPDATE");$q->execute([$id]);$event=$q->fetch();
    if(!$event)throw new RuntimeException('Etkinlik bulunamadı veya katılıma kapalı.');
    $demoCheck=$db->prepare('SELECT username FROM users WHERE id=?');$demoCheck->execute([(int)$event['user_id']]);if(str_starts_with((string)$demoCheck->fetchColumn(),'body_demo_'))throw new RuntimeException('Bu yalnızca örnek bir etkinliktir; katılım kapalıdır.');
    if($event['age_band']!==$me['age_band'] || (($ageNow=(new DateTimeImmutable((string)$event['birth_date']))->diff(new DateTimeImmutable('today'))->y)>=18?'adult':'minor')!==$event['age_band'])throw new RuntimeException('Bu etkinlik yaş grubuna açık değil.');
    if((int)$event['user_id']===(int)$me['id'])throw new RuntimeException('Kendi etkinliğine zaten organizatör olarak katılıyorsun.');
    $q=$db->prepare("SELECT COUNT(*) FROM event_participants WHERE event_id=? AND status='confirmed'");$q->execute([$id]);if((int)$q->fetchColumn()>=(int)$event['capacity'])throw new RuntimeException('Etkinlik dolu.');
    $q=$db->prepare("SELECT status FROM event_participants WHERE event_id=? AND user_id=? FOR UPDATE");$q->execute([$id,(int)$me['id']]);
    $prior=$q->fetchColumn();if($prior==='confirmed'||$prior==='pending')throw new RuntimeException('Bu etkinliğe zaten katıldın veya isteğin beklemede.');
    $status=(int)$event['approval_required']?'pending':'confirmed';
    $q=$db->prepare("INSERT INTO event_participants(event_id,user_id,status,created_at,updated_at) VALUES(?,?,?,NOW(),NOW()) ON DUPLICATE KEY UPDATE status=VALUES(status),updated_at=NOW()");$q->execute([$id,(int)$me['id'],$status]);
    $db->commit();fail_event($status==='pending'?'Katılım isteğin gönderildi.':'Etkinliğe katıldın.');
  }
  if(($_POST['action']??'')==='decide') {
    $id=(int)($_POST['event_id']??0);$participant=(int)($_POST['user_id']??0);$decision=(string)($_POST['decision']??'');
    if($id<1||$participant<1||!in_array($decision,['confirmed','rejected'],true))throw new RuntimeException('Geçersiz istek.');
    $db->beginTransaction();
    $q=$db->prepare("SELECT capacity FROM events WHERE id=? AND user_id=? AND status='open' FOR UPDATE");$q->execute([$id,$me['id']]);$event=$q->fetch();if(!$event)throw new RuntimeException('Bu etkinliği yönetemezsin.');
    $q=$db->prepare("SELECT status FROM event_participants WHERE event_id=? AND user_id=? FOR UPDATE");$q->execute([$id,$participant]);if($q->fetchColumn()!=='pending')throw new RuntimeException('Bekleyen istek bulunamadı.');
    if(!body_same_age_band((int)$me['id'],$participant))throw new RuntimeException('Katılımcı artık aynı yaş grubunda değil.');
    if($decision==='confirmed'){$q=$db->prepare("SELECT COUNT(*) FROM event_participants WHERE event_id=? AND status='confirmed'");$q->execute([$id]);if((int)$q->fetchColumn()>=(int)$event['capacity'])throw new RuntimeException('Kontenjan dolu.');}
    $db->prepare('UPDATE event_participants SET status=?,updated_at=NOW() WHERE event_id=? AND user_id=?')->execute([$decision,$id,$participant]);
    $db->commit();fail_event('Katılım isteği güncellendi.');
  }
  if(($_POST['action']??'')==='cancel') {
    $id=(int)($_POST['event_id']??0);
    $q=$db->prepare("UPDATE events SET status='cancelled',updated_at=NOW() WHERE id=? AND user_id=? AND status='open'");$q->execute([$id,$me['id']]);
    if(!$q->rowCount())throw new RuntimeException('Bu etkinlik iptal edilemedi.');fail_event('Buluşma iptal edildi.');
  }
  throw new RuntimeException('Bilinmeyen işlem.');
} catch(Throwable $e){if($db->inTransaction())$db->rollBack();error_log('ALDZ event action: '.$e->getMessage());$creating=($_POST['action']??'')==='create';$message=$e instanceof PDOException?'Veritabanı etkinlik kaydını kabul etmedi. database.sql şemasını kontrol edin.':$e->getMessage();fail_event($message,$creating);}
