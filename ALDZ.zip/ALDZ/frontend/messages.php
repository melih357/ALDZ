<?php
declare(strict_types=1);
require_once __DIR__.'/../private/body_notifications.php';
require_once __DIR__.'/../private/message_media_v25.php';
$me=body_require_login();$mid=(int)$me['id'];$db=body_db();$flash='';
function can_direct_message(PDO $db,int $a,int $b): bool {
    if($a===$b || !body_same_age_band($a,$b) || !social_can_view($b,$a))return false;
    $q=$db->prepare("SELECT 1 FROM social_follows WHERE ((follower_id=? AND following_id=?) OR (follower_id=? AND following_id=?)) AND status='accepted' LIMIT 1");
    $q->execute([$a,$b,$b,$a]);return (bool)$q->fetchColumn();
}
function direct_peer(PDO $db,int $conversation,int $me): ?int {
    $q=$db->prepare("SELECT c.id,cp2.user_id AS peer FROM conversations c JOIN conversation_participants cp1 ON cp1.conversation_id=c.id AND cp1.user_id=? AND cp1.status='active' JOIN conversation_participants cp2 ON cp2.conversation_id=c.id AND cp2.user_id<>? AND cp2.status='active' WHERE c.id=? AND c.kind='direct' LIMIT 1");
    $q->execute([$me,$me,$conversation]);$r=$q->fetch();return $r?(int)$r['peer']:null;
}
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!body_valid_csrf()){http_response_code(403);exit('İstek doğrulanamadı.');}
    try {
        $action=(string)($_POST['action']??'');
        if($action==='start'){
            $peer=(int)($_POST['peer']??0);if(!can_direct_message($db,$mid,$peer))throw new RuntimeException('Mesajlaşma için güvenli ve kabul edilmiş takip bağlantısı gerekir.');
            $db->beginTransaction();
            $q=$db->prepare("SELECT c.id FROM conversations c JOIN conversation_participants p1 ON p1.conversation_id=c.id AND p1.user_id=? JOIN conversation_participants p2 ON p2.conversation_id=c.id AND p2.user_id=? WHERE c.kind='direct' ORDER BY c.id LIMIT 1 FOR UPDATE");
            $q->execute([$mid,$peer]);$cid=(int)$q->fetchColumn();
            if(!$cid){
                $db->prepare("INSERT INTO conversations(kind,created_by,created_at,updated_at) VALUES('direct',?,NOW(),NOW())")->execute([$mid]);$cid=(int)$db->lastInsertId();
                $db->prepare("INSERT INTO conversation_participants(conversation_id,user_id,status,joined_at) VALUES(?,?,'active',NOW())")->execute([$cid,$mid]);
                $db->prepare("INSERT INTO conversation_participants(conversation_id,user_id,status,joined_at) VALUES(?,?,'active',NOW())")->execute([$cid,$peer]);
            }
            $db->commit();body_redirect('messages.php?chat='.$cid);
        }
        if($action==='send'){
            $cid=(int)($_POST['chat']??0);$body=trim((string)($_POST['body']??''));
            if($cid<=0||$body===''||mb_strlen($body)>2000)throw new RuntimeException('Mesaj 1–2000 karakter arasında olmalı.');
            $peer=direct_peer($db,$cid,$mid);
            if(!$peer||!can_direct_message($db,$mid,$peer))throw new RuntimeException('Bu sohbet için mesajlaşma yetkin yok.');
            $db->prepare("INSERT INTO messages(conversation_id,sender_id,body,message_type,created_at,updated_at) VALUES(?,?,?,'text',NOW(),NOW())")->execute([$cid,$mid,$body]);
            $db->prepare('UPDATE conversations SET updated_at=NOW() WHERE id=?')->execute([$cid]);
            body_emit_notification($db,$peer,$mid,'direct_message','Yeni mesaj','Yeni bir özel mesajın var.');
            body_redirect('messages.php?chat='.$cid);
        }
        throw new RuntimeException('Bilinmeyen işlem.');
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();$flash=$e->getMessage();}
}
$with=(int)($_GET['with']??0);$chat=(int)($_GET['chat']??0);
$directs=$db->prepare("SELECT c.id,c.updated_at,u.name,u.username,u.id AS peer,cp1.last_read_at,
 (SELECT m.body FROM messages m WHERE m.conversation_id=c.id AND m.deleted_at IS NULL ORDER BY m.id DESC LIMIT 1) AS last_body,
 (SELECT m.created_at FROM messages m WHERE m.conversation_id=c.id AND m.deleted_at IS NULL ORDER BY m.id DESC LIMIT 1) AS last_time,
 (SELECT COUNT(*) FROM messages m WHERE m.conversation_id=c.id AND m.deleted_at IS NULL AND m.sender_id<>? AND (cp1.last_read_at IS NULL OR m.created_at>cp1.last_read_at)) AS unread_count
 FROM conversations c JOIN conversation_participants cp1 ON cp1.conversation_id=c.id AND cp1.user_id=? AND cp1.status='active'
 JOIN conversation_participants cp2 ON cp2.conversation_id=c.id AND cp2.user_id<>? AND cp2.status='active'
 JOIN users u ON u.id=cp2.user_id AND u.status='active' WHERE c.kind='direct' ORDER BY c.updated_at DESC LIMIT 80");
$directs->execute([$mid,$mid,$mid]);
$convos=array_values(array_filter($directs->fetchAll(),fn($c)=>can_direct_message($db,$mid,(int)$c['peer'])));
$active=null;foreach($convos as $c){if((int)$c['id']===$chat)$active=$c;}
$messages=[];
if($active){
 $messages=body_chat_messages($db,$chat,$mid);
 $db->prepare('UPDATE conversation_participants SET last_read_at=NOW() WHERE conversation_id=? AND user_id=?')->execute([$chat,$mid]);
}
if(($_GET['format']??'')==='json'){
 header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');header('X-Content-Type-Options: nosniff');
 if(!$active){http_response_code(403);echo json_encode(['error'=>'Sohbet erişimi yok'],JSON_UNESCAPED_UNICODE);exit;}
 echo json_encode(['messages'=>$messages,'mine'=>$mid],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;
}
$stickers=[];if($active){$sq=$db->prepare('SELECT id,name FROM body_custom_stickers WHERE owner_id=? ORDER BY id DESC LIMIT 30');$sq->execute([$mid]);$stickers=$sq->fetchAll();}
$possible=null;if($with&&can_direct_message($db,$mid,$with)){$q=$db->prepare('SELECT id,name,username FROM users WHERE id=?');$q->execute([$with]);$possible=$q->fetch();}
?>
<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mesajlar — ALDZ</title><link rel="stylesheet" href="css/social-v2.css"><link rel="stylesheet" href="css/aldz-v7.css"><link rel="stylesheet" href="css/shell-v13.css?v=21"><link rel="stylesheet" href="css/messages-v21.css?v=21"><link rel="stylesheet" href="css/aldz-v23.css?v=23"><link rel="stylesheet" href="css/messages-v25.css?v=26"><link rel="stylesheet" href="css/messages-v26.css?v=26"><link rel="stylesheet" href="css/aldz-v27.css?v=27"><link rel="stylesheet" href="css/messages-v28.css?v=28"><link rel="stylesheet" href="css/aldz-i18n-v39.css?v=39"></head>
<body class="social-page aldz-app"><?php require __DIR__.'/shell.php'; ?>
<main class="container aldz-message-page">
 <div class="message-page-header"><div><h1>Mesajlar</h1><p>Takip bağlantısı olan kişilerle güvenli mesajlaşma.</p></div><a class="message-find" href="find.php">Kişi bul</a></div>
 <?php if($flash):?><p class="flash" role="alert"><?=body_e($flash)?></p><?php endif;?>
 <div class="aldz-messages <?= $active ? 'has-active-chat':'' ?>">
  <aside class="panel aldz-conversations" aria-label="Sohbet listesi">
   <div class="message-panel-heading"><h2>Sohbetler</h2><span><?=count($convos)?></span></div>
   <label class="message-search-label" for="chatSearch">Sohbet ara</label><input id="chatSearch" class="message-search" type="search" placeholder="Kişi veya mesaj ara..." autocomplete="off">
   <div id="conversationList">
    <?php if(!$convos):?><p class="message-empty">Henüz sohbetin yok. Takipleştiğin bir kişinin profilinden sohbet başlatabilirsin.</p><?php endif;?>
    <?php foreach($convos as $c):?>
     <a class="aldz-convo <?= (int)$c['id']===$chat?'active':'' ?>" href="?chat=<?=(int)$c['id']?>" data-search="<?=body_e(mb_strtolower($c['name'].' '.$c['username'].' '.($c['last_body']??''),'UTF-8'))?>">
      <span class="message-avatar" aria-hidden="true"><?=body_e(mb_substr((string)$c['name'],0,1))?></span>
      <span class="message-convo-content"><strong><?=body_e($c['name'])?></strong><small>@<?=body_e($c['username'])?></small><span class="message-last"><?=body_e(mb_strimwidth((string)($c['last_body']??'Henüz mesaj yok'),0,65,'…','UTF-8'))?></span></span>
      <?php if((int)$c['unread_count']>0 && (int)$c['id']!==$chat):?><span class="message-unread" aria-label="<?= (int)$c['unread_count'] ?> okunmamış mesaj"><?= min(99,(int)$c['unread_count']) ?></span><?php endif; ?>
     </a>
    <?php endforeach; ?>
   </div>
  </aside>
  <section class="panel aldz-chat" aria-label="Sohbet içeriği">
   <?php if($active):?>
    <div class="message-chat-heading"><a class="message-mobile-back" href="messages.php" aria-label="Sohbetlere dön">←</a><span class="message-avatar" aria-hidden="true"><?=body_e(mb_substr((string)$active['name'],0,1))?></span><div><h2><?=body_e($active['name'])?></h2><small>@<?=body_e($active['username'])?></small></div><div class="aldz-call-buttons"><button type="button" data-call="audio" title="Sesli arama" aria-label="Sesli arama">☎</button><button type="button" data-call="video" title="Görüntülü arama" aria-label="Görüntülü arama">▣</button></div><a class="message-profile" href="social.php?view=profile&amp;user=<?=(int)$active['peer']?>">Profili</a></div>
    <div class="aldz-bubbles" id="directChatMessages" data-chat="<?=$chat?>" aria-label="Mesaj geçmişi" aria-live="polite">
    <?php if(!$messages):?><p class="message-empty" data-empty="true">Henüz mesaj yok. İlk mesajı sen gönder.</p><?php endif;?>
    <?php foreach($messages as $m):?><div class="aldz-bubble <?= (int)$m['sender_id']===$mid?'mine':'other' ?>" data-id="<?=(int)$m['id']?>"><p><?=nl2br(body_e($m['body']))?></p><?php if(!empty($m['attachment_id'])):?><?php if(!empty($m['view_once'])):?><?php if(!empty($m['viewed_at'])):?><span class="view-once-expired">Tek görüntülemelik fotoğraf açıldı</span><?php elseif((int)$m['sender_id']===$mid):?><span class="view-once-expired">Tek görüntülemelik fotoğraf gönderildi</span><?php else:?><a class="view-once-link" target="_blank" rel="noopener noreferrer" href="message_file_v25.php?id=<?=(int)$m['attachment_id']?>">🔒 Fotoğrafı bir kez görüntüle</a><?php endif;?><?php elseif(in_array($m['attachment_kind'],['image','sticker'],true)):?><a href="message_file_v25.php?id=<?=(int)$m['attachment_id']?>" target="_blank" rel="noopener"><img class="chat-media-img" loading="lazy" src="message_file_v25.php?id=<?=(int)$m['attachment_id']?>" alt="Gönderilen görsel"></a><?php elseif($m['attachment_kind']==='video'):?><video class="chat-media-video" controls playsinline preload="metadata" src="message_file_v25.php?id=<?=(int)$m['attachment_id']?>"></video><?php elseif($m['attachment_kind']==='voice'):?><audio controls preload="none" src="message_file_v25.php?id=<?=(int)$m['attachment_id']?>"></audio><?php else:?><a class="chat-file-link" href="message_file_v25.php?id=<?=(int)$m['attachment_id']?>">📎 <?=body_e($m['attachment_name'])?></a><?php endif;?><?php endif;?><div class="chat-reaction-line"><?php if(!empty($m['reactions'])):?><?php foreach(explode('|',$m['reactions']) as $r):?><span><?=body_e(explode(':',$r)[0])?></span><?php endforeach;?><?php endif;?></div><small><?=body_e((string)$m['created_at'])?></small><button type="button" class="chat-react" data-react="<?=(int)$m['id']?>" aria-label="Mesaja ifade bırak">☺</button></div><?php endforeach; ?>
    </div>
    <form method="post" class="aldz-chat-form" id="directChatForm"><input type="hidden" name="csrf" value="<?=body_e(body_csrf())?>"><input type="hidden" name="action" value="send"><input type="hidden" name="chat" value="<?=$chat?>"><label class="message-search-label" for="messageAldz">Mesaj yaz</label><textarea id="messageAldz" name="body" maxlength="2000" rows="2" required placeholder="Mesajını yaz..."></textarea><button type="submit">Gönder</button></form><div class="aldz-message-toolbar"><button type="button" id="bodyPlusToggle" class="aldz-plus-toggle" aria-expanded="false" aria-controls="bodyAttachmentMenu" aria-label="Ek seçeneklerini aç">＋</button><button type="button" id="recordVoice" class="aldz-toolbar-record" aria-label="Ses kaydı başlat">🎙 <span>Ses kaydet</span></button><button type="button" id="showStickers" class="aldz-toolbar-stickers" aria-expanded="false">✦ <span>Çıkartmalar</span></button></div>
<div class="aldz-attachment-menu" id="bodyAttachmentMenu" hidden aria-label="Ek seçenekleri"><button type="button" id="openCamera">📷 <span>Kamera</span></button><button type="button" id="attachImage">▧ <span>Fotoğraf / Video</span></button><button type="button" id="attachFile">📎 <span>Dosya</span></button></div>
<section id="bodySendPreview" class="aldz-media-overlay" hidden role="dialog" aria-modal="true" aria-labelledby="bodyPreviewTitle"><div class="aldz-media-dialog aldz-send-dialog"><h3 id="bodyPreviewTitle">Göndermeden önce kontrol et</h3><div id="bodyPendingVisual" class="aldz-pending-visual"></div><p id="bodyPendingInfo"></p><fieldset id="bodyImagePrivacy"><legend>Bu fotoğraf nasıl gönderilsin?</legend><label><input type="radio" name="bodySendMode" value="normal"> Normal fotoğraf — tekrar görüntülenebilir</label><label><input type="radio" name="bodySendMode" value="once"> Tek görüntülemelik — yalnızca bir kez açılabilir</label></fieldset><p id="bodyVideoInfo" hidden>Video, sohbet içinde tekrar izlenebilir. Tek görüntüleme yalnızca fotoğraflarda desteklenir.</p><div class="aldz-media-controls"><button type="button" id="bodyConfirmSend" disabled>Gönder</button><button type="button" id="bodyCancelSend">İptal</button></div></div></section>
<section id="bodyCameraPanel" class="aldz-media-overlay" hidden role="dialog" aria-modal="true" aria-label="Kameradan fotoğraf çek"><div class="aldz-media-dialog"><h3>Fotoğraf çek</h3><video id="bodyLiveCamera" autoplay muted playsinline></video><div class="aldz-media-controls"><button type="button" id="bodyCameraCapture">Fotoğrafı çek</button><button type="button" id="bodyCameraClose">İptal</button></div></div></section><section id="bodyOncePanel" class="aldz-media-overlay" hidden role="dialog" aria-modal="true" aria-label="Tek görüntülemelik fotoğraf"><div class="aldz-media-dialog"><p>Bu fotoğraf yeniden açılamaz.</p><img id="bodyOnceImg" alt="Tek görüntülemelik fotoğraf"><button type="button" id="bodyOnceClose">Kapat</button></div></section>
<input hidden id="bodyMessageMedia" type="file"><input hidden id="bodyCameraMedia" type="file" accept="image/*" capture="environment"><div id="chatFeatureStatus" role="status" aria-live="polite"></div>
<div class="aldz-sticker-drawer" id="stickerDrawer" hidden><strong>Çıkartmalarım</strong><div class="aldz-sticker-grid"><?php foreach($stickers as $st):?><button type="button" data-sticker="<?=(int)$st['id']?>" title="<?=body_e($st['name'])?>"><img src="message_file_v25.php?sticker=<?=(int)$st['id']?>" loading="lazy" alt="<?=body_e($st['name'])?>"></button><?php endforeach;?></div><label>Yeni çıkartma (JPG, PNG, WEBP, en fazla 2 MB)<input id="newSticker" type="file" accept="image/jpeg,image/png,image/webp"></label></div>
<div id="voicePreview" hidden><strong id="bodyVoiceDuration"></strong><audio id="voicePlayback" controls></audio><button type="button" id="sendVoice">Sesli mesajı gönder</button><button type="button" id="cancelVoice">İptal</button></div>
<section id="callPanel" class="aldz-call-panel" hidden aria-label="Arama penceresi"><h3 id="callTitle">Arama</h3><p id="callState"></p><video id="localCallVideo" autoplay muted playsinline></video><video id="remoteCallVideo" autoplay playsinline></video><audio id="remoteCallAudio" autoplay></audio><div><button type="button" id="acceptCall" hidden>Yanıtla</button><button type="button" id="declineCall" hidden>Reddet</button><button type="button" id="hangupCall">Kapat</button></div></section>
<div id="reactionTray" class="reaction-tray" hidden><button type="button" data-emoji="❤️">❤️</button><button type="button" data-emoji="😂">😂</button><button type="button" data-emoji="👍">👍</button><button type="button" data-emoji="😮">😮</button><button type="button" data-emoji="😢">😢</button><button type="button" data-emoji="🔥">🔥</button></div>
<p class="message-hint">Enter: gönder · Shift+Enter: yeni satır · Mesajlar yaklaşık 8 saniyede yenilenir.</p>
   <?php elseif($possible):?>
    <div class="message-start"><h2><?=body_e($possible['name'])?> ile konuş</h2><p>Bu kişiyle güvenli takip bağlantınız var.</p><form method="post"><input type="hidden" name="csrf" value="<?=body_e(body_csrf())?>"><input type="hidden" name="action" value="start"><input type="hidden" name="peer" value="<?=$with?>"><button type="submit">Sohbeti başlat</button></form></div>
   <?php else:?>
    <div class="message-start"><h2>Bir sohbet seç</h2><p>Sohbet etmek istediğin kişiyi soldan seç veya yeni bir arkadaş bul.</p><a class="message-find" href="find.php">Kullanıcı ara</a></div>
   <?php endif; ?>
  </section>
 </div>
</main>
<script src="js/messages-v21.js?v=25" defer></script><script src="js/messages-v25.js?v=28" defer></script><script src="js/shared-nav.js?v=21" defer></script><script src="js/shell-v10.js?v=21" defer></script><script src="js/aldz-i18n-v39.js?v=39" defer></script></body></html>
