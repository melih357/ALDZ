<?php
declare(strict_types=1);
require_once __DIR__.'/../private/message_media_v25.php';
$me=body_require_login();$mid=(int)$me['id'];$db=body_db();$id=(int)($_GET['id']??0);$sticker=(int)($_GET['sticker']??0);
if($sticker>0){
 $q=$db->prepare('SELECT owner_id,storage_key,mime,name FROM body_custom_stickers WHERE id=?');$q->execute([$sticker]);$a=$q->fetch();
 if(!$a||(int)$a['owner_id']!==$mid){http_response_code(403);exit('Erişim yok.');}
 $filename=$a['name'];$inline=true;
}else{
 $q=$db->prepare('SELECT a.storage_key,a.mime,a.original_name,a.kind,a.view_once,a.viewed_at,m.sender_id,m.conversation_id FROM body_message_attachments a JOIN messages m ON m.id=a.message_id WHERE a.id=? AND m.deleted_at IS NULL');$q->execute([$id]);$a=$q->fetch();
 if(!$a||!body_chat_allowed($db,(int)$a['conversation_id'],$mid)){http_response_code(403);exit('Erişim yok.');}
 if(!empty($a['view_once'])){
    if((int)$a['sender_id']===$mid){http_response_code(403);exit('Tek görüntülemelik medyayı gönderen kişi açamaz.');}
    $claim=$db->prepare('UPDATE body_message_attachments SET viewed_at=NOW() WHERE id=? AND view_once=1 AND viewed_at IS NULL');
    $claim->execute([$id]);
    if($claim->rowCount()!==1){http_response_code(410);exit('Bu medya zaten görüntülendi.');}
 }
 $filename=$a['original_name'];$inline=in_array($a['kind'],['image','voice','sticker','video'],true);
}
$path=body_private_file_path($a['storage_key']);if(!is_file($path)){http_response_code(404);exit('Dosya bulunamadı.');}
header('Content-Type: '.$a['mime']);header('X-Content-Type-Options: nosniff');header('Content-Security-Policy: sandbox');header('Cache-Control: private, no-store');
header('Content-Disposition: '.($inline?'inline':'attachment').'; filename="'.preg_replace('/[^A-Za-z0-9._-]/','_', (string)$filename).'"');$size=(int)filesize($path);
// Audio elements may request partial content to determine and seek duration.
if(in_array(($a['kind']??''),['voice','video'],true) && isset($_SERVER['HTTP_RANGE']) && preg_match('/^bytes=(\d*)-(\d*)$/',trim((string)$_SERVER['HTTP_RANGE']),$mm)){
 $start=$mm[1]===''?0:(int)$mm[1];$end=$mm[2]===''?$size-1:min((int)$mm[2],$size-1);
 if($start>=$size||$end<$start){header('Content-Range: bytes */'.$size);http_response_code(416);exit;}
 http_response_code(206);header('Accept-Ranges: bytes');header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);header('Content-Length: '.($end-$start+1));
 $fp=fopen($path,'rb');fseek($fp,$start);$remaining=$end-$start+1;while($remaining>0&&!feof($fp)){$buffer=fread($fp,min(65536,$remaining));if($buffer==='')break;echo $buffer;$remaining-=strlen($buffer);}fclose($fp);exit;
}
header('Accept-Ranges: bytes');header('Content-Length: '.$size);readfile($path);
