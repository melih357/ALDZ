const CACHE = 'aldz-v46-cache';
const FILES = ['offline.html','css/aldz-motion-v35.css','js/aldz-motion-v35.js','css/terms-v34.css','js/terms-v34.js','css/notifications-v33.css','js/notifications-v33.js','assets/aldz-notification-v33.wav','css/aldz-v23.css','css/aldz-v24.css','js/aldz-v24.js','css/social.css','css/social-v2.css','css/shared-nav.css','css/shell-v13.css','css/listings-v14.css','css/listing-feedback-v18.css','css/aldz-v7.css','css/messages-v21.css','css/messages-v25.css','css/messages-v26.css','css/aldz-v27.css','css/aldz-v36.css','css/aldz-v37.css','css/aldz-v38.css','js/aldz-v38.js','js/aldz-i18n-v39.js','css/aldz-i18n-v39.css','js/aldz-v37.js','css/messages-v28.css','css/aldz-v28.css','js/messages-v21.js','js/messages-v25.js','js/social.js','js/social-v2.js','js/listings-v30.js','js/listings-v16.js','js/listings-v17.js','js/listings-v19.js','js/listings-v20.js','js/shared-nav.js','js/shell-v10.js','assets/logo-mark.png','icons/aldz-192.png','manifest.json'];
const BASE = new URL('./', self.location.href);
const URLS = FILES.map(name=>new URL(name,BASE).href);
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(URLS)).then(()=>self.skipWaiting())));
self.addEventListener('activate', event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>(key.startsWith('aldz-') || key.startsWith('body-')) && key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch', event=>{
 const req=event.request;if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
 if(req.mode==='navigate'){event.respondWith(fetch(req).catch(()=>caches.match(new URL('offline.html',BASE).href)));return;}
 if(URLS.includes(req.url))event.respondWith(caches.match(req).then(cached=>cached||fetch(req)));
});
