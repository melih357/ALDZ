<?php
declare(strict_types=1);
require_once __DIR__.'/../private/social_helpers.php';
require_once __DIR__.'/../private/listing_rules.php';
$me=body_require_login();$mid=(int)$me['id'];$id=(int)($_POST['listing_id']??0);
if($_SERVER['REQUEST_METHOD']!=='POST'||!body_valid_csrf()){http_response_code(403);exit('Geçersiz istek.');}
try{
 $db=body_db();$db->beginTransaction();
 $q=$db->prepare('SELECT * FROM body_listings WHERE id=? FOR UPDATE');$q->execute([$id]);$l=$q->fetch();
 if(!$l)throw new RuntimeException('İlan bulunamadı.');
 $demoCheck=$db->prepare('SELECT username FROM users WHERE id=?');$demoCheck->execute([(int)$l['user_id']]);if(str_starts_with((string)$demoCheck->fetchColumn(),'body_demo_'))throw new RuntimeException('Demo ilanlarına soru veya değerlendirme gönderilemez.');
 $owner=(int)$l['user_id'];$isOwner=$mid===$owner;
 if(!$isOwner && (!body_listing_allowed($l,$me)||!body_listing_gender_allowed($l,$me,$db)||!social_can_view($owner,$mid)))throw new RuntimeException('Bu ilana erişim iznin yok.');
 $action=(string)($_POST['action']??'');$message=trim((string)($_POST['body']??''));
 if($action==='ask'){
   if($isOwner || $l['status']!=='active'||mb_strlen($message)<3||mb_strlen($message)>1000)throw new RuntimeException('Sorun 3–1000 karakter olmalı ve ilan aktif olmalı.');
   $db->prepare('INSERT INTO body_listing_questions(listing_id,user_id,body) VALUES(?,?,?)')->execute([$id,$mid,$message]);$flash='Sorun herkesin görebileceği soru-cevap alanına eklendi.';
 }elseif($action==='answer'){
   if(!$isOwner||mb_strlen($message)<2||mb_strlen($message)>1500)throw new RuntimeException('Yanıt geçerli değil.');
   $questionId=(int)($_POST['question_id']??0);$q=$db->prepare('SELECT id FROM body_listing_questions WHERE id=? AND listing_id=?');$q->execute([$questionId,$id]);if(!$q->fetchColumn())throw new RuntimeException('Soru bulunamadı.');
   $db->prepare('INSERT INTO body_listing_answers(question_id,user_id,body) VALUES(?,?,?)')->execute([$questionId,$mid,$message]);$flash='Yanıtın yayınlandı.';
 }elseif($action==='complete'){
   if(!$isOwner||$l['status']!=='active')throw new RuntimeException('Yalnızca ilan sahibi aktif ilanını tamamlayabilir.');
   $q=$db->prepare("SELECT COUNT(*) FROM body_listing_members WHERE listing_id=? AND status='accepted'");$q->execute([$id]);if((int)$q->fetchColumn()<1)throw new RuntimeException('Tamamlamak için en az bir kabul edilmiş katılımcı gerekli.');
   $db->prepare("UPDATE body_listings SET status='completed' WHERE id=?")->execute([$id]);$flash='İlan tamamlandı. Kabul edilmiş katılımcılar değerlendirebilir.';
 }elseif($action==='review'){
   if($isOwner||$l['status']!=='completed')throw new RuntimeException('Sadece tamamlanmış ilana katılan kişiler değerlendirebilir.');
   $q=$db->prepare("SELECT status FROM body_listing_members WHERE listing_id=? AND user_id=?");$q->execute([$id,$mid]);if($q->fetchColumn()!=='accepted')throw new RuntimeException('Yalnızca kabul edilen katılımcılar değerlendirebilir.');
   $rating=(int)($_POST['rating']??0);$safe=(string)($_POST['safe_experience']??'');
   if($rating<1||$rating>5||!in_array($safe,['0','1'],true)||mb_strlen($message)<10||mb_strlen($message)>1000)throw new RuntimeException('1–5 puan, güvenlik seçimi ve 10–1000 karakter yorum gerekli.');
   $q=$db->prepare('SELECT id FROM body_listing_reviews WHERE listing_id=? AND reviewer_id=?');$q->execute([$id,$mid]);if($q->fetchColumn())throw new RuntimeException('Bu ilanı zaten değerlendirdin.');
   $db->prepare('INSERT INTO body_listing_reviews(listing_id,reviewer_id,reviewed_user_id,rating,safe_experience,body) VALUES(?,?,?,?,?,?)')->execute([$id,$mid,$owner,$rating,(int)$safe,$message]);$flash='Değerlendirmen kaydedildi.';
 }else throw new RuntimeException('Tanımsız işlem.');
 $db->commit();
}catch(Throwable $e){if(isset($db)&&$db->inTransaction())$db->rollBack();error_log('ALDZ listing feedback: '.$e->getMessage());$flash=$e instanceof RuntimeException?$e->getMessage():'İşlem gerçekleştirilemedi. V18 SQL güncellemesini kontrol et.';}
$_SESSION['listing_flash']=$flash;body_redirect('listing_room.php?id='.$id.'#listing-feedback');
