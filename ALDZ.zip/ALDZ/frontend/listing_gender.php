<?php
declare(strict_types=1);
require_once __DIR__.'/../private/social_helpers.php';
$me=body_require_login();
if($_SERVER['REQUEST_METHOD']!=='POST'||!body_valid_csrf()){http_response_code(403);exit('Geçersiz işlem.');}
$choice=(string)($_POST['gender']??'');
if(!in_array($choice,['woman','man'],true)){$_SESSION['body_gender_flash']='Geçerli bir seçim yap.';body_redirect('listings.php?type=samegender');}
$q=body_db()->prepare("UPDATE users SET gender=?,updated_at=NOW() WHERE id=? AND gender='undisclosed'");$q->execute([$choice,(int)$me['id']]);
$_SESSION['body_gender_flash']=$q->rowCount()?'Tercihin kaydedildi. Güvenlik için bu bilgiyi doğrudan tekrar değiştiremezsin.':'Bu bilgi zaten belirlenmiş; düzeltme için destek ekibiyle iletişime geç.';
body_redirect('listings.php?type=samegender');
