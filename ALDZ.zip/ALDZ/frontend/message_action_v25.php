<?php
declare(strict_types=1);
require_once __DIR__.'/../private/body_notifications.php';
require_once __DIR__.'/../private/message_media_v25.php';
$me=body_require_login();$mid=(int)$me['id'];$db=body_db();
header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');header('X-Content-Type-Options: nosniff');
function reply25(array $data,int $status=200): never {http_response_code($status);echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
if($_SERVER['REQUEST_METHOD']!=='POST'||!body_valid_csrf())reply25(['error'=>'İstek doğrulanamadı.'],403);
$action=(string)($_POST['action']??'');$chat=(int)($_POST['chat']??0);
if($chat<1||!body_chat_allowed($db,$chat,$mid))reply25(['error'=>'Sohbete erişim izni yok.'],403);
try{
 if($action==='upload'||$action==='voice'||$action==='sticker_send'){
  $kind=$action==='voice'?'voice':($action==='sticker_send'?'sticker':(string)($_POST['kind']??'image'));
  $blob=null;$stickerId=(int)($_POST['sticker_id']??0);
  if($action==='sticker_send' && $stickerId){
   $q=$db->prepare('SELECT storage_key,mime,name FROM body_custom_stickers WHERE id=? AND owner_id=?');$q->execute([$stickerId,$mid]);$sticker=$q->fetch();if(!$sticker)throw new RuntimeException('Çıkartma bulunamadı.');
   $source=body_private_file_path($sticker['storage_key']);$key=bin2hex(random_bytes(20)).'.'.pathinfo($source,PATHINFO_EXTENSION);$target=body_private_file_path($key);
   if(!copy($source,$target))throw new RuntimeException('Çıkartma kopyalanamadı.');
   $blob=['key'=>$key,'mime'=>$sticker['mime'],'name'=>$sticker['name'],'size'=>filesize($target),'path'=>$target];
  }else{
   if(!in_array($kind,['image','video','file','voice','sticker'],true))throw new RuntimeException('Dosya türü geçersiz.');
   $blob=body_save_private($_FILES['media']??[],$kind);
  }
  try{
   $db->beginTransaction();$messageText=trim((string)($_POST['body']??''));if($kind==='voice'){ $durationMs=(int)($_POST['duration_ms']??0);if($durationMs<400||$durationMs>600000)throw new RuntimeException('Geçerli bir ses kaydı süresi bulunamadı.');$messageText='[Sesli mesaj · '.floor($durationMs/60000).':'.str_pad((string)(floor($durationMs/1000)%60),2,'0',STR_PAD_LEFT).']';}if(mb_strlen($messageText)>1000)$messageText=mb_substr($messageText,0,1000);
   $db->prepare("INSERT INTO messages(conversation_id,sender_id,body,message_type,created_at,updated_at) VALUES(?,?,?,'text',NOW(),NOW())")->execute([$chat,$mid,$messageText?:('['.$kind.']')]);$id=(int)$db->lastInsertId();
   $once=$kind==='image' && !empty($_POST['view_once']) ? 1 : 0;
   $db->prepare('INSERT INTO body_message_attachments(message_id,storage_key,original_name,mime,byte_size,kind,view_once) VALUES(?,?,?,?,?,?,?)')->execute([$id,$blob['key'],$blob['name'],$blob['mime'],$blob['size'],$kind,$once]);
   $db->prepare('UPDATE conversations SET updated_at=NOW() WHERE id=?')->execute([$chat]);$db->commit();
   $peer=body_chat_peer($db,$chat,$mid);body_emit_notification($db,$peer,$mid,'direct_message','Yeni mesaj','Sohbetine yeni bir medya mesajı geldi.');
  }catch(Throwable $e){if($db->inTransaction())$db->rollBack();@unlink($blob['path']);throw $e;}
  reply25(['ok'=>true]);
 }
 if($action==='sticker_create'){
  $name=mb_substr(trim((string)($_POST['name']??'Çıkartmam')),0,90);
  $count=$db->prepare('SELECT COUNT(*) FROM body_custom_stickers WHERE owner_id=?');$count->execute([$mid]);if((int)$count->fetchColumn()>=30)throw new RuntimeException('En fazla 30 çıkartma ekleyebilirsin.');
  $blob=body_save_private($_FILES['media']??[],'sticker');
  try{$db->prepare('INSERT INTO body_custom_stickers(owner_id,storage_key,mime,name) VALUES(?,?,?,?)')->execute([$mid,$blob['key'],$blob['mime'],$name?:'Çıkartmam']);}catch(Throwable $e){@unlink($blob['path']);throw $e;}
  reply25(['ok'=>true,'id'=>(int)$db->lastInsertId()]);
 }
 if($action==='react'){
  $id=(int)($_POST['message_id']??0);$emoji=(string)($_POST['emoji']??'');
  if(!in_array($emoji,['❤️','😂','👍','😮','😢','🔥'],true))throw new RuntimeException('İfade geçersiz.');
  $q=$db->prepare('SELECT 1 FROM messages WHERE id=? AND conversation_id=? AND deleted_at IS NULL');$q->execute([$id,$chat]);if(!$q->fetchColumn())throw new RuntimeException('Mesaj bulunamadı.');
  $q=$db->prepare('SELECT emoji FROM body_message_reactions WHERE message_id=? AND user_id=?');$q->execute([$id,$mid]);$previous=$q->fetchColumn();
  if($previous===$emoji){$db->prepare('DELETE FROM body_message_reactions WHERE message_id=? AND user_id=?')->execute([$id,$mid]);}
  else{$db->prepare('INSERT INTO body_message_reactions(message_id,user_id,emoji) VALUES(?,?,?) ON DUPLICATE KEY UPDATE emoji=VALUES(emoji),created_at=NOW()')->execute([$id,$mid,$emoji]);}
  reply25(['ok'=>true]);
 }
 throw new RuntimeException('Bilinmeyen işlem.');
}catch(Throwable $e){reply25(['error'=>$e->getMessage()],400);}
