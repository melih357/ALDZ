<?php
declare(strict_types=1);
require_once __DIR__.'/../private/social_helpers.php';
$me=body_require_login();
$q=ltrim(mb_strtolower(trim((string)($_GET['q']??''))),'@');
if(mb_strlen($q)>30)$q=mb_substr($q,0,30);
$users=[];
if(mb_strlen($q)>=2 && preg_match('/^[a-z0-9._]+$/D',$q)){
 $db=body_db();
 $statement=$db->prepare("SELECT id,name,username FROM users WHERE status='active' AND age_band=? AND username LIKE ? AND id<>? ORDER BY CASE WHEN username=? THEN 0 ELSE 1 END,username LIMIT 30");
 $statement->execute([$me['age_band'],$q.'%',(int)$me['id'],$q]);
 foreach($statement->fetchAll() as $person){
  if(!social_can_view((int)$person['id'],(int)$me['id'])){ /* Private accounts remain discoverable to allow follow requests unless blocked. */
    $check=$db->prepare('SELECT 1 FROM user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?)');
    $check->execute([$me['id'],$person['id'],$person['id'],$me['id']]);
    if($check->fetchColumn())continue;
  }
  $users[]=$person;
 }
}
function h(string $v):string{return htmlspecialchars($v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kullanıcı Ara — ALDZ</title><link rel="stylesheet" href="css/social-v2.css"><link rel="stylesheet" href="css/aldz-v7.css"><link rel="stylesheet" href="css/shell-v13.css?v=23"><link rel="stylesheet" href="css/aldz-v23.css?v=23"><link rel="stylesheet" href="css/aldz-v27.css?v=27"><link rel="stylesheet" href="css/aldz-i18n-v39.css?v=39"></head><body class="aldz-app social-page">
<?php require __DIR__.'/shell.php'; ?>
<main class="container"><section class="panel"><h1>Kullanıcı adıyla ara</h1><p class="muted">Arkadaşlarını @kullanıcıadı ile bul ve profillerinden takip et.</p><form method="get" action="find.php" class="username-find"><input name="q" value="<?=h($q)?>" placeholder="@kullaniciadi" maxlength="30" autocomplete="off" required><button type="submit">Ara</button></form>
<?php if($q!=='' && mb_strlen($q)<2):?><p>En az 2 karakter yaz.</p><?php elseif($q!==''&&!$users):?><p>Bu kullanıcı adına uygun hesap bulunamadı.</p><?php endif; ?>
<div class="found-users"><?php foreach($users as $person):?><a class="found-user" href="social.php?view=profile&user=<?=(int)$person['id']?>"><span class="round"><?=h(mb_substr($person['name'],0,1))?></span><span><strong><?=h($person['name'])?></strong><small>@<?=h($person['username'])?></small></span><b>Profili Gör →</b></a><?php endforeach;?></div></section></main><script src="js/shared-nav.js?v=16" defer></script><script src="js/shell-v10.js?v=13" defer></script><script src="js/aldz-i18n-v39.js?v=39" defer></script></body></html>