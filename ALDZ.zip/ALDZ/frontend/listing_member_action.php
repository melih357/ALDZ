<?php
declare(strict_types=1);
require_once __DIR__.'/../private/body_notifications.php';
require_once __DIR__.'/../private/social_helpers.php';
require_once __DIR__.'/../private/listing_rules.php';
$me=body_require_login();$mid=(int)$me['id'];$id=(int)($_POST['listing_id']??0);
if($_SERVER['REQUEST_METHOD']!=='POST'||!body_valid_csrf()){http_response_code(403);exit('Geçersiz işlem.');}
try{
 $db=body_db();$db->beginTransaction();
 $q=$db->prepare('SELECT * FROM body_listings WHERE id=? FOR UPDATE');$q->execute([$id]);$l=$q->fetch();
 if(!$l)throw new RuntimeException('İlan bulunamadı.');
 $demoCheck=$db->prepare('SELECT username FROM users WHERE id=?');$demoCheck->execute([(int)$l['user_id']]);if(str_starts_with((string)$demoCheck->fetchColumn(),'body_demo_'))throw new RuntimeException('Bu yalnızca örnek bir ilandır; katılım kapalıdır.');
 $owner=(int)$l['user_id'];$action=(string)($_POST['action']??'');
 if($action==='join'){
   if(($l['type']==='jobs'&&$me['age_band']!=='adult')||!body_listing_gender_allowed($l,$me,$db)||($l['type']==='roommate'&&$me['age_band']!=='adult')||($l['type']==='partners'&&$me['age_band']!=='adult')||$l['status']!=='active'||$owner===$mid||!body_listing_allowed($l,$me)||!social_can_view($owner,$mid))throw new RuntimeException('Bu ilana katılamazsın.');
   $q=$db->prepare('SELECT status FROM body_listing_members WHERE listing_id=? AND user_id=?');$q->execute([$id,$mid]);$existing=$q->fetchColumn();
   if($existing==='accepted'||$existing==='pending')throw new RuntimeException('Başvurun zaten mevcut.');
   $jobType=[];if($l['type']==='jobs')$jobType=json_decode((string)($l['category_details']??''),true)?:[];
   $applicant=($jobType['job_mode']??'')==='Çalışan arıyorum';
   $cvText=trim((string)($_POST['cv_text']??''));
   if(mb_strlen($cvText)>8000)throw new RuntimeException('CV metni çok uzun.');
   $pdf=null;$pdfName=null;
   if(isset($_FILES['cv_pdf'])&&($_FILES['cv_pdf']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE){
    $f=$_FILES['cv_pdf'];if($f['error']!==UPLOAD_ERR_OK||$f['size']<1||$f['size']>3*1024*1024)throw new RuntimeException('CV en fazla 3 MB olabilir.');
    if(strtolower(pathinfo((string)$f['name'],PATHINFO_EXTENSION))!=='pdf'||!is_uploaded_file($f['tmp_name']))throw new RuntimeException('PDF dosyası yükle.');
    $pdf=file_get_contents($f['tmp_name']);if($pdf===false||substr($pdf,0,5)!=='%PDF-')throw new RuntimeException('CV geçerli bir PDF olmalı.');
    $pdfName=mb_substr(basename((string)$f['name']),0,150);
   }
   if($applicant&&$cvText===''&&$pdf===null)throw new RuntimeException('İş başvurularında CV metni veya PDF zorunludur.');
   $status=$l['approval_required']?'pending':'accepted';
   if($applicant)$db->prepare('INSERT INTO body_listing_cvs(listing_id,user_id,cv_text,cv_pdf,cv_filename) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE cv_text=VALUES(cv_text),cv_pdf=VALUES(cv_pdf),cv_filename=VALUES(cv_filename)')->execute([$id,$mid,$cvText!==''?$cvText:null,$pdf,$pdfName]);
   $db->prepare('INSERT INTO body_listing_members(listing_id,user_id,status) VALUES(?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status),updated_at=NOW()')->execute([$id,$mid,$status]);
   body_listing_flash($status==='pending'?'Katılım isteğin gönderildi.':'İlana katıldın.');
   body_emit_notification($db,$owner,$mid,'listing_join','İlan katılımı',$status==='pending'?'İlanına yeni bir katılım isteği geldi.':'İlanına yeni biri katıldı.');
 }elseif($action==='leave'){
   if($mid===$owner)throw new RuntimeException('İlan sahibi ayrılamaz.');
   $db->prepare("UPDATE body_listing_members SET status='left' WHERE listing_id=? AND user_id=? AND status IN ('pending','accepted')")->execute([$id,$mid]);
   body_listing_flash('İlandan ayrıldın.');
 }elseif(in_array($action,['accept','reject'],true)){
   if($mid!==$owner)throw new RuntimeException('Katılımcıları yalnızca ilan sahibi yönetebilir.');
   $target=(int)($_POST['target']??0);$q=$db->prepare("SELECT u.id,u.birth_date,u.age_band,u.gender,u.status FROM users u JOIN body_listing_members m ON m.user_id=u.id WHERE m.listing_id=? AND m.user_id=? AND m.status='pending'");$q->execute([$id,$target]);$u=$q->fetch();
   if(!$u||$u['status']!=='active'||!body_listing_allowed($l,$u)||!body_listing_gender_allowed($l,$u,$db)||!social_can_view($target,$mid))throw new RuntimeException('Katılım isteği uygun değil.');
   $db->prepare('UPDATE body_listing_members SET status=? WHERE listing_id=? AND user_id=?')->execute([$action==='accept'?'accepted':'rejected',$id,$target]);
   body_listing_flash('Katılım isteği güncellendi.');
   body_emit_notification($db,$target,$mid,'listing_update','Katılım durumu',$action==='accept'?'İlan katılım isteğin kabul edildi.':'İlan katılım isteğin reddedildi.');
 }elseif(in_array($action,['ready','unready','writers_all','writers_owner'],true)){
   if($mid!==$owner)throw new RuntimeException('Sohbet ayarlarını yalnızca ilan sahibi yönetebilir.');
   if($action==='ready'||$action==='unready')$db->prepare('UPDATE body_listings SET chat_ready=? WHERE id=?')->execute([$action==='ready'?1:0,$id]);
   else $db->prepare('UPDATE body_listings SET chat_writers=? WHERE id=?')->execute([$action==='writers_all'?'all':'owner',$id]);
   body_listing_flash('Sohbet ayarları güncellendi.');
 }else throw new RuntimeException('Geçersiz işlem.');
 $db->commit();
}catch(Throwable $e){if(isset($db)&&$db->inTransaction())$db->rollBack();error_log('ALDZ listing membership: '.$e->getMessage());body_listing_flash($e instanceof RuntimeException?$e->getMessage():'İşlem tamamlanamadı.');}
body_redirect('listing_room.php?id='.$id);
