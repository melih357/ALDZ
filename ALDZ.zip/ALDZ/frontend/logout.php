<?php
declare(strict_types=1);
require_once __DIR__.'/../private/auth.php';
if ($_SERVER['REQUEST_METHOD']!=='POST' || !body_valid_csrf()) {http_response_code(403);exit('İşlem reddedildi.');}
$_SESSION=[];
if (ini_get('session.use_cookies')) { $p=session_get_cookie_params(); setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']); }
session_destroy();
header('Location: auth.php?mode=login',true,303);exit;
