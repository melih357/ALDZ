<?php
declare(strict_types=1);
require_once __DIR__.'/../private/body_notifications.php';
require_once __DIR__.'/../private/social_helpers.php';
require_once __DIR__.'/../private/social_media_v24.php';
require_once __DIR__.'/../private/video_chunk_lib.php';
$user=body_require_login();$me=(int)$user['id'];
if($_SERVER['REQUEST_METHOD']==='POST' && empty($_POST) && (int)($_SERVER['CONTENT_LENGTH']??0)>0){
 $size=body42_ini_bytes((string)ini_get('post_max_size'));
 if($size>0 && (int)$_SERVER['CONTENT_LENGTH']>$size){
  $_SESSION['social_flash']='Video yüklenemedi: PHP post_max_size sınırı ('.ini_get('post_max_size').') aşıldı. WAMP PHP ayarlarını 300M / 256M olarak güncelle ve Apache hizmetini yeniden başlat.';
  body_redirect('social.php');
 }
}
if($_SERVER['REQUEST_METHOD']!=='POST'||!body_valid_csrf()){http_response_code(403);exit('Geçersiz istek.');}
$action=(string)($_POST['action']??'');$target=(int)($_POST['target']??0);
$back=(string)($_POST['back']??'social.php');if(!str_starts_with($back,'social.php')&&!str_starts_with($back,'index.php'))$back='social.php';
try{
$db=body_db();
switch($action){
case 'post24':
    $kind=(string)($_POST['media_type']??'photo');if(!in_array($kind,['photo','outfit','video_short','video_long'],true))throw new RuntimeException('Geçersiz medya türü.');
    $caption=trim((string)($_POST['caption']??''));if(mb_strlen($caption)>2000)throw new RuntimeException('Açıklama çok uzun.');
    // If post_max_size is exceeded, PHP silently clears both $_POST and $_FILES.
    $staged=(string)($_POST['staged_video']??'');
    $isVideo=in_array($kind,['video_short','video_long'],true);
    $uploaded=[];
    if($isVideo && $staged!==''){
      $uploaded[]=body44_consume($staged,$me,$kind);
    }else{
      $files=$_FILES['media']??null;
      if(!$files||!isset($files['name'])||!is_array($files['name']))throw new RuntimeException('Dosya alınamadı. Sayfayı yenileyip tekrar dene.');
      $n=count($files['name']);if($n<1||$n>($isVideo?1:8))throw new RuntimeException('Fotoğraf 1–8, video yalnızca 1 dosya olmalı.');
      foreach(range(0,$n-1) as $i){
        $_FILES['_body24_one']=['name'=>$files['name'][$i],'type'=>$files['type'][$i],'tmp_name'=>$files['tmp_name'][$i],'error'=>$files['error'][$i],'size'=>$files['size'][$i]];
        $uploaded[]=body24_upload('_body24_one',$isVideo,$kind==='video_long'?'long':'short');
      }
    }
    $db->beginTransaction();
    $db->prepare('INSERT INTO social_posts(user_id,caption,media_path) VALUES(?,?,?)')->execute([$me,$caption,$uploaded[0]['path']]);
    $post=(int)$db->lastInsertId();
    $insert=$db->prepare('INSERT INTO body_post_media(post_id,media_path,media_kind,position) VALUES(?,?,?,?)');
    foreach($uploaded as $i=>$file)$insert->execute([$post,$file['path'],$file['kind'],$i]);
    $style=trim((string)($_POST['outfit_style']??''));$details=trim((string)($_POST['outfit_details']??''));if(mb_strlen($style)>80||mb_strlen($details)>500)throw new RuntimeException('Kombin bilgileri çok uzun.');if($kind!=='outfit'){$style='';$details='';}
    $db->prepare('INSERT INTO body_post_options(post_id,comments_enabled,video_length,post_category,outfit_style,outfit_details) VALUES(?,?,?,?,?,?)')->execute([$post,isset($_POST['comments_enabled'])?1:0,$kind==='video_long'?'long':($kind==='video_short'?'short':null),$kind==='outfit'?'outfit':'standard',$style,$details]);
    $db->commit();body24_mentions($caption,$db,$me,$post);
    break;
case 'comments24':
    $q=$db->prepare('SELECT user_id FROM social_posts WHERE id=?');$q->execute([$target]);if((int)$q->fetchColumn()!==$me)throw new RuntimeException('Yalnızca gönderi sahibi değiştirebilir.');
    $enabled=(int)($_POST['enabled']??0)===1?1:0;
    $db->prepare('INSERT INTO body_post_options(post_id,comments_enabled) VALUES(?,?) ON DUPLICATE KEY UPDATE comments_enabled=VALUES(comments_enabled)')->execute([$target,$enabled]);break;
case 'repost24':
    $q=$db->prepare('SELECT user_id FROM social_posts WHERE id=?');$q->execute([$target]);$owner=(int)$q->fetchColumn();
    if(!$owner||$owner===$me||!body38_can_view_content($owner,$me))throw new RuntimeException('Bu gönderiyi repostlayamazsın.');
    $visibility=(string)($_POST['visibility']??'followers');if(!in_array($visibility,['everyone','followers'],true))throw new RuntimeException('Geçersiz görünürlük.');
    if((int)social_prefs($owner)['account_private'])$visibility='followers';
    $existing=$db->prepare('SELECT id FROM body_post_reposts WHERE post_id=? AND user_id=?');$existing->execute([$target,$me]);
    if($existing->fetchColumn() && ($_POST['remove']??'')==='1'){
      $db->prepare('DELETE FROM body_post_reposts WHERE post_id=? AND user_id=?')->execute([$target,$me]);
      $_SESSION['social_flash']='Repost kaldırıldı.';
    }else{
      $db->prepare('INSERT INTO body_post_reposts(post_id,user_id,visibility) VALUES(?,?,?) ON DUPLICATE KEY UPDATE visibility=VALUES(visibility),created_at=NOW()')->execute([$target,$me,$visibility]);
      $_SESSION['social_flash']='Gönderi yeniden paylaşıldı.';
    }
    break;
case 'share24':
    $recipient=ltrim(mb_strtolower(trim((string)($_POST['recipient']??''))),'@');
    $q=$db->prepare("SELECT id FROM users WHERE username=? AND status='active'");$q->execute([$recipient]);$peer=(int)$q->fetchColumn();
    $q=$db->prepare('SELECT user_id FROM social_posts WHERE id=?');$q->execute([$target]);$owner=(int)$q->fetchColumn();
    if(!$peer||$peer===$me||!$owner||!social_can_view($owner,$peer)||!social_can_view($owner,$me)||!body_same_age_band($peer,$me))throw new RuntimeException('Arkadaş veya gönderi erişimi uygun değil.');
    $q=$db->prepare("SELECT 1 FROM social_follows WHERE ((follower_id=? AND following_id=?) OR (follower_id=? AND following_id=?)) AND status='accepted' LIMIT 1");$q->execute([$me,$peer,$peer,$me]);
    if(!$q->fetchColumn()||!social_can_view($peer,$me)||!social_can_view($me,$peer))throw new RuntimeException('Mesaj göndermek için kabul edilmiş takip bağlantısı gerekli.');
    $db->beginTransaction();
    $q=$db->prepare("SELECT c.id FROM conversations c JOIN conversation_participants p1 ON p1.conversation_id=c.id AND p1.user_id=? AND p1.status='active' JOIN conversation_participants p2 ON p2.conversation_id=c.id AND p2.user_id=? AND p2.status='active' WHERE c.kind='direct' LIMIT 1");$q->execute([$me,$peer]);$cid=(int)$q->fetchColumn();
    if(!$cid){$db->prepare("INSERT INTO conversations(kind,created_by,created_at,updated_at) VALUES('direct',?,NOW(),NOW())")->execute([$me]);$cid=(int)$db->lastInsertId();$db->prepare("INSERT INTO conversation_participants(conversation_id,user_id,status,joined_at) VALUES(?,?,'active',NOW())")->execute([$cid,$me]);$db->prepare("INSERT INTO conversation_participants(conversation_id,user_id,status,joined_at) VALUES(?,?,'active',NOW())")->execute([$cid,$peer]);}
    $msg='ALDZ paylaşımı: social.php?view=profile&user='.$owner.'#post-'.$target;
    $db->prepare("INSERT INTO messages(conversation_id,sender_id,body,message_type,created_at,updated_at) VALUES(?,?,?,'text',NOW(),NOW())")->execute([$cid,$me,$msg]);
    $db->prepare('UPDATE conversations SET updated_at=NOW() WHERE id=?')->execute([$cid]);$db->commit();body_emit_notification($db,$peer,$me,'direct_message','Yeni paylaşım','Bir arkadaşın sana gönderi gönderdi.');break;
case 'cover':
    $media=social_upload('image');
    $db->prepare('UPDATE profiles SET cover_path=?,updated_at=NOW() WHERE user_id=?')->execute([$media,$me]);
    break;
case 'avatar':
    $media=social_upload('image');
    $db->prepare('UPDATE profiles SET avatar_path=?,updated_at=NOW() WHERE user_id=?')->execute([$media,$me]);
    break;
case 'post':case 'story':
    $media=social_upload('image');
    if($action==='post'){
        $caption=trim((string)($_POST['caption']??''));if(mb_strlen($caption)>2000)throw new RuntimeException('Açıklama çok uzun.');
        $db->prepare('INSERT INTO social_posts(user_id,caption,media_path) VALUES(?,?,?)')->execute([$me,$caption,$media]);
    } else $db->prepare('INSERT INTO social_stories(user_id,media_path,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 24 HOUR))')->execute([$me,$media]);
    break;
case 'comment':
    $body=trim((string)($_POST['body']??''));if(!$body||mb_strlen($body)>1000)throw new RuntimeException('Yorum 1–1000 karakter olmalı.');
    $q=$db->prepare('SELECT user_id FROM social_posts WHERE id=?');$q->execute([$target]);$owner=(int)$q->fetchColumn();
    if(!$owner||!social_can_view($owner,$me))throw new RuntimeException('Bu gönderiye yorum yapamazsın.');
    $q=$db->prepare('SELECT comments_enabled FROM body_post_options WHERE post_id=?');$q->execute([$target]);if($q->fetchColumn()==='0')throw new RuntimeException('Gönderi sahibi yorumları kapatmış.');
    $db->prepare('INSERT INTO social_post_comments(post_id,user_id,body) VALUES(?,?,?)')->execute([$target,$me,$body]);social_notify($owner,$me,'comment','Gönderine yeni bir yorum yapıldı.');break;
case 'like':
    $q=$db->prepare('SELECT user_id FROM social_posts WHERE id=?');$q->execute([$target]);$owner=(int)$q->fetchColumn();
    if(!$owner||!social_can_view($owner,$me))throw new RuntimeException('Bu gönderi görüntülenemiyor.');
    $q=$db->prepare('SELECT 1 FROM social_post_likes WHERE post_id=? AND user_id=?');$q->execute([$target,$me]);
    if($q->fetchColumn())$db->prepare('DELETE FROM social_post_likes WHERE post_id=? AND user_id=?')->execute([$target,$me]);
    else {$db->prepare('INSERT INTO social_post_likes(post_id,user_id) VALUES(?,?)')->execute([$target,$me]);social_notify($owner,$me,'like','Gönderin beğenildi.');}
    break;
case 'follow':
    if(!$target||$target===$me||!body_same_age_band($me,$target)||social_blocked($db,$me,$target))throw new RuntimeException('Bu kişiyi takip edemezsin.');
    $q=$db->prepare('SELECT id FROM users WHERE id=? AND status="active"');$q->execute([$target]);if(!$q->fetchColumn())throw new RuntimeException('Kullanıcı bulunamadı.');
    $q=$db->prepare('SELECT 1 FROM social_follows WHERE follower_id=? AND following_id=?');$q->execute([$me,$target]);
    if($q->fetchColumn())$db->prepare('DELETE FROM social_follows WHERE follower_id=? AND following_id=?')->execute([$me,$target]);
    else {$private=social_prefs($target)['account_private'];$db->prepare('INSERT INTO social_follows(follower_id,following_id,status) VALUES(?,?,?)')->execute([$me,$target,$private?'pending':'accepted']);social_notify($target,$me,'follow',$private?'Yeni takip isteğin var.':'Yeni bir takipçin var.');}break;
case 'approve':case 'reject':
    $db->prepare("UPDATE social_follows SET status=? WHERE follower_id=? AND following_id=? AND status='pending'")->execute([$action==='approve'?'accepted':'pending',$target,$me]);
    if($action==='reject')$db->prepare("DELETE FROM social_follows WHERE follower_id=? AND following_id=? AND status='pending'")->execute([$target,$me]);
    break;
case 'block':
    if(!$target||$target===$me)throw new RuntimeException('Kullanıcı seçilemedi.');
    $check=$db->prepare("SELECT 1 FROM users WHERE id=? AND status='active'");$check->execute([$target]);if(!$check->fetchColumn())throw new RuntimeException('Bu kullanıcı bulunamadı.');
    $db->prepare('INSERT IGNORE INTO user_blocks(blocker_id,blocked_id,created_at) VALUES(?,?,NOW())')->execute([$me,$target]);
    $db->prepare('DELETE FROM social_follows WHERE (follower_id=? AND following_id=?) OR (follower_id=? AND following_id=?)')->execute([$me,$target,$target,$me]);break;
case 'unblock':$db->prepare('DELETE FROM user_blocks WHERE blocker_id=? AND blocked_id=?')->execute([$me,$target]);break;
case 'username':
    $username=mb_strtolower(trim((string)($_POST['username']??'')));
    if(!preg_match('/^[a-z][a-z0-9._]{3,29}$/D',$username))throw new RuntimeException('Kullanıcı adı 4–30 karakter olmalı ve yalnızca küçük harf, rakam, nokta ya da alt çizgi içermeli.');
    $check=$db->prepare('SELECT id FROM users WHERE username=? AND id<>? LIMIT 1');$check->execute([$username,$me]);
    if($check->fetchColumn())throw new RuntimeException('Bu kullanıcı adı başkası tarafından kullanılıyor.');
    try{$db->prepare('UPDATE users SET username=?, updated_at=NOW() WHERE id=?')->execute([$username,$me]);}
    catch(PDOException $e){if($e->getCode()==='23000')throw new RuntimeException('Bu kullanıcı adı başkası tarafından kullanılıyor.');throw $e;}
    break;
case 'cities':
    $cities=require __DIR__.'/../private/body_cities.php';
    $city1=trim((string)($_POST['city_primary']??''));
    $city2=trim((string)($_POST['city_secondary']??''));
    if(!in_array($city1,$cities,true)||($city2!=='' && !in_array($city2,$cities,true))||($city1!==''&&$city1===$city2))throw new RuntimeException('Geçerli ve farklı şehirler seç.');
    $q=$db->prepare('SELECT preferences FROM profiles WHERE user_id=?');$q->execute([$me]);
    $prefs=json_decode((string)$q->fetchColumn(),true);if(!is_array($prefs))$prefs=[];
    $prefs['discovery_city2']=$city2;
    $db->prepare('UPDATE profiles SET city=?,preferences=?,updated_at=NOW() WHERE user_id=?')->execute([$city1,json_encode($prefs,JSON_UNESCAPED_UNICODE),$me]);
    break;
case 'settings':
    $private=isset($_POST['private'])?1:0;
    $visibility=(string)($_POST['follow_visibility']??'');
    if($visibility!==''){
      if(!in_array($visibility,['everyone','following','mutual','only_me'],true))throw new RuntimeException('Geçersiz takip listesi görünürlüğü.');
      $db->prepare('INSERT INTO social_preferences(user_id,follow_visibility) VALUES(?,?) ON DUPLICATE KEY UPDATE follow_visibility=VALUES(follow_visibility)')->execute([$me,$visibility]);
    }
    $language=(string)($_POST['language']??'tr');if(!in_array($language,['tr','en','es','ar','it'],true))throw new RuntimeException('Geçersiz dil.');
    $db->prepare('INSERT INTO social_preferences(user_id,account_private,language_code) VALUES(?,?,?) ON DUPLICATE KEY UPDATE account_private=VALUES(account_private),language_code=VALUES(language_code)')->execute([$me,$private,$language]);
    $bio=trim((string)($_POST['bio']??''));if(mb_strlen($bio)>500)throw new RuntimeException('Biyografi 500 karakteri geçemez.');
    $db->prepare('UPDATE profiles SET bio=?,updated_at=NOW() WHERE user_id=?')->execute([$bio,$me]);
    break;
default:throw new RuntimeException('Bilinmeyen işlem.');
}
if(empty($_SESSION['social_flash']))$_SESSION['social_flash']='İşlem kaydedildi.';
}catch(Throwable $e){$_SESSION['social_flash']='İşlem yapılamadı: '.$e->getMessage();}
body_redirect($back);
function social_blocked(PDO $db,int $a,int $b): bool {
 $q=$db->prepare('SELECT 1 FROM user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?)');$q->execute([$a,$b,$b,$a]);return(bool)$q->fetchColumn();
}
