<?php
declare(strict_types=1);
require_once __DIR__.'/../private/auth.php';
require_once __DIR__.'/../private/body_terms.php';
$mode = ($_GET['mode'] ?? 'login') === 'register' ? 'register' : 'login';
if (body_user()) body_redirect('./');
$cities=require __DIR__.'/../private/body_cities.php';
$errors=[];$badCredentials=false;$old=['first'=>'','last'=>'','username'=>'','email'=>'','birth'=>'','city'=>''];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $postedMode = ($_POST['mode'] ?? 'login') === 'register' ? 'register' : 'login';
    $mode=$postedMode;
    $old=['first'=>trim((string)($_POST['first']??'')),'last'=>trim((string)($_POST['last']??'')),'username'=>mb_strtolower(trim((string)($_POST['username']??''))),'email'=>trim((string)($_POST['email']??'')),'birth'=>trim((string)($_POST['birth']??'')),'city'=>trim((string)($_POST['city']??''))];
    $pass=(string)($_POST['password']??'');
    if (!body_valid_csrf()) $errors[]='Güvenlik doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || strlen($old['email'])>190) $errors[]='Geçerli bir e-posta adresi girin.';
    if ($mode==='register') {
        if ($old['first']==='' || $old['last']==='' || mb_strlen($old['first'])>50 || mb_strlen($old['last'])>50) $errors[]='Adınızı ve soyadınızı doğru girin (en fazla 50 karakter).';
        if (!preg_match('/^[a-z][a-z0-9._]{3,29}$/D',$old['username'])) $errors[]='Kullanıcı adı 4–30 karakter olmalı; küçük harfle başlamalı, yalnızca a-z, 0-9, nokta ve alt çizgi içermeli.';
        if (strlen($pass)<12 || strlen($pass)>128) $errors[]='Şifre 12–128 karakter arasında olmalıdır.';
        if ($pass !== (string)($_POST['confirm_password']??'')) $errors[]='Şifreler eşleşmiyor.';
        $d=DateTimeImmutable::createFromFormat('!Y-m-d',$old['birth']);
        if (!$d || $d->format('Y-m-d')!==$old['birth'] || $d > new DateTimeImmutable('-13 years') || $d < new DateTimeImmutable('-110 years')) $errors[]='ALDZ’ye kayıt için en az 13 yaşında olmalısınız.';
        if (!in_array($old['city'],$cities,true)) $errors[]='Yaşadığın şehri seç.';
        $termsAck=$_SESSION['body_terms_accept']??null;
        if (!is_array($termsAck) || ($termsAck['version']??'')!==ALDZ_TERMS_VERSION || ($termsAck['nonce']??'')!==(string)($_POST['terms_nonce']??'') || time()-(int)($termsAck['at']??0)>1800 || empty($_POST['accept_terms'])) $errors[]='Üyelik sözleşmesini sonuna kadar okuyup ayrı onay vermelisiniz.';
    }
    if (count($_SESSION['body_attempts']??[])>=12) {
        $_SESSION['body_attempts']=array_filter($_SESSION['body_attempts'],fn($t)=>$t>time()-900);
    }
    $_SESSION['body_attempts']=array_values(array_filter($_SESSION['body_attempts']??[],fn($t)=>$t>time()-900));
    if (count($_SESSION['body_attempts'])>=10) $errors[]='Çok fazla deneme yapıldı. 15 dakika sonra tekrar deneyin.';
    if (!$errors) {
        $_SESSION['body_attempts'][]=time();
        try {
            $db=body_db();
            if ($mode==='register') {
                $email=mb_strtolower($old['email']);
                $q=$db->prepare('SELECT id FROM users WHERE email=? LIMIT 1');$q->execute([$email]);
                if ($q->fetch()) $errors[]='Bu e-posta adresiyle zaten kayıt yapılmış.';
                $q=$db->prepare('SELECT id FROM users WHERE username=? LIMIT 1');$q->execute([$old['username']]);
                if ($q->fetch()) $errors[]='Bu kullanıcı adı alınmış. Lütfen başka bir kullanıcı adı seç.';
                if (!$errors) {
                    $db->beginTransaction();
                    try {
                        $username=$old['username'];
                        $q=$db->prepare("INSERT INTO users(name,username,email,password,birth_date,age_band,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'active',NOW(),NOW())");
                        $q->execute([trim($old['first'].' '.$old['last']),$username,$email,password_hash($pass,PASSWORD_DEFAULT),$old['birth'], $d > new DateTimeImmutable('-18 years') ? 'minor' : 'adult']);
                        $id=(int)$db->lastInsertId();
                        $q=$db->prepare('INSERT INTO profiles(user_id,city,created_at,updated_at) VALUES(?,?,NOW(),NOW())');$q->execute([$id,$old['city']]);
                        $q=$db->prepare("INSERT INTO role_user(user_id,role_id,created_at) SELECT ?,id,NOW() FROM roles WHERE name='member'");$q->execute([$id]);
                        $signupLanguage=(string)($_COOKIE['body_language']??'tr');
                        if(!in_array($signupLanguage,['tr','en','es','it','ar'],true))$signupLanguage='tr';
                        $db->prepare('INSERT INTO social_preferences(user_id,language_code) VALUES(?,?)')->execute([$id,$signupLanguage]);
                        $consent=$db->prepare('INSERT INTO user_terms_acceptances(user_id,terms_version,accepted_at,ip_hash,user_agent_hash) VALUES(?,?,NOW(),?,?)');
                        $consent->execute([$id,ALDZ_TERMS_VERSION,hash('sha256',(string)($_SERVER['REMOTE_ADDR']??'').'|aldz-terms'),hash('sha256',(string)($_SERVER['HTTP_USER_AGENT']??''))]);
                        $db->commit();unset($_SESSION['body_terms_accept']);
                        session_regenerate_id(true);$_SESSION['body_user_id']=$id;$_SESSION['body_csrf']=bin2hex(random_bytes(32));
                        body_redirect('./');
                    } catch (Throwable $e) {$db->rollBack();throw $e;}
                }
            } else {
                $q=$db->prepare('SELECT id,password,status FROM users WHERE email=? LIMIT 1');
                $q->execute([mb_strtolower($old['email'])]);$u=$q->fetch();
                if ($u && $u['status']==='active' && password_verify($pass,$u['password'])) {
                    if (password_needs_rehash($u['password'],PASSWORD_DEFAULT)) {
                        $q=$db->prepare('UPDATE users SET password=?,updated_at=NOW() WHERE id=?');$q->execute([password_hash($pass,PASSWORD_DEFAULT),$u['id']]);
                    }
                    session_regenerate_id(true);$_SESSION['body_user_id']=(int)$u['id'];$_SESSION['body_csrf']=bin2hex(random_bytes(32));
                    body_redirect('./');
                }
                $errors[]='E-posta veya şifre hatalı.';
                $badCredentials=true;
            }
        } catch (PDOException $e) {
            if ($e->getCode()==='23000') { $errors[]='E-posta veya kullanıcı adı zaten kullanılıyor. Farklı bir kullanıcı adı deneyin.'; } else {
            error_log('ALDZ database authentication error: '.$e->getMessage());
            $errors[]='Veritabanına bağlanılamadı veya kurulum tamamlanmadı. Kurulum rehberini kontrol edin.';
            }
        } catch (Throwable $e) {
            error_log('ALDZ auth error: '.$e->getMessage());
            $errors[]='İşlem tamamlanamadı. Lütfen tekrar deneyin.';
        }
    }
}
?>
<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#0c1026"><meta name="robots" content="noindex"><title><?= $mode === 'register' ? 'Kayıt Ol' : 'Giriş Yap' ?> — ALDZ</title><link rel="manifest" href="manifest.json"><link rel="stylesheet" href="css/auth.css?v=47"><link rel="stylesheet" href="css/terms-v34.css"><link rel="stylesheet" href="css/aldz-i18n-v39.css?v=39"></head><body><div class="aldz-language-public"><label for="bodyLanguagePublic">Language / Idioma / Lingua / اللغة</label><select id="bodyLanguagePublic" aria-label="Language"><option value="tr">Türkçe</option><option value="en">English</option><option value="es">Español</option><option value="it">Italiano</option><option value="ar">العربية</option></select></div>
<div class="glow g1"></div><div class="glow g2"></div><div class="shell">
<section class="story">
 <a class="brand" href="./"><img src="assets/logo-mark.png" alt="ALDZ" style="width:39px;height:39px;object-fit:contain"> ALDZ <span class="brand-sub">BİRLİKTE DAHA GÜZEL</span></a>
 <div class="story-inner"><div class="mini">✦ &nbsp; ORTAK İLGİLER, GERÇEK BAĞLANTILAR</div><h1>Hayatın güzel tarafı, <span>birlikte.</span></h1><p>Yeni insanlarla tanış, etkinliklere katıl, deneyimlerini ve güzel anlarını paylaş.</p><div class="visual"><img src="assets/hero-banner.png" alt="ALDZ ile yeni arkadaşlarla buluşma"></div><div class="features"><span>✧ Yeni bağlantılar</span><span>✧ Ortak aktiviteler</span><span>✧ Gerçek topluluklar</span></div></div>
 <div class="foot-story">ALDZ © <?= date('Y') ?> · Gerçek hayatta daha fazla bağlantı.</div>
</section>
<section class="auth"><div class="auth-top"><span class="pill"><span class="dot"></span> ALDZ TOPLULUĞU</span><a class="back" href="./">← Ana sayfa</a></div>
<div class="auth-main<?= $badCredentials ? ' aldz-login-shake' : '' ?>" id="bodyAuthPanel"><div class="form-head"><div class="overline">BİRLİKTE DAHA GÜZEL</div><h2><?= $mode === 'register' ? 'Aramıza katıl.' : 'Tekrar hoş geldin.' ?></h2><p><?= $mode === 'register' ? 'ALDZ dünyasına katıl, yeni bağlantılara ilk adımı at.' : 'Hesabınla giriş yaparak ALDZ dünyasına dön.' ?></p></div>
<div class="tabs"><a class="<?= $mode === 'login' ? 'active' : '' ?>" href="?mode=login">Giriş yap</a><a class="<?= $mode === 'register' ? 'active' : '' ?>" href="?mode=register">Kayıt ol</a></div>
<?php if ($errors): ?><div class="message" role="alert"><?= implode('<br>', array_map('body_e',$errors)) ?></div><?php endif; ?>
<form id="authForm" method="post" action="auth.php?mode=<?= $mode ?>">
 <input type="hidden" name="mode" value="<?= $mode ?>"><input type="hidden" name="csrf" value="<?= body_e(body_csrf()) ?>">
<?php if ($mode === 'register'): ?>
<div class="name-row"><label>Ad<input name="first" type="text" autocomplete="given-name" placeholder="Adın" maxlength="50" value="<?= body_e($old['first']) ?>" required></label><label>Soyad<input name="last" type="text" autocomplete="family-name" placeholder="Soyadın" maxlength="50" value="<?= body_e($old['last']) ?>" required></label></div>
<label>Kullanıcı adı (@)<input name="username" type="text" minlength="4" maxlength="30" pattern="[a-z][a-z0-9._]{3,29}" autocomplete="username" autocapitalize="off" spellcheck="false" placeholder="ornek.kullanici" value="<?= body_e($old['username']) ?>" required><small class="username-help">4–30 karakter, yalnızca küçük harf, rakam, nokta ve _ . Her kullanıcı adı tektir.</small></label>
<?php endif; ?>
<label>E-posta adresi<input name="email" type="email" autocomplete="email" placeholder="ornek@eposta.com" maxlength="190" value="<?= body_e($old['email']) ?>" required></label>
<label>Şifre<div class="password<?= $badCredentials ? ' aldz-input-invalid' : '' ?>"><input name="password" id="pass" type="password" autocomplete="<?= $mode === 'register' ? 'new-password' : 'current-password' ?>" placeholder="<?= $mode==='register'?'En az 12 karakter':'Şifren' ?>" <?= $mode==='register'?'minlength="12"':' ' ?> maxlength="128" required><button id="toggle" type="button" aria-label="Şifreyi göster">Göster</button></div></label>
<?php if ($mode === 'register'): ?>
<label>Şifre tekrar<div class="password"><input name="confirm_password" type="password" autocomplete="new-password" placeholder="Şifreni tekrar gir" minlength="12" maxlength="128" required></div></label>
<label>Doğum tarihi (13+)<input name="birth" type="date" autocomplete="bday" max="<?= date('Y-m-d',strtotime('-13 years')) ?>" value="<?= body_e($old['birth']) ?>" required></label>
<label>Yaşadığın şehir<select name="city" required style="min-height:49px;border-radius:12px;background:#171d35;color:#fff;border:1px solid #303651;padding:0 14px"><option value="">Şehir seç</option><?php foreach($cities as $city): ?><option value="<?=body_e($city)?>" <?=$old['city']===$city?'selected':''?>><?=body_e($city)?></option><?php endforeach; ?></select></label>
<div class="aldz-terms-consent"><input type="hidden" id="termsNonce" name="terms_nonce" value=""><input type="hidden" id="termsVersion" name="terms_version" value="<?= body_e(ALDZ_TERMS_VERSION) ?>"><input type="hidden" name="accept_terms" value="1"><button class="aldz-terms-launch" id="termsLaunch" type="button" aria-pressed="false"><span class="fake-check" aria-hidden="true"></span><span id="termsLabel">Üyelik Sözleşmesini oku ve kabul et</span></button><p class="aldz-terms-status">Sözleşme metni açılır; sonuna ulaşıp onay vermeden kayıt tamamlanmaz.</p><p class="aldz-terms-status"><a href="rules.php" target="_blank" rel="noopener">Topluluk kuralları</a> · <a href="privacy.php" target="_blank" rel="noopener">KVKK Aydınlatması</a> (ayrı bilgilendirme, onay kutusu değildir)</p></div>
<?php endif; ?>
<button class="submit" type="submit"><?= $mode === 'register' ? 'ALDZ’ye katıl' : 'Giriş yap' ?> <span>↗</span></button>
</form>
<div class="bottom"><?= $mode === 'register' ? 'Zaten hesabın var mı?' : 'Henüz bir hesabın yok mu?' ?> <a href="?mode=<?= $mode === 'register' ? 'login' : 'register' ?>"><?= $mode === 'register' ? 'Giriş yap' : 'Hemen katıl' ?></a></div>
<p class="preview">Şifre sıfırlama ve e-posta doğrulama sonraki aşamada etkinleştirilecek. Hesap güvenliği için güçlü bir şifre seç.</p>
</div><div class="auth-footer">Güvenli topluluklar · Gerçek bağlantılar</div></section>
</div>
<?php if ($mode==='register'): ?><div class="aldz-terms-modal" id="termsModal" hidden><div class="aldz-terms-dialog" role="dialog" aria-modal="true" aria-labelledby="termsTitle"><div class="aldz-terms-head"><h2 id="termsTitle">ALDZ Kullanıcı Sözleşmesi</h2><button type="button" id="termsClose" class="aldz-terms-close" aria-label="Pencereyi kapat">×</button></div><div id="termsScroll" class="aldz-terms-scroll" tabindex="0"><p class="aldz-legal-language-notice" hidden>Hukuki metnin bağlayıcı sürümü Türkçedir. Diğer dillerde onaylı hukuki çeviri henüz bulunmuyor.</p><?php require __DIR__.'/../private/terms_content.php'; ?></div><div class="aldz-terms-bottom"><label><input id="termsRead" type="checkbox" disabled><span>Sözleşmeyi okudum, anladım ve kabul ediyorum.</span></label><div class="aldz-terms-actions"><small id="termsStatus" role="status">Sözleşmenin sonuna kadar kaydırmalısın.</small><button id="termsApprove" type="button" disabled>Kabul et ve devam et</button></div></div></div></div><script src="js/terms-v34.js" defer></script><?php endif; ?>
<script>document.querySelector('#toggle').addEventListener('click',()=>{const p=document.querySelector('#pass'),t=document.querySelector('#toggle');p.type=p.type==='password'?'text':'password';t.textContent=p.type==='password'?'Göster':'Gizle'});</script>
<script src="js/aldz-i18n-v39.js?v=39" defer></script></body></html>
