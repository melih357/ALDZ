<?php
declare(strict_types=1);
require_once __DIR__.'/../private/social_helpers.php';
require_once __DIR__.'/../private/video_chunk_lib.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function body44_json(int $code,array $data):never {http_response_code($code);echo json_encode($data,JSON_UNESCAPED_UNICODE);exit;}
try {
 if(($_SERVER['REQUEST_METHOD']??'')!=='POST')body44_json(405,['error'=>'Bu işlem desteklenmiyor.']);
 $user=body_require_login();$uid=(int)$user['id'];
 // Header allows raw octet-stream chunks (not blocked by PHP upload_max_filesize).
 $csrf=(string)($_SERVER['HTTP_X_ALDZ_CSRF']??'');
 if($csrf==='' || !hash_equals((string)body_csrf(),$csrf))body44_json(403,['error'=>'Güvenlik doğrulaması başarısız. Sayfayı yenile.']);
 $op=(string)($_GET['op']??'');
 if($op==='init'){
  $size=filter_var($_POST['size']??null,FILTER_VALIDATE_INT);
  $kind=(string)($_POST['kind']??'');
  if(!$size || $size<1 || $size>ALDZ_VIDEO_MAX_BYTES || !in_array($kind,['video_short','video_long'],true))throw new RuntimeException('Video 1 GB’dan büyük olamaz veya türü geçersiz.');
  $dir=body44_dir();
  $active=0;foreach(glob($dir.'/*.json')?:[] as $candidate){
   $record=json_decode((string)@file_get_contents($candidate),true);
   if(is_array($record) && (int)($record['uid']??0)===$uid && filemtime($candidate)>time()-86400 && is_file(substr($candidate,0,-5).'.part'))$active++;
  }
  if($active>=3)throw new RuntimeException('En fazla 3 video yüklemesi aynı anda açık olabilir. Bir süre sonra yeniden dene.');
  // Best effort cleanup of abandoned uploads older than a day.
  foreach(glob($dir.'/*.json')?:[] as $file){if(filemtime($file)<time()-86400){@unlink(substr($file,0,-5).'.part');@unlink($file);}}
  $id=bin2hex(random_bytes(24));[$meta,$part]=body44_paths($id);
  $state=['uid'=>$uid,'size'=>$size,'kind'=>$kind,'created'=>time(),'ready'=>false];
  if(file_put_contents($meta,json_encode($state),LOCK_EX)===false || file_put_contents($part,'')===false)throw new RuntimeException('Geçici dosya oluşturulamadı. private/video_staging klasörünün yazma iznini kontrol et.');
  clearstatcache(true,$meta);
  $check=json_decode((string)@file_get_contents($meta),true);
  if(!is_array($check) || (int)($check['uid']??0)!==$uid || !is_file($part))throw new RuntimeException('Video oturumu diske kaydedilemedi. private/video_staging klasörünün yazma iznini kontrol et.');
  body44_json(200,['id'=>$id]);
 }
 $id=(string)($_GET['id']??'');[$meta,$part]=body44_paths($id);
 // c+ creates a missing metadata file and then reports an expired session. Do not create missing sessions.
 if(!is_file($meta))body44_json(409,['error'=>'Yükleme oturumu sunucuda bulunamadı. Yeni oturum açılıyor.','code'=>'SESSION_MISSING']);
 $fp=@fopen($meta,'r+b');if(!$fp||!flock($fp,LOCK_EX))body44_json(409,['error'=>'Video oturumu okunamadı. Sunucu dosya izinlerini kontrol et.','code'=>'SESSION_UNREADABLE']);
 try {
  rewind($fp);$state=json_decode((string)stream_get_contents($fp),true);
  if(!is_array($state))body44_json(409,['error'=>'Video oturum kaydı bozuk veya boş. Yeni oturum açılıyor.','code'=>'SESSION_MISSING']);
  if((int)($state['uid']??0)!==$uid)body44_json(403,['error'=>'Yükleme oturumu bu hesaba ait değil.','code'=>'SESSION_OWNER']);
  if(time()-(int)($state['created']??0)>86400)body44_json(409,['error'=>'Yükleme oturumu zaman aşımına uğradı.','code'=>'SESSION_MISSING']);
  $size=(int)$state['size'];$offset=is_file($part)?filesize($part):0;
  if($op==='chunk'){
   if(!empty($state['ready']))throw new RuntimeException('Video zaten tamamlandı.');
   $expected=filter_var($_GET['offset']??null,FILTER_VALIDATE_INT);
   $length=(int)($_SERVER['CONTENT_LENGTH']??0);
   if($expected===false || $expected!==$offset || $length<1 || $length>1048576 || $offset+$length>$size)throw new RuntimeException('Video parçası geçersiz veya sırası yanlış.');
   $in=fopen('php://input','rb');$out=fopen($part,'ab');
   if(!$in||!$out)throw new RuntimeException('Disk yazma hatası.');
   $written=stream_copy_to_stream($in,$out,1048576+1);fclose($in);fflush($out);fclose($out);
   if($written!==$length)throw new RuntimeException('Video parçası eksik aktarıldı.');
   body44_json(200,['received'=>$offset+$written]);
  }
  if($op==='finish'){
   if($offset!==$size)throw new RuntimeException('Video tamamlanmadı.');
   // Reject invalid video before marking it ready.
   body44_validate_file($part,(string)$state['kind']);
   $state['ready']=true;
   ftruncate($fp,0);rewind($fp);fwrite($fp,json_encode($state));fflush($fp);
   body44_json(200,['id'=>$id,'ready'=>true]);
  }
  throw new RuntimeException('Bilinmeyen işlem.');
 }finally{flock($fp,LOCK_UN);fclose($fp);}
}catch(Throwable $e){body44_json(400,['error'=>$e->getMessage()]);}
