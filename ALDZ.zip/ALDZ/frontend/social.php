<?php
declare(strict_types=1);
require_once __DIR__.'/../private/social_helpers.php';
require_once __DIR__.'/../private/listing_reputation.php';
require_once __DIR__.'/../private/follow_visibility.php';
require_once __DIR__.'/../private/social_media_v24.php';
$me=body_require_login();
$mid=(int)$me['id'];
$db=body_db();
$view=(string)($_GET['view']??'feed');
if(!in_array($view,['feed','media','profile','settings','roommate','stories'],true))$view='feed';
$uid=$view==='profile'?(int)($_GET['user']??$mid):$mid;
if($uid<=0)$uid=$mid;
$mine=$uid===$mid;
$csrf=body_csrf();
$bodyCities=require __DIR__.'/../private/body_cities.php';
$cityCurrent='';$citySecondary='';
try{$cp=$db->prepare('SELECT city,preferences FROM profiles WHERE user_id=?');$cp->execute([$mid]);$cr=$cp->fetch();if($cr){$cityCurrent=(string)$cr['city'];$cPrefs=json_decode((string)($cr['preferences']??''),true);$citySecondary=(string)($cPrefs['discovery_city2']??'');}}catch(Throwable $e){error_log('ALDZ city settings: '.$e->getMessage());}

$flash=$_SESSION['social_flash']??null;
unset($_SESSION['social_flash']);
$owner=null;$posts=[];$stories=[];$requests=[];$blocked=[];$followers=0;$following=0;
$follow='';$allowed=false;$followList=[];$iBlocked=false;$theyBlocked=false;
$canSeeFollowList=true;
$profileReputation=['count'=>0,'average'=>0,'badge'=>''];$profileReviews=[];
$viewerPrefs=['account_private'=>0,'language_code'=>'tr','appearance'=>'social'];
$prefs=$viewerPrefs;
$loadError='';
try {
  $q=$db->prepare('SELECT u.id,u.name,u.username,p.bio,p.avatar_path,p.cover_path FROM users u LEFT JOIN profiles p ON p.user_id=u.id WHERE u.id=? AND u.status=\'active\'');
  $q->execute([$uid]);$owner=$q->fetch();
  if(!$owner){
    http_response_code(404);exit('Bu profil bulunamadı veya görüntülenmesine izin verilmiyor. <a href="index.php">Ana Sayfa</a>');
  }
  $viewerPrefs=social_prefs($mid);
  $prefs=$mine?$viewerPrefs:social_prefs($uid);
  $canSeeFollowList=body_can_see_follow_list($db,$uid,$mid);
  $allowed=body38_can_view_content($uid,$mid);
  if(!$mine){
    $blockState=$db->prepare('SELECT blocker_id FROM user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?)');
    $blockState->execute([$mid,$uid,$uid,$mid]);
    foreach($blockState->fetchAll(PDO::FETCH_COLUMN) as $blocker){if((int)$blocker===$mid)$iBlocked=true;else $theyBlocked=true;}
  }

  if($view==='profile'){try{$profileReputation=body_reputation($db,$uid);$rq=$db->prepare('SELECT r.rating,r.body,r.created_at,u.username FROM body_listing_reviews r JOIN users u ON u.id=r.reviewer_id WHERE r.reviewed_user_id=? AND u.status=\'active\' ORDER BY r.created_at DESC LIMIT 5');$rq->execute([$uid]);$profileReviews=$rq->fetchAll();}catch(Throwable $e){error_log('ALDZ reputation profile: '.$e->getMessage());}
    $q=$db->prepare('SELECT COUNT(*) FROM social_follows WHERE following_id=? AND status=\'accepted\'');
    $q->execute([$uid]);$followers=(int)$q->fetchColumn();
    $q=$db->prepare('SELECT COUNT(*) FROM social_follows WHERE follower_id=? AND status=\'accepted\'');
    $q->execute([$uid]);$following=(int)$q->fetchColumn();
    if(!$mine){
      $q=$db->prepare('SELECT status FROM social_follows WHERE follower_id=? AND following_id=?');
      $q->execute([$mid,$uid]);$follow=(string)($q->fetchColumn()?:'');
    }
  }
  if($mine&&$view==='settings'){
    $q=$db->prepare("SELECT f.follower_id,u.name FROM social_follows f JOIN users u ON u.id=f.follower_id WHERE f.following_id=? AND f.status='pending' ORDER BY f.created_at DESC");
    $q->execute([$mid]);$requests=$q->fetchAll();
    $q=$db->prepare('SELECT u.id,u.name FROM user_blocks b JOIN users u ON u.id=b.blocked_id WHERE b.blocker_id=?');
    $q->execute([$mid]);$blocked=$q->fetchAll();
  }
  if($allowed && in_array($view,['feed','media','profile','stories'],true)){
    if($view!=='stories'){
      // Filter who can view a post BEFORE LIMIT. In older versions, 48 private posts could crowd out all public posts for a new account.
      $q=$db->prepare("SELECT sp.*,u.name,u.username,
        (SELECT COUNT(*) FROM social_post_likes l WHERE l.post_id=sp.id) likes,
        (SELECT COUNT(*) FROM social_post_comments c WHERE c.post_id=sp.id) comments,
        (SELECT COUNT(*) FROM social_post_likes l WHERE l.post_id=sp.id AND l.user_id=?) liked
        FROM social_posts sp
        JOIN users u ON u.id=sp.user_id AND u.status='active'
        LEFT JOIN social_preferences pref ON pref.user_id=u.id
        WHERE (?=0 OR sp.user_id=?)
          AND (sp.user_id=? OR (
            NOT EXISTS (SELECT 1 FROM user_blocks bl
              WHERE (bl.blocker_id=u.id AND bl.blocked_id=?)
                 OR (bl.blocker_id=? AND bl.blocked_id=u.id))
            AND (COALESCE(pref.account_private,0)=0 OR EXISTS
              (SELECT 1 FROM social_follows f WHERE f.follower_id=?
                 AND f.following_id=u.id AND f.status='accepted'))
          ))
        ORDER BY sp.created_at DESC LIMIT 96");
      $q->execute([$mid,$view==='profile'?1:0,$uid,$mid,$mid,$mid,$mid]);
      // Defense in depth: keep the application's existing visibility check.
      $posts=array_values(array_filter($q->fetchAll(),static fn($p)=>body38_can_view_content((int)$p['user_id'],$mid)));
      if($view==='feed'||$view==='media'){usort($posts,static fn($a,$b)=>((int)$b['likes']*5+(int)$b['comments']*2+max(0,14-(time()-strtotime($b['created_at']))/86400)) <=> ((int)$a['likes']*5+(int)$a['comments']*2+max(0,14-(time()-strtotime($a['created_at']))/86400)));}
    }
    if($view!=='profile'||($_GET['section']??'posts')==='stories'){
      $q=$db->prepare('SELECT s.*,u.name FROM social_stories s JOIN users u ON u.id=s.user_id WHERE s.expires_at>NOW() ORDER BY s.created_at DESC LIMIT 60');
      $q->execute();$stories=array_values(array_filter($q->fetchAll(),static fn($s)=>body38_can_view_content((int)$s['user_id'],$mid)));
    }
  }
} catch (Throwable $e) {
  error_log('ALDZ social.php '.$view.' error: '.$e->getMessage());
  $loadError='Bu bölümün verileri yüklenemedi. Veritabanı şemasını ve WAMP bağlantısını kontrol edin. KURULUM_V8.txt dosyasındaki adımları uygulayın.';
  $owner=$owner?:['id'=>$mid,'name'=>$me['name'],'username'=>$me['username'],'bio'=>'','avatar_path'=>null,'cover_path'=>null];
  $allowed=false;
}
$lang=(string)$viewerPrefs['language_code'];
$labels=[
 'tr'=>['save'=>'Kaydet','feed'=>'Keşfet','media'=>'ALDZ Akış','profile'=>'Profil','settings'=>'Ayarlar','stories'=>'Hikâyeler','post'=>'Fotoğraf Paylaş','follow'=>'Takip Et','save'=>'Kaydet','privacy'=>'Gizli Hesap','appearance'=>'Görünüm','language'=>'Dil','roommate'=>'Ev Arkadaşı','comment'=>'Yorum Yap','share'=>'Paylaş'],
 'en'=>['save'=>'Save','feed'=>'Explore','profile'=>'Profile','settings'=>'Settings','stories'=>'Stories','post'=>'Share Photo','follow'=>'Follow','save'=>'Save','privacy'=>'Private Account','appearance'=>'Appearance','language'=>'Language','roommate'=>'Roommate','comment'=>'Comment','share'=>'Share'],
 'es'=>['save'=>'Guardar','feed'=>'Explorar','profile'=>'Perfil','settings'=>'Configuración','stories'=>'Historias','post'=>'Publicar Foto','follow'=>'Seguir','save'=>'Guardar','privacy'=>'Cuenta privada','appearance'=>'Apariencia','language'=>'Idioma','roommate'=>'Compañero de piso','comment'=>'Comentar','share'=>'Compartir'],
 'ar'=>['save'=>'حفظ','feed'=>'استكشاف','profile'=>'الملف الشخصي','settings'=>'الإعدادات','stories'=>'القصص','post'=>'نشر صورة','follow'=>'متابعة','save'=>'حفظ','privacy'=>'حساب خاص','appearance'=>'المظهر','language'=>'اللغة','roommate'=>'زميل السكن','comment'=>'تعليق','share'=>'مشاركة'],
 'it'=>['save'=>'Salva','feed'=>'Esplora','profile'=>'Profilo','settings'=>'Impostazioni','stories'=>'Storie','post'=>'Pubblica Foto','follow'=>'Segui','save'=>'Salva','privacy'=>'Account privato','appearance'=>'Aspetto','language'=>'Lingua','roommate'=>'Coinquilino','comment'=>'Commenta','share'=>'Condividi'],
];$t=$labels[$lang]??$labels['tr'];
function body36_matches_filter(PDO $db,int $postId,string $filter):bool {
 if($filter==='mixed')return true;
 $q=$db->prepare('SELECT m.media_kind,o.video_length,o.post_category FROM body_post_media m LEFT JOIN body_post_options o ON o.post_id=m.post_id WHERE m.post_id=? ORDER BY m.position,m.id LIMIT 1');$q->execute([$postId]);$r=$q->fetch(PDO::FETCH_ASSOC);
 if(!$r)return false;
 $kind=(string)$r['media_kind'];$category=(string)($r['post_category']??'standard');
 if($filter==='outfits')return $category==='outfit';
 if($filter==='photos')return $kind==='photo' && $category!=='outfit';
 if($filter==='videos')return $kind==='video';
 if($filter==='short'||$filter==='long')return $kind==='video'&&($r['video_length']??'short')===$filter;
 return false;
}
function tx($value): string{return body_e((string)$value);}function social_post_action(string $action,int $id,string $back,string $csrf,string $text): string {return '<form method="post" action="social_action.php"><input type="hidden" name="csrf" value="'.tx($csrf).'"><input type="hidden" name="action" value="'.tx($action).'"><input type="hidden" name="target" value="'.$id.'"><input type="hidden" name="back" value="'.tx($back).'"><button type="submit">'.tx($text).'</button></form>';}
$back='social.php?view='.rawurlencode($view).'&user='.$uid;
$profileSection=(string)($_GET['section']??'posts');
if(!in_array($profileSection,['posts','reposts','stories','edit','about','followers','following','listings'],true))$profileSection='posts';
if($view==='profile' && in_array($profileSection,['followers','following'],true) && $canSeeFollowList){
 try{
  $sql=$profileSection==='followers' ? "SELECT u.id,u.name,u.username FROM social_follows f JOIN users u ON u.id=f.follower_id WHERE f.following_id=? AND f.status='accepted' AND u.status='active' ORDER BY f.created_at DESC LIMIT 120" : "SELECT u.id,u.name,u.username FROM social_follows f JOIN users u ON u.id=f.following_id WHERE f.follower_id=? AND f.status='accepted' AND u.status='active' ORDER BY f.created_at DESC LIMIT 120";
  $q=$db->prepare($sql);$q->execute([$uid]);$followList=array_values(array_filter($q->fetchAll(),static fn($u)=>body38_can_view_content((int)$u['id'],$mid)));
 }catch(Throwable $e){error_log('ALDZ followers: '.$e->getMessage());$loadError='Takip listesi yüklenemedi.';}
}

?>
<!doctype html><html lang="<?= tx($lang) ?>" dir="<?= $lang==='ar'?'rtl':'ltr' ?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#25133e"><link rel="manifest" href="manifest.json"><link rel="icon" href="icons/aldz-192.png"><title>ALDZ · <?= tx($t[$view]??'ALDZ') ?></title><link rel="stylesheet" href="css/social-v2.css"><link rel="stylesheet" href="css/aldz-v7.css"><link rel="stylesheet" href="css/shell-v13.css?v=23"><link rel="stylesheet" href="css/listings-v14.css?v=14"><link rel="stylesheet" href="css/aldz-v23.css?v=23"><link rel="stylesheet" href="css/aldz-v24.css?v=41"><link rel="stylesheet" href="css/aldz-v27.css?v=27"><link rel="stylesheet" href="css/aldz-v28.css?v=28"><link rel="stylesheet" href="css/aldz-v36.css?v=36"><link rel="stylesheet" href="css/aldz-v37.css?v=37"><link rel="stylesheet" href="css/aldz-v38.css?v=38"><link rel="stylesheet" href="css/aldz-i18n-v39.css?v=39"></head><body class="social-page aldz-app<?= $view==='media'?' body36-media-page':'' ?>">
<?php require __DIR__.'/shell.php'; ?>
<main class="container<?= $view==='media'?' body36-media-main':'' ?>">
<?php if($flash): ?><p class="flash" role="status"><?= tx($flash) ?></p><?php endif; ?><?php if($loadError): ?><section class="panel" role="alert"><h2>Bölüm yüklenemedi</h2><p><?= tx($loadError) ?></p><a class="button" href="index.php">Ana Sayfaya Dön</a></section><?php endif; ?>
<?php if(!$loadError&&$view==='profile'): ?>
<section class="profile-header panel"><div class="cover"<?= !empty($owner['cover_path']) ? ' style="background-image:url('.tx($owner['cover_path']).')"' : '' ?>></div><div class="profile-info"><div class="avatar-large"><?php if(!empty($owner['avatar_path'])): ?><img src="<?= tx($owner['avatar_path']) ?>" alt="Profil fotoğrafı"><?php else: ?><?= tx(mb_substr($owner['name'],0,1)) ?><?php endif; ?></div><div class="identity"><h1><?= tx($owner['name']) ?></h1><small>@<?= tx($owner['username']) ?> <?= $prefs['account_private']?'🔒':'' ?></small><p><?= tx($owner['bio']??'ALDZ’de birlikte daha güzel.') ?></p><div class="stats"><b><?= count($posts) ?></b> gönderi · <?php if($canSeeFollowList): ?><a href="social.php?view=profile&user=<?= $uid ?>&section=followers"><b><?= $followers ?></b> takipçi</a> · <a href="social.php?view=profile&user=<?= $uid ?>&section=following"><b><?= $following ?></b> takip edilen</a><?php else: ?><span>Takip listeleri gizli</span><?php endif; ?></div></div><div class="profile-controls"><?php if($mine): ?><a class="button" href="social.php?view=profile&section=edit">Profili Düzenle</a><a class="button alt" href="social.php?view=settings">Ayarlar</a><a class="button alt" href="listings.php?mine=1">İlanlarım</a><a class="button alt" href="social.php?view=profile&section=reposts">Repostlarım</a><?php else: ?><?php if($iBlocked): ?><?= social_post_action('unblock',$uid,$back,$csrf,'Engeli Kaldır') ?><?php elseif($theyBlocked): ?><span class="aldz-blocked-note">Bu hesapla etkileşim kurulamıyor.</span><?php else: ?><?= social_post_action('follow',$uid,$back,$csrf,$follow=== 'accepted'?'Takibi Bırak':($follow==='pending'?'İsteği Geri Çek':$t['follow'])) ?><?= social_post_action('block',$uid,$back,$csrf,'Engelle') ?><?php if($follow==='accepted'): ?><a class="button" href="messages.php?with=<?= $uid ?>">Mesaj Gönder</a><?php endif; ?><?php endif; ?><?php endif; ?></div></div></section>
<?php if(!$allowed): ?><div class="panel private-note">🔒 Bu hesaba erişim kapalı olabilir. Gizli hesapların gönderilerini görmek için onaylı takip gerekir; engellenen hesaplarla etkileşim kurulamaz.</div><?php endif; ?>
<nav class="profile-local-tabs panel"><a class="<?= $profileSection==='posts'?'active':'' ?>" href="social.php?view=profile&user=<?= $uid ?>&section=posts">Paylaşımlar</a><a class="<?= $profileSection==='reposts'?'active':'' ?>" href="social.php?view=profile&user=<?= $uid ?>&section=reposts">↻ Repostlar</a><?php if($mine): ?><a class="<?= $profileSection==='stories'?'active':'' ?>" href="social.php?view=profile&section=stories">Hikâyeler</a><a class="<?= $profileSection==='edit'?'active':'' ?>" href="social.php?view=profile&section=edit">Profili Düzenle</a><a class="<?= $profileSection==='about'?'active':'' ?>" href="social.php?view=profile&section=about">Hakkında</a><a class="<?= $profileSection==='listings'?'active':'' ?>" href="listings.php?mine=1">İlanlarım</a><?php endif; ?><?php if($canSeeFollowList): ?><a class="<?= $profileSection==='followers'?'active':'' ?>" href="social.php?view=profile&user=<?= $uid ?>&section=followers">Takipçiler</a><a class="<?= $profileSection==='following'?'active':'' ?>" href="social.php?view=profile&user=<?= $uid ?>&section=following">Takip Edilenler</a><?php endif; ?></nav>
<?php if(!$canSeeFollowList && in_array($profileSection,['followers','following'],true)): ?><section class="panel"><h2>Takip listesi gizli</h2><p>Bu kullanıcı takip listesini görüntülemeni sınırlandırmış.</p></section><?php endif; ?>
<?php if($allowed && ($canSeeFollowList || !in_array($profileSection,['followers','following'],true))): ?>
<?php if(in_array($profileSection,['followers','following'],true)): ?>
<section class="panel"><h2><?= $profileSection==='followers'?'Takipçiler':'Takip Edilenler' ?></h2><div class="profile-follow-list"><?php if(!$followList):?><p>Gösterilebilecek kullanıcı bulunamadı.</p><?php endif;?><?php foreach($followList as $f):?><a class="profile-follow-person" href="social.php?view=profile&user=<?=(int)$f['id']?>"><span class="round"><?=tx(mb_substr($f['name'],0,1))?></span><span><strong><?=tx($f['name'])?></strong><small style="display:block">@<?=tx($f['username'])?></small></span></a><?php endforeach;?></div></section>
<?php elseif(!$mine || $profileSection==='posts'): ?>
<?php if($mine)body24_compose($csrf,$back); ?>
<div class="feed-grid"><div class="posts"><?php if(!$posts): ?><div class="panel empty">Henüz fotoğraf paylaşımı yok.</div><?php endif; ?><?php foreach($posts as $p): ?><?php if($view==='media' && !body36_matches_filter($db,(int)$p['id'],(string)($_GET['filter']??'mixed')))continue; ?><?php body24_post($db,$p,$mid,$back,$csrf); ?><?php endforeach; ?></div><aside class="suggestions panel"><h2>ALDZ’de İnsanlar</h2><?php $uq=$db->prepare("SELECT id,name,username FROM users WHERE id<>? AND status='active' ORDER BY id DESC LIMIT 15");$uq->execute([$mid]);foreach($uq->fetchAll() as $u): if(!body38_can_view_content((int)$u['id'],$mid))continue; ?><div class="person"><a href="social.php?view=profile&user=<?= (int)$u['id'] ?>"><span class="round"><?= tx(mb_substr($u['name'],0,1)) ?></span> <?= tx($u['name']) ?></a></div><?php endforeach; ?></aside></div>
<?php elseif($profileSection==='reposts'): ?>
<section class="panel"><h2>↻ Repostlar</h2><p>Kullanıcının yeniden paylaştığı ve görüntüleme iznin olan gönderiler.</p></section>
<div class="feed-grid"><div class="posts">
<?php
$repostsQuery=$db->prepare("SELECT r.visibility, r.user_id AS reposter_id, sp.*, u.name,u.username,(SELECT COUNT(*) FROM social_post_likes l WHERE l.post_id=sp.id) likes,(SELECT COUNT(*) FROM social_post_comments c WHERE c.post_id=sp.id) comments,(SELECT COUNT(*) FROM social_post_likes l WHERE l.post_id=sp.id AND l.user_id=?) liked FROM body_post_reposts r JOIN social_posts sp ON sp.id=r.post_id JOIN users u ON u.id=sp.user_id AND u.status='active' WHERE r.user_id=? ORDER BY r.created_at DESC LIMIT 50");
$repostsQuery->execute([$mid,$uid]);$repostCount=0;
foreach($repostsQuery->fetchAll() as $rep):
 if(!body38_can_view_content((int)$rep['user_id'],$mid))continue;
 if($rep['visibility']==='followers' && !$mine){$fq=$db->prepare("SELECT 1 FROM social_follows WHERE follower_id=? AND following_id=? AND status='accepted'");$fq->execute([$mid,$uid]);if(!$fq->fetchColumn())continue;}
 $repostCount++;body24_post($db,$rep,$mid,$back,$csrf,['user_id'=>$uid,'username'=>$owner['username']]);
endforeach;
if(!$repostCount):?><p class="panel empty">Görüntülenebilecek repost bulunmuyor.</p><?php endif;?>
</div></div>
<?php elseif($profileSection==='stories'): ?>
<section class="panel"><h2><?= tx($t['stories']) ?></h2><div class="story-list large"><?php if(!$stories): ?><p>Henüz aktif hikâye yok.</p><?php endif; ?><?php foreach($stories as $s): if((int)$s['user_id']!==$uid) continue; ?><a href="social.php?view=stories&id=<?= (int)$s['id'] ?>" class="story"><img src="<?= tx($s['media_path']) ?>" alt="Hikâye"><span><?= tx($s['name']) ?></span></a><?php endforeach; ?></div><details class="compose-disclosure"><summary>＋ Hikâye Ekle <span>Formu aç</span></summary><div class="compose-contents"><form method="post" action="social_action.php" enctype="multipart/form-data" class="story-form story-inline"><input type="hidden" name="csrf" value="<?= tx($csrf) ?>"><input type="hidden" name="action" value="story"><input type="hidden" name="back" value="social.php?view=profile&section=stories"><label>📸 Yeni hikâye ekle <input type="file" name="image" accept="image/jpeg,image/png,image/webp" required></label><button type="submit">Hikâye Paylaş</button></form></div></details></section>
<?php elseif($profileSection==='edit'): ?>
<section class="panel edit-profile-panel"><h2>Profil Fotoğrafı ve Düzenleme</h2><form action="social_action.php" method="post" class="username-change"><input type="hidden" name="csrf" value="<?= tx($csrf) ?>"><input type="hidden" name="action" value="username"><input type="hidden" name="back" value="social.php?view=profile&section=edit"><label>Kullanıcı adı <input type="text" name="username" value="<?= tx($owner['username']) ?>" minlength="4" maxlength="30" pattern="[a-z][a-z0-9._]{3,29}" required autocomplete="username"></label><button type="submit">Kullanıcı Adını Kaydet</button></form><div class="edit-grid"><form action="social_action.php" method="post" enctype="multipart/form-data" class="avatar-upload"><input type="hidden" name="csrf" value="<?= tx($csrf) ?>"><input type="hidden" name="action" value="avatar"><input type="hidden" name="back" value="social.php?view=profile&section=edit"><label>Profil fotoğrafı yükle<input type="file" name="image" accept="image/jpeg,image/png,image/webp" required></label><button type="submit">Fotoğrafı Güncelle</button></form><form action="social_action.php" method="post" enctype="multipart/form-data" class="avatar-upload"><input type="hidden" name="csrf" value="<?= tx($csrf) ?>"><input type="hidden" name="action" value="cover"><input type="hidden" name="back" value="social.php?view=profile&section=edit"><label>Kapak fotoğrafı yükle<input type="file" name="image" accept="image/jpeg,image/png,image/webp" required></label><button type="submit">Kapağı Güncelle</button></form><form action="social_action.php" method="post" class="settings-form compact"><input type="hidden" name="csrf" value="<?= tx($csrf) ?>"><input type="hidden" name="action" value="settings"><input type="hidden" name="back" value="social.php?view=profile&section=edit"><label>Biyografi<textarea name="bio" maxlength="500" rows="4"><?= tx($owner['bio']??'') ?></textarea></label><label class="check"><input type="checkbox" name="private" value="1" <?= $viewerPrefs['account_private']?'checked':'' ?>> <?= tx($t['privacy']) ?></label><label>Takipçilerimi ve takip ettiklerimi kimler görebilir?<select name="follow_visibility">
<?php foreach(['everyone'=>'Herkes','following'=>'Yalnızca takip ettiklerim','mutual'=>'Karşılıklı takip ettiklerim','only_me'=>'Yalnızca ben'] as $policy=>$caption): ?><option value="<?=tx($policy)?>" <?=($viewerPrefs['follow_visibility']??'everyone')===$policy?'selected':''?>><?=tx($caption)?></option><?php endforeach; ?>
</select></label><label><?= tx($t['language']) ?><select name="language"><option value="tr" <?= $lang==='tr'?'selected':'' ?>>Türkçe</option><option value="en" <?= $lang==='en'?'selected':'' ?>>English</option><option value="es" <?= $lang==='es'?'selected':'' ?>>Español</option><option value="ar" <?= $lang==='ar'?'selected':'' ?>>العربية</option><option value="it" <?= $lang==='it'?'selected':'' ?>>Italiano</option></select></label><label><?= tx($t['appearance']) ?><select disabled><option>Modern Social (Tek seçenek)</option></select></label><button class="button" type="submit">Profili Kaydet</button></form></div></section>
<?php else: ?>
<section class="panel about-panel"><h2>Hakkında</h2><p><?= tx($owner['bio']??'ALDZ’de birlikte daha güzel.') ?></p><p><strong>Topluluk değerlendirmeleri:</strong> <?= (int)$profileReputation['count'] ?> değerlendirme<?= $profileReputation['count'] ? ' · '.tx((string)$profileReputation['average']).'/5' : '' ?><?php if($profileReputation['badge']):?> · ★ <?=tx($profileReputation['badge'])?><?php endif;?></p><small>Topluluk değerlendirmesi kimlik veya güvenlik doğrulaması değildir.</small><?php foreach($profileReviews as $pr):?><div class="listing-review-profile"><b>★ <?= (int)$pr['rating'] ?>/5 · @<?=tx($pr['username'])?></b><p><?=nl2br(tx($pr['body']))?></p></div><?php endforeach;?><div class="stats-cards"><div><strong><?= $followers ?></strong><span>Takipçi</span></div><div><strong><?= $following ?></strong><span>Takip</span></div><div><strong><?= count($posts) ?></strong><span>Gönderi</span></div></div></section>
<?php endif; ?>
<?php endif; ?>
<?php endif; ?>
<?php if(!$loadError&&$view==='settings'): ?>
<h1><?= tx($t['settings']) ?></h1><section class="panel" style="margin-bottom:18px"><h2>Şehir ve İlan Keşfi</h2><p>Seçtiğin iki şehre yakın ilanları önce görürsün. Kesin konumun paylaşılmaz.</p><form method="post" action="social_action.php" class="settings-form"><input type="hidden" name="csrf" value="<?=tx($csrf)?>"><input type="hidden" name="action" value="cities"><input type="hidden" name="back" value="social.php?view=settings"><label>Yaşadığım şehir<select name="city_primary" required><option value="">Seç</option><?php foreach($bodyCities as $ct):?><option value="<?=tx($ct)?>" <?=$cityCurrent===$ct?'selected':''?>><?=tx($ct)?></option><?php endforeach;?></select></label><label>İkinci şehir (isteğe bağlı)<select name="city_secondary"><option value="">Yalnızca bir şehir</option><?php foreach($bodyCities as $ct):?><option value="<?=tx($ct)?>" <?=$citySecondary===$ct?'selected':''?>><?=tx($ct)?></option><?php endforeach;?></select></label><button class="button" type="submit">Şehir Tercihlerini Kaydet</button></form></section><div class="settings-layout"><section class="panel"><h2>Profil Fotoğrafı</h2><form action="social_action.php" method="post" enctype="multipart/form-data" class="avatar-upload"><input type="hidden" name="csrf" value="<?= tx($csrf) ?>"><input type="hidden" name="action" value="avatar"><input type="hidden" name="back" value="social.php?view=settings"><input type="file" name="image" accept="image/jpeg,image/png,image/webp" required><button type="submit">Fotoğrafı Güncelle</button></form><hr><h2 id="privacy">Hesap ve Gizlilik</h2><form action="social_action.php" method="post" class="settings-form"><input type="hidden" name="csrf" value="<?= tx($csrf) ?>"><input type="hidden" name="action" value="settings"><input type="hidden" name="back" value="social.php?view=settings"><label>Biyografi<textarea name="bio" maxlength="500" rows="4"><?= tx($owner['bio']??'') ?></textarea></label><label class="check"><input type="checkbox" name="private" value="1" <?= $viewerPrefs['account_private']?'checked':'' ?>> <?= tx($t['privacy']) ?> (Takip isteklerini onayla)</label><label>Takipçilerimi ve takip ettiklerimi kimler görebilir?<select name="follow_visibility">
<?php foreach(['everyone'=>'Herkes','following'=>'Yalnızca takip ettiklerim','mutual'=>'Karşılıklı takip ettiklerim','only_me'=>'Yalnızca ben'] as $policy=>$caption): ?><option value="<?=tx($policy)?>" <?=($viewerPrefs['follow_visibility']??'everyone')===$policy?'selected':''?>><?=tx($caption)?></option><?php endforeach; ?>
</select></label><label><?= tx($t['language']) ?><select name="language"><option value="tr" <?= $lang==='tr'?'selected':'' ?>>Türkçe</option><option value="en" <?= $lang==='en'?'selected':'' ?>>English</option><option value="es" <?= $lang==='es'?'selected':'' ?>>Español</option><option value="ar" <?= $lang==='ar'?'selected':'' ?>>العربية</option><option value="it" <?= $lang==='it'?'selected':'' ?>>Italiano</option></select></label><label><?= tx($t['appearance']) ?><select disabled><option>Modern Social (Tek seçenek)</option></select></label><button class="button" type="submit"><?= tx($t['save']) ?></button></form><p class="hint">Dil tercihi sosyal sayfaların ve ortak menünün desteklenen metinlerinde kullanılır. Bazı eski modül metinleri henüz çevrilmemiştir.</p></section><section class="panel"><h2>Takip İstekleri</h2><?php if(!$requests): ?><p>Bekleyen istek yok.</p><?php endif; ?><?php foreach($requests as $r): ?><div class="person"><span><?= tx($r['name']) ?></span><?= social_post_action('approve',(int)$r['follower_id'],'social.php?view=settings',$csrf,'Onayla') ?><?= social_post_action('reject',(int)$r['follower_id'],'social.php?view=settings',$csrf,'Reddet') ?></div><?php endforeach; ?><h2>Engellenen Hesaplar</h2><?php if(!$blocked): ?><p>Engellenen hesap yok.</p><?php endif; ?><?php foreach($blocked as $b): ?><div class="person"><span><?= tx($b['name']) ?></span><?= social_post_action('unblock',(int)$b['id'],'social.php?view=settings',$csrf,'Engeli Kaldır') ?></div><?php endforeach; ?></section></div>
<?php elseif(!$loadError&&$view==='roommate'): ?><section class="panel"><h1>Ev Arkadaşı</h1><p>Ev arkadaşı ilanları, sosyal fotoğraf ve etkinlik gönderilerinden tamamen ayrı bir bölümde yer alacak.</p><p>Uyum, konum, bütçe, yaşam alışkanlıkları ve başvuru yönetimi bu bölümde geliştirilecek.</p><div class="private-note">Bu sürümde ev arkadaşı ilanı oluşturma henüz aktif değil.</div></section>
<?php elseif(!$loadError&&in_array($view,['feed','media','stories'],true)): ?>
<?php if($view==='media'): ?>
<div class="body37-media-toolbar"><div class="body37-media-label"><h1>ALDZ Akış</h1><span>Keşfet, izle, ilham al.</span></div><a class="body37-people-link" href="find.php" aria-label="Arkadaş bul">⌕ <span>Arkadaş bul</span></a><?php body24_compose($csrf,$back); ?></div>
<?php elseif($view==='feed'): ?><h1>ALDZ · <?= tx($t['feed']) ?></h1><p><a class="button" href="find.php">🔎 Kullanıcı Adıyla Arkadaş Bul</a></p><p class="subhead">Fotoğraf, kısa ve uzun video, kombin, yorum ve arkadaşlarınla paylaşımlar.</p><?php body24_compose($csrf,$back); ?><?php endif; ?>
<?php if($view!=='media'): ?><div class="panel story-panel"><h2><?= tx($t['stories']) ?></h2><div class="story-list"><?php if(!$stories): ?><p>Henüz aktif hikâye yok.</p><?php endif; ?><?php foreach($stories as $s): ?><a href="social.php?view=stories&id=<?= (int)$s['id'] ?>" class="story"><img src="<?= tx($s['media_path']) ?>" alt="Hikâye"><span><?= tx($s['name']) ?></span></a><?php endforeach; ?></div></div><?php endif; ?>
<?php if($view==='stories'): $storyId=(int)($_GET['id']??0);$matched=null;foreach($stories as $s){if((int)$s['id']===$storyId)$matched=$s;} ?><section class="panel viewer"><?php if($matched): ?><h2><?= tx($matched['name']) ?> · Hikâye</h2><img src="<?= tx($matched['media_path']) ?>" alt="Hikâye görseli"><p>Bu hikâye 24 saat sonra otomatik görünmez olur.</p><?php else: ?><p>Bu hikâyenin süresi dolmuş veya erişim iznin yok.</p><?php endif; ?></section><?php endif; ?>
<?php if($view==='media'): ?><nav class="body24-filters" aria-label="Medya türü"><a href="social.php?view=media&filter=mixed" class="<?=($_GET['filter']??'mixed')==='mixed'?'active':''?>">Karışık</a><a href="social.php?view=media&filter=photos" class="<?=($_GET['filter']??'mixed')==='photos'?'active':''?>">Fotoğraflar</a><a href="social.php?view=media&filter=videos" class="<?=($_GET['filter']??'mixed')==='videos'?'active':''?>">Tüm Videolar</a><a href="social.php?view=media&filter=short" class="<?=($_GET['filter']??'mixed')==='short'?'active':''?>">ALDZ Kısa</a><a href="social.php?view=media&filter=long" class="<?=($_GET['filter']??'mixed')==='long'?'active':''?>">ALDZ Uzun</a><a href="social.php?view=media&filter=outfits" class="<?=($_GET['filter']??'mixed')==='outfits'?'active':''?>">Kombinler</a></nav><?php endif; ?>
<?php if($view==='media'): ?><div class="body36-feed-scroll" id="body36-feed-scroll" tabindex="0" aria-label="ALDZ Akış gönderileri · kendi içinde kaydır"><?php endif; ?>
<div class="feed-grid"><div class="posts"><?php if(!$posts&&$allowed): ?><div class="panel empty body37-feed-empty"><h2>Henüz görüntüleyebileceğin paylaşım yok</h2><p>Herkese açık gönderiler burada görünür. Gizli hesapların içerikleri için onaylı takip gerekir.</p><a class="button" href="find.php">Kişileri keşfet</a></div><?php endif; ?><?php foreach($posts as $p): ?><?php if($view==='media' && !body36_matches_filter($db,(int)$p['id'],(string)($_GET['filter']??'mixed')))continue; ?><?php body24_post($db,$p,$mid,$back,$csrf); ?><?php endforeach; ?><?php if(in_array($view,['feed','media'],true)):
 $rpq=$db->prepare("SELECT r.user_id AS reposter_id,r.visibility,r.created_at AS repost_at, ru.username AS reposter_username, sp.*, u.name,u.username,(SELECT COUNT(*) FROM social_post_likes l WHERE l.post_id=sp.id) likes,(SELECT COUNT(*) FROM social_post_comments c WHERE c.post_id=sp.id) comments,(SELECT COUNT(*) FROM social_post_likes l WHERE l.post_id=sp.id AND l.user_id=?) liked FROM body_post_reposts r JOIN social_posts sp ON sp.id=r.post_id JOIN users ru ON ru.id=r.user_id AND ru.status='active' JOIN users u ON u.id=sp.user_id AND u.status='active' WHERE r.user_id<>? ORDER BY r.created_at DESC LIMIT 30");
 $rpq->execute([$mid,$mid]);foreach($rpq->fetchAll() as $rp):
 $reposter=(int)$rp['reposter_id'];
 // Author comes from social_posts, repost creator is kept separately in a SQL alias below.
 if(!body38_can_view_content($reposter,$mid)||!body38_can_view_content((int)$rp['user_id'],$mid))continue;
 if($view==='media' && !body36_matches_filter($db,(int)$rp['id'],(string)($_GET['filter']??'mixed')))continue;
 if($rp['visibility']==='followers'){$f=$db->prepare("SELECT 1 FROM social_follows WHERE follower_id=? AND following_id=? AND status='accepted'");$f->execute([$mid,$reposter]);if(!$f->fetchColumn())continue;}
 $rp['name']=$rp['name'];body24_post($db,$rp,$mid,$back,$csrf,['user_id'=>$reposter,'username'=>$rp['reposter_username']]);
 endforeach;endif;?></div><aside class="suggestions panel"><h2>ALDZ’de İnsanlar</h2><?php $uq=$db->prepare("SELECT id,name,username FROM users WHERE id<>? AND status='active' ORDER BY id DESC LIMIT 15");$uq->execute([$mid]);foreach($uq->fetchAll() as $u): if(!body38_can_view_content((int)$u['id'],$mid))continue; ?><div class="person"><a href="social.php?view=profile&user=<?= (int)$u['id'] ?>"><span class="round"><?= tx(mb_substr($u['name'],0,1)) ?></span> <?= tx($u['name']) ?></a></div><?php endforeach; ?></aside></div><?php if($view==='media'): ?></div><?php endif; ?>
<?php endif; ?>
</main><script src="js/social-v2.js" defer></script><script src="js/aldz-v24.js?v=46" defer></script><script src="js/shared-nav.js?v=16" defer></script><script src="js/shell-v10.js?v=13" defer></script><script>if('serviceWorker' in navigator){navigator.serviceWorker.register('sw.js').catch(()=>{});}</script><script src="js/aldz-v38.js?v=38" defer></script><script src="js/aldz-i18n-v39.js?v=39" defer></script></body></html>
