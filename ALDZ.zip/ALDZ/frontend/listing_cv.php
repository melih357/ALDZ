<?php
/** CV data is stored in MySQL, never in public uploads. */
declare(strict_types=1);
require_once __DIR__.'/../private/social_helpers.php';
require_once __DIR__.'/../private/listing_rules.php';
$me=body_require_login();$mid=(int)$me['id'];$db=body_db();
$id=(int)($_GET['id']??0);$candidate=(int)($_GET['user']??0);
$q=$db->prepare('SELECT l.user_id,l.type,l.age_band,l.category_details FROM body_listings l WHERE l.id=?');$q->execute([$id]);$l=$q->fetch();
if(!$l||$l['type']!=='jobs'||$me['age_band']!=='adult') {http_response_code(404);exit('CV bulunamadı.');}
$owner=(int)$l['user_id'];$details=json_decode((string)$l['category_details'],true)?:[];
$seek=($details['job_mode']??'')==='İş arıyorum';
if($seek){
 if($candidate!==$owner){http_response_code(403);exit('Yetki yok.');}
 $permitted=$mid===$owner;
 if(!$permitted){$q=$db->prepare("SELECT 1 FROM body_listing_members WHERE listing_id=? AND user_id=? AND status='accepted'");$q->execute([$id,$mid]);$permitted=(bool)$q->fetchColumn();}
}else{
 $permitted=$mid===$owner||$mid===$candidate;
 if($permitted && $mid!==$candidate){$q=$db->prepare("SELECT 1 FROM body_listing_members WHERE listing_id=? AND user_id=? AND status IN ('pending','accepted')");$q->execute([$id,$candidate]);$permitted=(bool)$q->fetchColumn();}
}
if(!$permitted||!social_can_view($candidate,$mid)){http_response_code(403);exit('Bu CV için erişim yetkin yok.');}
$q=$db->prepare('SELECT cv_text,cv_pdf,cv_filename FROM body_listing_cvs WHERE listing_id=? AND user_id=?');$q->execute([$id,$candidate]);$cv=$q->fetch();if(!$cv){http_response_code(404);exit('CV bulunamadı.');}
header('Cache-Control: no-store, private');header('X-Content-Type-Options: nosniff');header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'");
if(($_GET['download']??'')==='1'&&!empty($cv['cv_pdf'])){
 header('Content-Type: application/pdf');header('Content-Disposition: attachment; filename="ALDZ-CV.pdf"');header('Content-Length: '.strlen($cv['cv_pdf']));echo $cv['cv_pdf'];exit;
}
?><!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Özel CV · ALDZ</title><link rel="stylesheet" href="css/aldz-i18n-v39.css?v=39"><body style="font:16px system-ui;max-width:800px;margin:45px auto;padding:20px;background:#f8f5ff;color:#281943"><h1>Özel CV</h1><p>Bu sayfa CV sahibi ve yetkili ilan tarafına özeldir. CV kişisel veri içerebilir; üçüncü kişilerle izinsiz paylaşma.</p><div style="white-space:pre-wrap;padding:22px;border-radius:15px;background:white"><?=body_e((string)($cv['cv_text']?:'CV metni eklenmemiş, yalnızca PDF yüklenmiş.'))?></div><?php if(!empty($cv['cv_pdf'])):?><p><a href="?id=<?=$id?>&user=<?=$candidate?>&download=1">PDF CV dosyasını indir</a></p><?php endif;?><p><a href="listing_room.php?id=<?=$id?>">İlana dön</a></p><script src="js/aldz-i18n-v39.js?v=39" defer></script></body></html>
