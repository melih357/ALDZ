<?php
declare(strict_types=1);
require_once __DIR__.'/../private/message_media_v25.php';
$me=body_require_login();$mid=(int)$me['id'];$db=body_db();
header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');header('X-Content-Type-Options: nosniff');
function call_reply(array $v,int $status=200): never {http_response_code($status);echo json_encode($v,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
$chat=(int)($_REQUEST['chat']??0);
if($chat<1||!body_chat_allowed($db,$chat,$mid))call_reply(['error'=>'Arama yetkin yok.'],403);
$peer=body_chat_peer($db,$chat,$mid);
if($_SERVER['REQUEST_METHOD']==='GET'){
 $q=$db->prepare("SELECT id,caller_id,callee_id,kind,status,created_at FROM body_direct_calls WHERE conversation_id=? AND status IN ('ringing','accepted') AND created_at>DATE_SUB(NOW(),INTERVAL 10 MINUTE) ORDER BY id DESC LIMIT 1");$q->execute([$chat]);$call=$q->fetch();
 if(!$call)call_reply(['call'=>null,'signals'=>[]]);
 $since=max(0,(int)($_GET['since']??0));
 $s=$db->prepare('SELECT id,sender_id,signal_type,payload FROM body_call_signals WHERE call_id=? AND id>? ORDER BY id LIMIT 90');$s->execute([(int)$call['id'],$since]);
 call_reply(['call'=>$call,'signals'=>$s->fetchAll(),'mine'=>$mid]);
}
if(!body_valid_csrf())call_reply(['error'=>'İstek doğrulanamadı.'],403);
$action=(string)($_POST['action']??'');
try{
 if($action==='start'){
  $kind=(string)($_POST['kind']??'audio');if(!in_array($kind,['audio','video'],true))throw new RuntimeException('Geçersiz arama türü.');
  $db->beginTransaction();
  $lock=$db->prepare('SELECT id FROM conversations WHERE id=? FOR UPDATE');$lock->execute([$chat]);
  $q=$db->prepare("SELECT id,status FROM body_direct_calls WHERE conversation_id=? AND status IN ('ringing','accepted') AND created_at>DATE_SUB(NOW(),INTERVAL 10 MINUTE) ORDER BY id DESC LIMIT 1");$q->execute([$chat]);$existing=$q->fetch();
  if($existing){$db->commit();call_reply(['error'=>'Bu konuşmada zaten bir arama var.'],409);}
  $db->prepare("INSERT INTO body_direct_calls(conversation_id,caller_id,callee_id,kind) VALUES(?,?,?,?)")->execute([$chat,$mid,$peer,$kind]);$id=(int)$db->lastInsertId();$db->commit();call_reply(['ok'=>true,'call_id'=>$id]);
 }
 $id=(int)($_POST['call_id']??0);
 $q=$db->prepare('SELECT * FROM body_direct_calls WHERE id=? AND conversation_id=?');$q->execute([$id,$chat]);$call=$q->fetch();
 if(!$call||!in_array($mid,[(int)$call['caller_id'],(int)$call['callee_id']],true))throw new RuntimeException('Arama bulunamadı.');
 if($action==='accept'){
  if($mid!==(int)$call['callee_id']||$call['status']!=='ringing')throw new RuntimeException('Arama yanıtlanamıyor.');
  $db->prepare("UPDATE body_direct_calls SET status='accepted' WHERE id=?")->execute([$id]);call_reply(['ok'=>true]);
 }
 if($action==='decline'||$action==='end'){
  $status=($action==='decline'?'declined':'ended');$db->prepare('UPDATE body_direct_calls SET status=? WHERE id=?')->execute([$status,$id]);call_reply(['ok'=>true]);
 }
 if($action==='signal'){
  if(!in_array($call['status'],['ringing','accepted'],true))throw new RuntimeException('Arama sona ermiş.');
  $type=(string)($_POST['signal_type']??'');if(!in_array($type,['offer','answer','ice'],true))throw new RuntimeException('Geçersiz sinyal.');
  $payload=(string)($_POST['payload']??'');if(strlen($payload)>16000||!is_array(json_decode($payload,true)))throw new RuntimeException('Sinyal geçersiz.');
  $db->prepare('INSERT INTO body_call_signals(call_id,sender_id,signal_type,payload) VALUES(?,?,?,?)')->execute([$id,$mid,$type,$payload]);call_reply(['ok'=>true]);
 }
 throw new RuntimeException('İşlem bulunamadı.');
}catch(Throwable $e){if($db->inTransaction())$db->rollBack();call_reply(['error'=>$e->getMessage()],400);}
