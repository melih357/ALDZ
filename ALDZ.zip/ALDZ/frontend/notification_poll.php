<?php
declare(strict_types=1);
require_once __DIR__.'/../private/auth.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: private, no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
try {
 $u=body_require_login();$db=body_db();$uid=(int)$u['id'];
 $after=max(0,(int)($_GET['after']??0));
 $q=$db->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL');$q->execute([$uid]);$unread=(int)$q->fetchColumn();
 $q=$db->prepare('SELECT COALESCE(MAX(id),0) FROM notifications WHERE user_id=?');$q->execute([$uid]);$latest=(int)$q->fetchColumn();
 $items=[];
 if($after>0 && $latest>$after){
  $q=$db->prepare('SELECT id,type,title,body,created_at FROM notifications WHERE user_id=? AND id>? ORDER BY id ASC LIMIT 10');$q->execute([$uid,$after]);$items=$q->fetchAll(PDO::FETCH_ASSOC);
 }
 echo json_encode(['ok'=>true,'unread'=>$unread,'latest'=>$latest,'items'=>$items],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
}catch(Throwable $e){error_log('ALDZ notification polling: '.$e->getMessage());http_response_code(503);echo json_encode(['ok'=>false,'error'=>'Bildirimler şu anda alınamıyor.'],JSON_UNESCAPED_UNICODE);}
