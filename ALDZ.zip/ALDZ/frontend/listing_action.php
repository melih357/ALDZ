<?php
declare(strict_types=1);
require_once __DIR__.'/../private/social_helpers.php';
require_once __DIR__.'/../private/listing_rules.php';
$me=body_require_login();$mid=(int)$me['id'];
if($_SERVER['REQUEST_METHOD']!=='POST'||!body_valid_csrf()){http_response_code(403);exit('Geçersiz işlem.');}
$action=(string)($_POST['action']??'');$id=(int)($_POST['id']??0);
$types=['activity','roommate','freeitems','creative','travel','samegender','skills','jobs','partners'];
$fieldDefinitions=require __DIR__.'/../private/listing_fields.php';
$locations=require __DIR__.'/../private/turkiye_locations.php';
$redirectOnError='listings.php?create=1#create-form';
try{
 $db=body_db();
 if($action==='save'){
  $type=(string)($_POST['type']??'');$title=trim((string)($_POST['title']??''));$description=trim((string)($_POST['description']??''));$province=trim((string)($_POST['city_province']??''));$area=trim((string)($_POST['city_area']??'İl geneli'));
  if(!in_array($province,$locations['cities'],true) || !in_array($area,$locations['areas'],true))throw new RuntimeException('Şehir ve genel bölgeyi listeden seçmelisin.');
  $city=$province.' / '.$area;$extra=trim((string)($_POST['extra_info']??''));
  if($type==='samegender' && !in_array((string)($me['gender']??''),['woman','man'],true))throw new RuntimeException('Aynı Çevreden ilanı için önce cinsiyet tercihini kaydet.');
  if($type==='jobs' && $me['age_band']!=='adult')throw new RuntimeException('İş ilanları bu sürümde yalnızca 18 yaş üzeri hesaplara açıktır.');
  if($type==='roommate' && $me['age_band']!=='adult')throw new RuntimeException('Ev arkadaşı ilanları 18 yaş ve üzeri kullanıcılar içindir.');
  if($type==='partners' && $me['age_band']!=='adult')throw new RuntimeException('Proje & İş Ortaklığı ilanları 18 yaş ve üzeri kullanıcılar içindir.');
  if(!in_array($type,$types,true)||mb_strlen($title)<4||mb_strlen($title)>140||mb_strlen($description)<10||mb_strlen($description)>4000||mb_strlen($city)<2||mb_strlen($city)>100||mb_strlen($extra)>250)throw new RuntimeException('İlan bilgilerini kontrol et. Başlık en az 4, açıklama en az 10 karakter olmalı.');
  $min=(int)($_POST['min_age']??0);$max=(int)($_POST['max_age']??0);
  $age=body_listing_age($me);
  $low=$me['age_band']==='minor'?13:18;$high=$me['age_band']==='minor'?17:110;
  if($min<$low || $max>$high || $min>$max)throw new RuntimeException('Yaş aralığı 13–17 veya 18+ güvenli yaş grubunda olmalıdır.');
  $approval=$type==='partners'?1:(int)(($_POST['approval_required']??'1')==='1');
  $chatMode=(string)($_POST['chat_mode']??'open');$writers=(string)($_POST['chat_writers']??'all');
  if(!in_array($chatMode,['open','after_ready'],true)||!in_array($writers,['all','owner'],true))throw new RuntimeException('Sohbet seçimi geçersiz.');
  $details=[];
  foreach(($fieldDefinitions[$type]??[]) as $field){
   $key=$field['key'];$value=trim((string)($_POST['detail'][$key]??''));
   if(mb_strlen($value)>180)throw new RuntimeException($field['label'].' alanı çok uzun.');
   if($field['required'] && $value==='')throw new RuntimeException($field['label'].' alanını doldur. Seçtiğin ilan türüne ait zorunlu alanları kontrol et.');
   if($field['kind']==='select' && $value!=='' && !in_array($value,$field['options'],true))throw new RuntimeException($field['label'].' seçimi geçersiz.');
   if($field['kind']==='number' && $value!=='' && (!ctype_digit($value) || (int)$value>100000000))throw new RuntimeException($field['label'].' geçerli bir sayı olmalı.');
   if($field['kind']==='date' && $value!=='' && (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$value) || !strtotime($value)))throw new RuntimeException($field['label'].' için geçerli tarih gir.');
   if($field['kind']==='url' && $value!=='' && (!filter_var($value,FILTER_VALIDATE_URL) || !in_array(parse_url($value,PHP_URL_SCHEME),['https'],true)))throw new RuntimeException('Bağlantı https:// ile başlamalı.');
   if($value!=='')$details[$key]=$value;
  }
  $jobSeeker=$type==='jobs' && ($details['job_mode']??'')==='İş arıyorum';
  $cvText=trim((string)($_POST['cv_text']??''));
  if(mb_strlen($cvText)>8000)throw new RuntimeException('CV metni en fazla 8000 karakter olabilir.');
  $pdf=null;$pdfName=null;
  if(isset($_FILES['cv_pdf']) && ($_FILES['cv_pdf']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE){
   $f=$_FILES['cv_pdf'];if($f['error']!==UPLOAD_ERR_OK || $f['size']<1 || $f['size']>3*1024*1024)throw new RuntimeException('CV PDF en fazla 3 MB olabilir.');
   $filename=(string)$f['name'];$fp=(string)$f['tmp_name'];
   if(!is_uploaded_file($fp)||strtolower(pathinfo($filename,PATHINFO_EXTENSION))!=='pdf')throw new RuntimeException('Yalnızca PDF CV yükleyebilirsin.');
   $handle=fopen($fp,'rb');$magic=$handle?fread($handle,5):'';if($handle)fclose($handle);
   if($magic!=='%PDF-')throw new RuntimeException('Geçerli bir PDF dosyası yükle.');
   $pdf=file_get_contents($fp);if($pdf===false)throw new RuntimeException('CV dosyası okunamadı.');
   $pdfName=mb_substr(basename($filename),0,150);
  }
  if($jobSeeker && $cvText==='' && $pdf===null){
   $q=$db->prepare('SELECT 1 FROM body_listing_cvs WHERE listing_id=? AND user_id=? AND (cv_text IS NOT NULL OR cv_pdf IS NOT NULL)');$q->execute([$id,$mid]);
   if(!$id || !$q->fetchColumn())throw new RuntimeException('İş arayanlar CV metni yazmalı veya PDF yüklemelidir.');
  }
  // Eski kurulumda yalnızca bazı kategorilerin ENUM türleri bulunabilir.
  // SQL hatası yerine açıklayıcı bir bakım mesajı göster.
  $schema=$db->query("SHOW COLUMNS FROM body_listings LIKE 'type'")->fetch();
  if($schema && preg_match('/^enum\((.*)\)$/i',(string)$schema['Type'],$enumParts) && !str_contains($enumParts[1],"'".$type."'")){
   throw new RuntimeException('Bu kategori veritabanında henüz tanımlı değil. body/database.sql dosyasını mevcut veritabanına bir kez uygula; mevcut verileri silme.');
  }
  $detailsJson=json_encode($details,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
  if($id){$q=$db->prepare('SELECT image_path,status,type,category_details FROM body_listings WHERE id=? AND user_id=?');$q->execute([$id,$mid]);$old=$q->fetch();if(!$old)throw new RuntimeException('Bu ilan üzerinde düzenleme yetkin yok.');if($old['status']==='completed')throw new RuntimeException('Tamamlanan ilan düzenlenemez.');
    if($old['type']!==$type || ($type==='jobs' && (json_decode((string)$old['category_details'],true)['job_mode']??'')!==($details['job_mode']??''))){
      $m=$db->prepare('SELECT COUNT(*) FROM body_listing_members WHERE listing_id=?');$m->execute([$id]);
      if((int)$m->fetchColumn()>0)throw new RuntimeException('Katılım başvurusu olan ilanın türü veya iş amacı değiştirilemez. Yeni ilan oluştur.');
    }
}
  $image=$old['image_path']??null;
  if(isset($_FILES['image'])&&($_FILES['image']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE)$image=social_upload('image');
  if($id){$q=$db->prepare('UPDATE body_listings SET type=?,title=?,description=?,city=?,extra_info=?,image_path=?,category_details=?,min_age=?,max_age=?,age_band=?,approval_required=?,chat_mode=?,chat_writers=? WHERE id=? AND user_id=?');$q->execute([$type,$title,$description,$city,$extra,$image,$detailsJson,$min,$max,$me['age_band'],$approval,$chatMode,$writers,$id,$mid]);}
  else{$q=$db->prepare('INSERT INTO body_listings(user_id,type,title,description,city,extra_info,image_path,category_details,min_age,max_age,age_band,approval_required,chat_mode,chat_writers) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)');$q->execute([$mid,$type,$title,$description,$city,$extra,$image,$detailsJson,$min,$max,$me['age_band'],$approval,$chatMode,$writers]);}
  $listingId=$id ?: (int)$db->lastInsertId();
  if(!$jobSeeker && $id) $db->prepare('DELETE FROM body_listing_cvs WHERE listing_id=? AND user_id=?')->execute([$id,$mid]);
  if($jobSeeker && ($cvText!==''||$pdf!==null)){
   $q=$db->prepare('INSERT INTO body_listing_cvs(listing_id,user_id,cv_text,cv_pdf,cv_filename) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE cv_text=IF(VALUES(cv_text) IS NOT NULL,VALUES(cv_text),cv_text),cv_pdf=IF(VALUES(cv_pdf) IS NOT NULL,VALUES(cv_pdf),cv_pdf),cv_filename=IF(VALUES(cv_filename) IS NOT NULL,VALUES(cv_filename),cv_filename)');
   $q->execute([$listingId,$mid,$cvText!==''?$cvText:null,$pdf,$pdfName]);
  }
  unset($_SESSION['body_listing_draft']);
  $_SESSION['listing_flash']=$id?'İlan güncellendi.':'İlan başarıyla yayınlandı.';
 }elseif(in_array($action,['close','reopen','delete'],true)&&$id>0){
  if($action==='delete'){$q=$db->prepare("DELETE FROM body_listings WHERE id=? AND user_id=? AND status<>'completed'");$q->execute([$id,$mid]);}
  else{$q=$db->prepare("UPDATE body_listings SET status=? WHERE id=? AND user_id=? AND status<>'completed'");$q->execute([$action==='close'?'closed':'active',$id,$mid]);}
  if(!$q->rowCount())throw new RuntimeException('İlan bulunamadı veya değişiklik yapılamadı.');
  $_SESSION['listing_flash']='İlan durumu güncellendi.';
 }else{throw new RuntimeException('Geçersiz ilan işlemi.');}
}catch(Throwable $e){
 error_log('ALDZ listing action: '.$e->getMessage());
 $isSave=($action==='save');
 if($isSave){
   $draft=$_POST;
   // Never retain a CV, CSRF token or uploaded file in the session draft.
   unset($draft['csrf'],$draft['cv_text']);
   $_SESSION['body_listing_draft']=$draft;
   $typeRaw=(string)($_POST['type']??'freeitems');
   $redirectOnError='listings.php?create=1&type='.urlencode(in_array($typeRaw,$types,true)?$typeRaw:'freeitems').'#create-form';
   if($id>0)$redirectOnError='listings.php?mine=1&edit='.$id.'#create-form';
 }
 $_SESSION['listing_flash']=$e instanceof RuntimeException?$e->getMessage():'İlan kaydedilemedi. Veritabanı yapısını kontrol et ve body/database.sql dosyasının güncel olduğunu doğrula; teknik ayrıntı PHP hata günlüğündedir.';
 body_redirect($isSave?$redirectOnError:'listings.php?mine=1');
}
body_redirect('listings.php?mine=1');
