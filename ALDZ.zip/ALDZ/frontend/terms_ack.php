<?php
declare(strict_types=1);
require_once __DIR__.'/../private/auth.php';
require_once __DIR__.'/../private/body_terms.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !body_valid_csrf() || body_user()) {http_response_code(403);echo json_encode(['ok'=>false]);exit;}
if (($_POST['version']??'')!==ALDZ_TERMS_VERSION || ($_POST['read_confirm']??'')!=='yes') {http_response_code(422);echo json_encode(['ok'=>false]);exit;}
$_SESSION['body_terms_accept']=['version'=>ALDZ_TERMS_VERSION,'at'=>time(),'nonce'=>bin2hex(random_bytes(16))];
echo json_encode(['ok'=>true,'nonce'=>$_SESSION['body_terms_accept']['nonce']],JSON_UNESCAPED_UNICODE);
