(()=>{
 const toggle=document.getElementById('navToggle');
 const sidebar=document.getElementById('bodySidebar');
 if(toggle&&sidebar){
  const mobile=()=>matchMedia('(max-width: 900px)').matches;
  let saved=false;try{saved=localStorage.getItem('body_navigation_collapsed_v8')==='1';}catch(e){}
  document.body.classList.toggle('nav-collapsed',saved&&!mobile());
  const sync=()=>{const open=mobile()?document.body.classList.contains('mobile-nav-open'):!document.body.classList.contains('nav-collapsed');toggle.setAttribute('aria-expanded',String(open));toggle.setAttribute('aria-label',open?'Menüyü kapat':'Menüyü aç');};
  toggle.addEventListener('click',()=>{
   if(mobile())document.body.classList.toggle('mobile-nav-open');
   else {document.body.classList.toggle('nav-collapsed');try{localStorage.setItem('body_navigation_collapsed_v8',document.body.classList.contains('nav-collapsed')?'1':'0');}catch(e){}}
   sync();
  });
  document.getElementById('navBackdrop')?.addEventListener('click',()=>{document.body.classList.remove('mobile-nav-open');sync();});
  window.addEventListener('resize',()=>{document.body.classList.remove('mobile-nav-open');sync();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.body.classList.remove('mobile-nav-open');sync();}});
  sync();
 }

 // ALDZ V16 navigation: in-app history stops at the home screen, never loops.
 const home=new URL('index.php',location.href).pathname;
 const current=location.pathname+location.search;
 const key='body_route_stack_v16';const suppress='body_route_back_v16';
 const isHome=()=>location.pathname===home&&(!location.search||new URLSearchParams(location.search).get('page')==='home');
 let stack=[];
 try{stack=JSON.parse(sessionStorage.getItem(key)||'[]');if(!Array.isArray(stack))stack=[];}catch(_){stack=[];}
 stack=stack.filter(v=>typeof v==='string'&&v.startsWith(home.slice(0,home.lastIndexOf('/')+1))&&v.length<700).slice(-35);
 let goingBack=false;try{goingBack=sessionStorage.getItem(suppress)==='1';sessionStorage.removeItem(suppress);}catch(_){}
 if(isHome()){stack=[current];}else if(goingBack){
   const idx=stack.lastIndexOf(current);if(idx>=0)stack=stack.slice(0,idx+1);else stack=[home,current];
 }else if(stack[stack.length-1]!==current){stack.push(current);}
 try{sessionStorage.setItem(key,JSON.stringify(stack));}catch(_){}
 const backButtons=[...document.querySelectorAll('[data-aldz-back]')];
 if(isHome())backButtons.forEach(btn=>{btn.hidden=true;btn.setAttribute('aria-hidden','true');});
 backButtons.forEach(btn=>btn.addEventListener('click',()=>{
   if(isHome())return;
   let route=home;
   if(stack.length>1){stack.pop();route=stack[stack.length-1]||home;}
   if(route===current)route=home;
   try{sessionStorage.setItem(key,JSON.stringify(stack));sessionStorage.setItem(suppress,'1');}catch(_){}
   location.assign(route);
 }));
})();
