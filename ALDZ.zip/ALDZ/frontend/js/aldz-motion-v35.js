/* ALDZ Motion V35 — minimal, nonblocking progressive enhancement. */
(()=>{
 'use strict';
 const root=document.body;
 if(!root.classList.contains('aldz-app'))return;
 const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');
 const canMove=()=>!reduced.matches;
 const links=document.querySelectorAll('.aldz-shell-sidebar .aldz-shell-link');
 links.forEach((el,i)=>el.style.setProperty('--bm-index',String(i)));
 const candidates=[...document.querySelectorAll('.summary-card,.category-tile,.simple-card,.listing-card,.media-post,.aldz-convo,.panel')]
   .filter(el=>!el.closest('.aldz-shell-sidebar,.aldz-shell-header,[hidden],.aldz-shell-account,.aldz-notification-toast'));
 const viewport=window.innerHeight;
 if(canMove()&&'IntersectionObserver'in window){
  const obs=new IntersectionObserver(entries=>{
   entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('bm-visible');obs.unobserve(entry.target)}});
  },{threshold:0.06,rootMargin:'0px 0px 50px 0px'});
  candidates.forEach((el,i)=>{
   // Do not hide the above-the-fold content or any element inside interactive/hidden panels.
   if(el.getBoundingClientRect().top>viewport*.89 && !el.closest('details:not([open]),dialog,[role="dialog"]')){
    el.classList.add('bm-reveal');obs.observe(el);
   }
   if(el.matches('.summary-card,.category-tile,.simple-card'))el.classList.add('bm-interactive');
  });
  window.setTimeout(()=>{candidates.forEach(el=>el.classList.add('bm-visible'));obs.disconnect();},2800);
 }
 const menu=document.getElementById('bodySidebar');
 const mobile=()=>window.matchMedia('(max-width: 900px)').matches;
 if(menu){
  let start=null;
  // swipe left closes an open mobile drawer; horizontal gestures in posts are untouched.
  menu.addEventListener('touchstart',e=>{if(!mobile()||!root.classList.contains('mobile-nav-open')||e.touches.length!==1)return;start={x:e.touches[0].clientX,y:e.touches[0].clientY};},{passive:true});
  menu.addEventListener('touchend',e=>{if(!start||!mobile())return;let dx=e.changedTouches[0].clientX-start.x,dy=e.changedTouches[0].clientY-start.y;start=null;if(dx< -75&&Math.abs(dx)>Math.abs(dy)*1.35){root.classList.remove('mobile-nav-open');document.getElementById('navToggle')?.setAttribute('aria-expanded','false');}},{passive:true});
  menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{if(mobile())root.classList.remove('mobile-nav-open');}));
 }
 document.addEventListener('pointerdown',e=>{
  if(!canMove())return;
  const el=e.target.closest('button,.aldz-shell-create,.aldz-shell-icon');
  if(!el||el.disabled||el.closest('[hidden]'))return;
  el.classList.remove('bm-press');void el.offsetWidth;el.classList.add('bm-press');
 },{passive:true});
 document.addEventListener('animationend',e=>{if(e.target.classList.contains('bm-press'))e.target.classList.remove('bm-press');});
})();
