(()=>{'use strict';
const form=document.getElementById('bodyListingForm');if(!form)return;
const submit=form.querySelector('button[type="submit"]');
const error=document.getElementById('listingFormError');
const province=document.getElementById('bodyListingProvince');
const kind=document.getElementById('listingTypeSelect');
function issue(message,field){if(error){error.textContent=message;error.hidden=false;error.scrollIntoView({block:'center'});}if(field){field.focus();field.reportValidity();}}
form.addEventListener('submit',event=>{
 if(error){error.hidden=true;error.textContent='';}
 if(!province||!province.value){event.preventDefault();issue('Önce 81 il listesinden şehir seçmelisin.',province);return;}
 const area=form.querySelector('[name="city_area"]');
 if(!area||!area.value){event.preventDefault();issue('Genel bölgeyi seçmelisin.',area);return;}
 const details=document.getElementById('listingDynamicFields');
 if(details&&details.querySelectorAll('[data-field-key]').length===0){event.preventDefault();issue('Kategoriye özel alanlar yüklenemedi. Sayfayı yenileyip tekrar dene.');return;}
 const required=[...form.querySelectorAll('[required]')].filter(el=>!el.disabled&&!el.closest('[hidden]'));
 const first=required.find(el=>!el.checkValidity());
 if(first){event.preventDefault();issue('Lütfen '+(first.closest('label')?.querySelector('span')?.textContent||'zorunlu alan')+' bilgisini doldur.',first);return;}
 if(submit){submit.disabled=true;submit.textContent='İlan kaydediliyor…';}
});
const notice=document.getElementById('listingSaveNotice');if(notice)notice.scrollIntoView({block:'center'});
})();
