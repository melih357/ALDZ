(() => {
 const panel=document.querySelector('.body37-media-toolbar .body24-composer details');
 if(!panel)return;
 const form=panel.querySelector('form');
 if(!form)return;
 const close=document.createElement('button'); close.type='button';close.className='body37-compose-close';close.textContent='✕ Kapat';
 form.prepend(close);
 const backdrop=document.createElement('div');backdrop.className='body37-compose-backdrop';backdrop.hidden=true;
 document.body.append(backdrop);
 const sync=()=>{backdrop.hidden=!panel.open;document.body.classList.toggle('body37-compose-open',panel.open);};
 panel.addEventListener('toggle',sync);
 close.addEventListener('click',()=>{panel.open=false;});
 backdrop.addEventListener('click',()=>{panel.open=false;});
 document.addEventListener('keydown',(e)=>{if(e.key==='Escape'&&panel.open)panel.open=false;});
 sync();
})();
