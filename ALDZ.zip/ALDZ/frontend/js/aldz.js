(() => {
  const toast = document.getElementById('offline-toast');
  const sync = () => { if (toast) toast.hidden = navigator.onLine; };
  window.addEventListener('online', sync); window.addEventListener('offline', sync); sync();
  if ('serviceWorker' in navigator && location.protocol === 'https:' || ('serviceWorker' in navigator && ['localhost','127.0.0.1'].includes(location.hostname))) {
    window.addEventListener('load', () => navigator.serviceWorker.register(new URL((document.querySelector('meta[name=aldz-base]')?.content || '/') + 'sw.js', location.origin).toString()).catch(() => {}));
  }
})();
