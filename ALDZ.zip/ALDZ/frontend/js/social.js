(()=>{
 const modal=document.querySelector('#demoModal'),title=document.querySelector('#modalTitle');
 document.querySelectorAll('[data-modal]').forEach(b=>b.addEventListener('click',()=>{title.textContent=b.dataset.modal;modal.hidden=false}));
 document.querySelectorAll('.modal-close').forEach(b=>b.addEventListener('click',()=>modal.hidden=true));
 modal?.addEventListener('click',e=>{if(e.target===modal)modal.hidden=true});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal)modal.hidden=true});
 const chats={nature:{title:'Doğa Grubu',type:'Topluluk sohbeti',items:[['other','Merhaba! Hafta sonu yürüyüş için kimler geliyor?'],['mine','Ben de geliyorum, harika olacak! 🌿'],['other','Pazar için plan netleşti, herkesi bekliyoruz 😊']]},mert:{title:'Mert Kaya',type:'Bireysel sohbet',items:[['other','Etkinliğe katılıyor musun?'],['mine','Henüz karar vermedim.']]},book:{title:'Kitap Kulübü',type:'Topluluk sohbeti',items:[['other','Yeni kitap önerileri var mı? 📚']]}};
 const chatTitle=document.querySelector('#chatTitle'),chatMessages=document.querySelector('#chatMessages');
 document.querySelectorAll('[data-chat]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-chat]').forEach(x=>x.classList.remove('active'));b.classList.add('active');const c=chats[b.dataset.chat];if(!c)return;chatTitle.textContent=c.title;chatTitle.nextElementSibling.textContent=c.type;chatMessages.innerHTML='';c.items.forEach(([who,text])=>{const n=document.createElement('div');n.className='bubble '+who;n.textContent=text;chatMessages.append(n)})}));
 document.querySelectorAll('[data-chatfilter]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-chatfilter]').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.querySelectorAll('[data-chat]').forEach(x=>x.hidden=b.dataset.chatfilter!=='all'&&x.dataset.type!==b.dataset.chatfilter)}));
 document.querySelector('#chatCompose')?.addEventListener('submit',e=>{e.preventDefault();if(document.querySelector('#chatInput').value.trim()){title.textContent='Mesaj gönderimi';modal.hidden=false}});
 const headers={posts:['Paylaşımlar','Burada kendi paylaşımların listelenecek.'],events:['Etkinlikler','Katıldığın etkinlikler burada görünecek.'],communities:['Topluluklar','Üyesi olduğun topluluklar burada görünecek.'],about:['Hakkında','Biyografi ve ilgi alanları burada gösterilecek.']};
 document.querySelectorAll('[data-profiletab]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-profiletab]').forEach(x=>x.classList.remove('active'));b.classList.add('active');const [h,p]=headers[b.dataset.profiletab];document.querySelector('#profileSection h2').textContent=h;document.querySelector('#profileSection p').textContent=p}));
 
})();

(()=>{
 const slider=document.querySelector('#heroSlider');if(!slider)return;
 const slides=[...slider.querySelectorAll('.hero-slide')];
 const dots=[...slider.querySelectorAll('[data-slide]')];
 if(!slides.length)return;
 let index=0,timer=null;
 const reduceMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
 function show(n){
  index=(n+slides.length)%slides.length;
  slides.forEach((slide,j)=>{
   const selected=j===index;
   slide.classList.toggle('active',selected);
   slide.setAttribute('aria-hidden',String(!selected));
   const link=slide.querySelector('a');if(link)link.tabIndex=selected?0:-1;
  });
  dots.forEach((dot,j)=>{
   dot.classList.toggle('active',j===index);
   dot.setAttribute('aria-pressed',String(j===index));
  });
 }
 function pause(){if(timer!==null){clearInterval(timer);timer=null;}}
 function start(){pause();if(!reduceMotion.matches&&!document.hidden)timer=setInterval(()=>show(index+1),5000);}
 dots.forEach((dot,j)=>dot.addEventListener('click',()=>{show(j);start();}));
 slider.addEventListener('pointerenter',pause);
 slider.addEventListener('pointerleave',start);
 slider.addEventListener('focusin',pause);
 slider.addEventListener('focusout',e=>{if(!slider.contains(e.relatedTarget))start();});
 slider.addEventListener('keydown',e=>{
  if(e.key==='ArrowRight'||e.key==='ArrowLeft'){
   e.preventDefault();show(index+(e.key==='ArrowRight'?1:-1));start();
  }
 });
 document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();else start();});
 if(reduceMotion.addEventListener)reduceMotion.addEventListener('change',start);
 show(0);start();
})();
