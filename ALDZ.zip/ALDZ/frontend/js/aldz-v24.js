document.addEventListener('DOMContentLoaded',()=>{const type=document.getElementById('body24-type');const files=document.getElementById('body24-files');if(type&&files){type.addEventListener('change',()=>{files.value='';files.multiple=type.value==='photo'||type.value==='outfit';files.accept=type.value==='video_short'||type.value==='video_long'?'video/mp4,video/webm':'image/jpeg,image/png,image/webp';const outfit=type.closest('form')?.querySelector('#body36-outfit-fields');if(outfit)outfit.hidden=type.value!=='outfit';});}document.querySelectorAll('.body24-media').forEach(el=>{el.addEventListener('wheel',e=>{if(Math.abs(e.deltaX)>Math.abs(e.deltaY))return;}, {passive:true});});});
// Filter the existing accepted-follow contact list locally without exposing private accounts.
document.querySelectorAll('.aldz-friend-share').forEach(panel=>{
  const search=panel.querySelector('.aldz-friend-search');const empty=panel.querySelector('.aldz-share-empty');
  search?.addEventListener('input',()=>{const term=search.value.trim().toLocaleLowerCase('tr');let shown=0;
    panel.querySelectorAll('.aldz-friend-option').forEach(item=>{item.hidden=!(item.dataset.search||'').includes(term);if(!item.hidden)shown++;});
    if(empty){empty.hidden=shown>0;}
  });
});

// ALDZ V44 — stream videos in bounded 1 MiB chunks; regular photos keep multipart upload.
document.addEventListener('DOMContentLoaded',()=>{
 const form=document.getElementById('body42-upload-form');if(!form)return;
 const type=form.querySelector('#body24-type'),input=form.querySelector('#body24-files');
 const hint=form.querySelector('#body42-upload-feedback'),progress=form.querySelector('#body44-upload-progress');
 const staged=form.querySelector('#body44-staged-video'),button=form.querySelector('button[type="submit"]');
 const csrf=form.querySelector('input[name="csrf"]')?.value||'';
 const MB=1048576,MAX_VIDEO=1024*MB;
 let uploading=false;
 function notice(message){if(hint)hint.textContent=message;}
 function video(){return !!type?.value?.startsWith('video_');}
 function reset(){staged.value='';if(progress){progress.hidden=true;progress.value=0;}notice('');}
 input?.addEventListener('change',reset);type?.addEventListener('change',reset);
 async function api(op,id='',offset=0,body=null){
   const qs=new URLSearchParams({op});if(id)qs.set('id',id);if(op==='chunk')qs.set('offset',String(offset));
   const headers={'X-ALDZ-CSRF':csrf};
   const options={method:'POST',headers,body,credentials:'same-origin',cache:'no-store'};
   if(op==='chunk')headers['Content-Type']='application/octet-stream';
   const response=await fetch('video_chunk.php?'+qs.toString(),options);
   let data;try{data=await response.json();}catch{throw new Error('Sunucudan geçerli yanıt gelmedi. Bağlantıyı kontrol et.');}
   if(!response.ok||data.error){const error=new Error(data.error||'Yükleme başarısız.');error.code=data.code||'';throw error;}
   return data;
 }
 form.addEventListener('submit',async event=>{
   if(uploading){event.preventDefault();return;}
   if(staged.value){ // Completed upload: send only metadata, not the giant file.
     input.required=false;input.removeAttribute('name');
     button.disabled=true;button.textContent='Paylaşım kaydediliyor…';
     return;
   }
   const selected=Array.from(input?.files||[]);
   if(!selected.length)return;
   const total=selected.reduce((sum,f)=>sum+f.size,0);
   if(video()){
     event.preventDefault();event.stopImmediatePropagation();
     if(selected.length!==1){notice('Bir seferde bir video seç.');return;}
     const file=selected[0];
     if(file.size>MAX_VIDEO){notice('Video en fazla 1 GB olabilir.');return;}
     if(!/\.(mp4|webm)$/i.test(file.name)){notice('MP4 veya WEBM video seç.');return;}
     uploading=true;button.disabled=true;button.textContent='Video yükleniyor…';
     if(progress){progress.hidden=false;progress.value=0;}
     try{
       const init=new FormData();init.set('size',String(file.size));init.set('kind',type.value);
       let {id}=await api('init','',0,init);
       let offset=0,restarted=false;
       while(offset<file.size){
         const next=Math.min(offset+MB,file.size);
         let result;
         for(let attempt=0;attempt<3;attempt++){
           try{result=await api('chunk',id,offset,file.slice(offset,next));break;}
           catch(error){
             // Missing metadata on the very first chunk is recoverable by reinitialising once.
             // Later chunks must never silently restart the entire upload.
             if(offset===0&&!restarted&&error.code==='SESSION_MISSING'){
               restarted=true;
               notice('Yükleme bağlantısı yenileniyor…');
               ({id}=await api('init','',0,init));
               attempt=-1;continue;
             }
             if(attempt===2 || error.code==='SESSION_OWNER'||error.code==='SESSION_UNREADABLE'||error.code==='SESSION_MISSING')throw error;
             await new Promise(resolve=>setTimeout(resolve,500*(attempt+1)));
           }
         }
         if(!result||!Number.isInteger(result.received)||result.received!==next)throw new Error('Sunucu video parçasını eksik doğruladı.');
         offset=result.received;
         const pct=Math.round(offset/file.size*100);
         if(progress)progress.value=pct;
         notice('Video yükleniyor: %'+pct+' ('+(offset/MB).toFixed(1)+' / '+(file.size/MB).toFixed(1)+' MB)');
       }
       notice('Video kontrol ediliyor…');await api('finish',id);
       staged.value=id;uploading=false;
       notice('Video tamamlandı; gönderi oluşturuluyor…');
       form.requestSubmit(button);
     }catch(error){uploading=false;button.disabled=false;button.textContent='Paylaş';notice('Yükleme başarısız: '+error.message);}
   }else{
     const valid=selected.length<=8 && selected.every(f=>f.size<=8*MB);
     if(!valid){event.preventDefault();notice('En fazla 8 fotoğraf seçilebilir; her biri en fazla 8 MB olmalı.');return;}
     const postLimit=Number(form.dataset.phpPostMax)||0;
     const fileLimit=Number(form.dataset.phpUploadMax)||0;
     if((postLimit&&total+MB>postLimit)||(fileLimit&&selected.some(f=>f.size>fileLimit))){
       event.preventDefault();notice('Fotoğrafların toplam boyutu sunucunun PHP sınırını aşıyor. Daha az fotoğraf seç.');return;
     }
     button.disabled=true;button.textContent='Paylaşılıyor…';
   }
 },true);
});
