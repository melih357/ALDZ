/* ALDZ V15: Keep the listing type, page category and form hints in sync. */
(()=>{
  'use strict';
  const select=document.getElementById('listingTypeSelect');
  const source=document.getElementById('listingTypesMeta');
  if(!select||!source)return;
  let types={};
  try{types=JSON.parse(source.textContent||'{}');}catch(_){return;}
  const formTitle=document.getElementById('listingFormHeading');
  const description=document.getElementById('listingCategoryDescription');
  const pageTitle=document.getElementById('listingPageHeading');
  const pageDescription=document.getElementById('listingPageDescription');
  const extra=document.getElementById('listingExtraInfo');
  const mine=new URLSearchParams(window.location.search).get('mine')==='1';
  const editing=new URLSearchParams(window.location.search).has('edit');
  const apply=()=>{
    const value=select.value;
    const meta=types[value];
    if(!meta)return;
    if(formTitle)formTitle.textContent=meta.label+' · '+(editing?'İlanı düzenle':'Yeni ilan oluştur');
    if(description)description.textContent=meta.description;
    if(extra)extra.placeholder=meta.placeholder;
    if(pageTitle)pageTitle.textContent=mine?'İlanlarım · '+meta.label:meta.label;
    if(pageDescription)pageDescription.textContent=mine?'İlanlarını yönetiyorsun. Seçilen yeni ilan türü: '+meta.label+'.':meta.description;
    document.querySelectorAll('[data-listing-category]').forEach(link=>{
      const active=link.dataset.listingCategory===value;
      link.classList.toggle('active',active);
      if(active)link.setAttribute('aria-current','true');else link.removeAttribute('aria-current');
    });
  };
  select.addEventListener('change',apply);
  select.addEventListener('input',apply);
  apply();
})();

/* ALDZ V16: Kategoriye özgü alanları güvenli DOM API ile oluşturur. */
(()=>{
'use strict';
const select=document.getElementById('listingTypeSelect');
const src=document.getElementById('listingFieldDefinitions');
const target=document.getElementById('listingDynamicFields');
if(!select||!src||!target)return;
let defs={}, old={};
try{defs=JSON.parse(src.textContent||'{}');old=JSON.parse(document.getElementById('listingExistingDetails')?.textContent||'{}');}catch(_){return;}
let last=select.value,valuesByType={};valuesByType[last]={...old};
const read=()=>{const v={};target.querySelectorAll('[data-field-key]').forEach(el=>v[el.dataset.fieldKey]=el.value);valuesByType[last]=v;};
function draw(){
 const type=select.value;const values=valuesByType[type]||{};last=type;target.replaceChildren();
 (defs[type]||[]).forEach(field=>{
   const label=document.createElement('label');label.className='listing-special-field';
   const title=document.createElement('span');title.textContent=field.label+(field.required?' *':'');label.append(title);
   const el=field.kind==='select'?document.createElement('select'):document.createElement('input');
   if(field.kind==='select'){
     const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent='Seçiniz';el.append(placeholder);
     (field.options||[]).forEach(choice=>{const opt=document.createElement('option');opt.value=choice;opt.textContent=choice;el.append(opt);});
   }else{
     el.type=field.kind==='date'?'date':field.kind==='number'?'number':field.kind==='url'?'url':'text';
     if(el.type==='number'){el.min='0';el.max='100000000';el.step='1';}
     if(el.type==='url')el.placeholder='https://...';
     if(el.type==='text')el.maxLength=180;
   }
   el.name='detail['+field.key+']';el.dataset.fieldKey=field.key;el.value=values[field.key]||'';el.required=Boolean(field.required);
   label.append(el);target.append(label);
 });
}
select.addEventListener('change',()=>{read();draw();});
draw();
})();
