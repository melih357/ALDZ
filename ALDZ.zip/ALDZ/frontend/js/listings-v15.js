/* ALDZ V15: Keep the listing type, page category and form hints in sync. */
(()=>{
  'use strict';
  const select=document.getElementById('listingTypeSelect');
  const source=document.getElementById('listingTypesMeta');
  if(!select||!source)return;
  let types={};
  try{types=JSON.parse(source.textContent||'{}');}catch(_){return;}
  const formTitle=document.getElementById('listingFormHeading');
  const description=document.getElementById('listingCategoryDescription');
  const pageTitle=document.getElementById('listingPageHeading');
  const pageDescription=document.getElementById('listingPageDescription');
  const extra=document.getElementById('listingExtraInfo');
  const mine=new URLSearchParams(window.location.search).get('mine')==='1';
  const editing=new URLSearchParams(window.location.search).has('edit');
  const apply=()=>{
    const value=select.value;
    const meta=types[value];
    if(!meta)return;
    if(formTitle)formTitle.textContent=meta.label+' · '+(editing?'İlanı düzenle':'Yeni ilan oluştur');
    if(description)description.textContent=meta.description;
    if(extra)extra.placeholder=meta.placeholder;
    if(pageTitle)pageTitle.textContent=mine?'İlanlarım · '+meta.label:meta.label;
    if(pageDescription)pageDescription.textContent=mine?'İlanlarını yönetiyorsun. Seçilen yeni ilan türü: '+meta.label+'.':meta.description;
    document.querySelectorAll('[data-listing-category]').forEach(link=>{
      const active=link.dataset.listingCategory===value;
      link.classList.toggle('active',active);
      if(active)link.setAttribute('aria-current','true');else link.removeAttribute('aria-current');
    });
  };
  select.addEventListener('change',apply);
  select.addEventListener('input',apply);
  apply();
})();
