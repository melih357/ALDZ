/* ALDZ V21 message experience. No client trust for permissions; server validates each operation. */
(() => {
  'use strict';
  const search = document.querySelector('#chatSearch');
  if (search) search.addEventListener('input', () => {
    const term = search.value.trim().toLocaleLowerCase('tr');
    document.querySelectorAll('#conversationList .aldz-convo').forEach(link => {
      link.hidden = !(link.dataset.search || '').includes(term);
    });
  });

  const directForm = document.querySelector('#directChatForm');
  const directInput = document.querySelector('#messageAldz');
  if (directForm && directInput) {
    directInput.addEventListener('keydown', event => {
      if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
        event.preventDefault();
        if (directForm.reportValidity()) directForm.requestSubmit();
      }
    });
  }

  function bubbleNode(item, self, group) {
    const node = document.createElement('div');
    node.className = group ? 'listing-chat-bubble' : 'aldz-bubble';
    if (Number(item.sender_id) === Number(self)) node.classList.add(group ? 'own' : 'mine');
    node.dataset.id = String(item.id);if(!group)node.dataset.reactions=item.reactions||'';
    if (group) {
      const sender = document.createElement('b'); sender.textContent = '@' + item.username;
      node.append(sender);
    }
    const content = document.createElement('p');
    content.textContent = item.body;
    content.style.whiteSpace = 'pre-wrap';
    node.append(content);
    if (!group && item.attachment_id) {
      const url = 'message_file_v25.php?id=' + encodeURIComponent(item.attachment_id);
      if (item.attachment_kind === 'image' && item.view_once) {
        const note=document.createElement('span');note.className='view-once-expired';
        if(item.viewed_at)note.textContent='Tek görüntülemelik fotoğraf açıldı';
        else if(Number(item.sender_id)===Number(self))note.textContent='Tek görüntülemelik fotoğraf gönderildi';
        else {const link=document.createElement('a');link.href=url;link.className='view-once-link';link.textContent='🔒 Fotoğrafı bir kez görüntüle';note.append(link);}
        node.append(note);
      } else if (item.attachment_kind === 'image' || item.attachment_kind === 'sticker') {
        const link = document.createElement('a'); link.href = url;link.target='_blank';link.rel='noopener';
        const photo = document.createElement('img');photo.src=url;photo.loading='lazy';photo.alt='Gönderilen görsel';photo.className='chat-media-img';link.append(photo);node.append(link);
      } else if (item.attachment_kind === 'video') {
        const video=document.createElement('video');video.controls=true;video.playsInline=true;video.preload='metadata';video.src=url;video.className='chat-media-video';node.append(video);
      } else if (item.attachment_kind === 'voice') {
        const audio = document.createElement('audio');audio.controls=true;audio.preload='none';audio.src=url;node.append(audio);
      } else {
        const link = document.createElement('a');link.href=url;link.className='chat-file-link';link.textContent='📎 ' + (item.attachment_name||'Dosya');node.append(link);
      }
    }
    if (!group && item.reactions) {
      const reactions=document.createElement('div');reactions.className='chat-reaction-line';
      item.reactions.split('|').forEach(x=>{const label=document.createElement('span');label.textContent=x.split(':')[0];reactions.append(label);});node.append(reactions);
    }
    const stamp = document.createElement('small'); stamp.textContent = item.created_at;
    node.append(stamp);
    if (!group) {const react=document.createElement('button');react.type='button';react.className='chat-react';react.dataset.react=item.id;react.setAttribute('aria-label','Mesaja ifade bırak');react.textContent='☺';node.append(react);}
    return node;
  }

  // Incremental refresh of current chat. Poll only while tab is visible.
  async function setupUpdates(element, endpoint, group) {
    let running = false;
    const refresh = async () => {
      if (running || document.hidden) return;
      running = true;
      try {
        const response = await fetch(endpoint, {credentials: 'same-origin', headers: {'Accept':'application/json'}, cache:'no-store'});
        if (!response.ok) return;
        const data = await response.json();
        if (!Array.isArray(data.messages)) return;
        if (group && (!data.canRead || !data.chatAvailable)) {
          window.location.reload(); return;
        }
        const existing = new Map([...element.querySelectorAll('[data-id]')].map(n => [n.dataset.id, n]));
        const nearBottom = element.scrollHeight - element.scrollTop - element.clientHeight < 110;
        const ids = new Set();
        for (const item of data.messages) {
          const id = String(item.id);
          ids.add(id);
          if (!existing.has(id)) element.appendChild(bubbleNode(item, data.mine, group));
          else if(!group && existing.get(id).dataset.reactions !== (item.reactions||'')) existing.get(id).replaceWith(bubbleNode(item,data.mine,group));
        }
        existing.forEach((node, id) => { if (!ids.has(id)) node.remove(); });
        const empty = element.querySelector('[data-empty]');
        if (empty && data.messages.length) empty.remove();
        if (nearBottom) element.scrollTop = element.scrollHeight;
        if (group) {
          const composer = document.querySelector('#listingMessageAldz');
          if (composer && !data.canWrite) window.location.reload();
        }
      } catch (_) {
        // Network errors are temporary; keep current conversation visible.
      } finally { running = false; }
    };
    element.scrollTop = element.scrollHeight;
    const timer = window.setInterval(refresh, 8000);
    window.addEventListener('pagehide', () => clearInterval(timer), {once:true});
  }
  const direct = document.querySelector('#directChatMessages');
  if (direct) setupUpdates(direct, 'messages.php?chat=' + encodeURIComponent(direct.dataset.chat) + '&format=json', false);
  const listing = document.querySelector('#listingChatMessages');
  if (listing) setupUpdates(listing, 'listing_room.php?id=' + encodeURIComponent(listing.dataset.listing) + '&format=json', true);
})();
