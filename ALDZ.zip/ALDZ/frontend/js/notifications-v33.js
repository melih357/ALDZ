(()=>{
 'use strict';
 const badge=document.getElementById('bodyUnreadBadge');
 const toast=document.getElementById('bodyNotificationToast');
 const toggle=document.getElementById('bodySoundToggle');
 if(!badge||!toast||!toggle)return;
 const title=document.getElementById('bodyToastTitle'),message=document.getElementById('bodyToastText');
 let latest=null,busy=false,audio=null;
 let soundOn=false;
 try{soundOn=localStorage.getItem('aldz-notification-sound')==='on';}catch(_){}
 const updateToggle=()=>{toggle.setAttribute('aria-pressed',String(soundOn));toggle.firstChild.textContent=soundOn?'🔔 ':'🔕 ';toggle.title=soundOn?'Bildirim sesini kapat':'Bildirim sesini aç';};
 const sound=()=>{if(!soundOn)return;try{if(!audio)audio=new Audio('assets/aldz-notification-v33.wav');audio.currentTime=0;audio.play().catch(()=>{});}catch(_){}};
 toggle.addEventListener('click',()=>{soundOn=!soundOn;try{localStorage.setItem('aldz-notification-sound',soundOn?'on':'off');}catch(_){}updateToggle();if(soundOn)sound();});updateToggle();
 document.getElementById('bodyToastClose')?.addEventListener('click',()=>{toast.hidden=true;});
 async function poll(){if(busy)return;busy=true;try{
  const url='notification_poll.php?after='+encodeURIComponent(latest===null?0:latest);
  const r=await fetch(url,{credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'}});
  if(!r.ok)return;const d=await r.json();if(!d.ok)return;
  const number=Math.max(0,Number(d.unread)||0);badge.hidden=number===0;badge.textContent=number>99?'99+':String(number);
  if(latest!==null&&Array.isArray(d.items)&&d.items.length){
   const last=d.items[d.items.length-1];title.textContent=String(last.title||'ALDZ bildirimi');message.textContent=String(last.body||'Yeni bildirimin var.');toast.hidden=false;sound();
  }
  latest=Math.max(latest||0,Number(d.latest)||0);
 }catch(_){}finally{busy=false;}}
 poll();setInterval(poll,4500);document.addEventListener('visibilitychange',()=>{if(!document.hidden)poll();});
})();
