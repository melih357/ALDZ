(()=>{
'use strict';
const type=document.getElementById('listingTypeSelect');const fields=document.getElementById('listingDynamicFields');const section=document.getElementById('listingCvSection');if(!type||!fields||!section)return;
const refresh=()=>{
 const mode=fields.querySelector('[data-field-key="job_mode"]');
 const required=type.value==='jobs'&&mode?.value==='İş arıyorum';
 section.hidden=!required;
 section.querySelectorAll('textarea,input[type=file]').forEach(el=>{el.disabled=!required;});
};
fields.addEventListener('change',refresh);type.addEventListener('change',refresh);
refresh();
})();
