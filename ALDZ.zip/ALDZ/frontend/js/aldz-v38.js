(() => {
  const panel = document.querySelector('.body37-media-toolbar .body24-composer details');
  if (!panel) return;
  const form = panel.querySelector('form');
  if (!form) return;
  const root = document.createElement('div');
  root.className = 'body38-dialog-root';
  root.hidden = true;
  root.innerHTML = '<div class="body38-dialog-backdrop"></div><section class="body38-dialog" role="dialog" aria-modal="true" aria-label="Yeni paylaşım"><div class="body38-dialog-head"><strong>Yeni paylaşım</strong><button type="button" class="body38-dialog-close" aria-label="Paylaşımı kapat">✕</button></div></section>';
  document.body.appendChild(root);
  const dialog = root.querySelector('.body38-dialog');
  const close = root.querySelector('.body38-dialog-close');
  const backdrop = root.querySelector('.body38-dialog-backdrop');
  const anchor = document.createComment('ALDZ sharing form original position');
  form.before(anchor);
  let previousFocus = null;
  function sync() {
    const isOpen = panel.open;
    root.hidden = !isOpen;
    document.body.classList.toggle('body38-dialog-open', isOpen);
    if (isOpen) {
      previousFocus = document.activeElement;
      dialog.appendChild(form);
      close.focus();
    } else {
      anchor.after(form);
      if (previousFocus && previousFocus.isConnected) previousFocus.focus();
    }
  }
  panel.addEventListener('toggle', sync);
  close.addEventListener('click', () => {panel.open = false;});
  backdrop.addEventListener('click', () => {panel.open = false;});
  document.addEventListener('keydown', e => {
    if (!panel.open) return;
    if (e.key === 'Escape') {e.preventDefault(); panel.open = false;}
    if (e.key === 'Tab') {
      const focusable = [...dialog.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),a[href]')].filter(el => el.getClientRects().length);
      if (!focusable.length) return;
      const first=focusable[0], last=focusable[focusable.length-1];
      if (e.shiftKey && document.activeElement === first) {e.preventDefault();last.focus();}
      else if (!e.shiftKey && document.activeElement === last) {e.preventDefault();first.focus();}
    }
  });
  sync();
})();
