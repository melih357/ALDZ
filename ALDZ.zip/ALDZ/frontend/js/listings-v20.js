/* ALDZ V20 partnership transparency and form guidance. */
(()=>{'use strict';
const kind=document.getElementById('listingTypeSelect');
const privacy=document.getElementById('partnerPrivacyNotice');
const approval=document.getElementById('listingApprovalSelect');
const submit=document.getElementById('listingSubmitButton');
const desc=document.querySelector('textarea[name="description"]');
if(!kind)return;
const minor=Number(document.getElementById('listingAgeMin')?.min||18)<18;
function update(){
 const enabled=kind.value==='partners';
 if(privacy)privacy.hidden=!enabled;
 if(approval){
   const free=approval.querySelector('option[value="0"]');
   if(free)free.disabled=enabled;
   if(enabled)approval.value='1';
 }
 if(desc)desc.placeholder=enabled?'Örn. Mobil uygulama geliştiriyorum. Fikir ve maddi katkı sunabilecek 2 ortak arıyorum. Ayrıntılar karşılıklı görüşme sonrası paylaşılacak. Gizli konsepti burada açıklama.':'Detayları ve beklentilerini yaz';
 if(submit){submit.disabled=enabled&&minor;submit.title=enabled&&minor?'Bu ilan türü yalnızca 18+ içindir':'';}
}
kind.addEventListener('change',update);update();
})();
