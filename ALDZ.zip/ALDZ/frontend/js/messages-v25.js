/* ALDZ V25 -- native messaging enhancements, no third-party scripts. */
(() => {
  'use strict';
  const convo = document.querySelector('#directChatMessages');
  if (!convo) return;
  const chat = convo.dataset.chat;
  const csrf = document.querySelector('#directChatForm input[name=csrf]')?.value;
  const status = document.querySelector('#chatFeatureStatus');
  const picker = document.querySelector('#bodyMessageMedia');
  const camera = document.querySelector('#bodyCameraMedia');
  const notices = (message) => { if (status) status.textContent = message; };
  const send = async (endpoint, data) => {
    const body = new FormData();body.append('csrf',csrf);body.append('chat',chat);
    for (const [k,v] of Object.entries(data)) body.append(k,v);
    const response = await fetch(endpoint,{method:'POST',body,credentials:'same-origin',cache:'no-store'});
    const json = await response.json();if(!response.ok || json.error)throw new Error(json.error || 'İşlem yapılamadı.');
    return json;
  };
  const attachMenu=document.querySelector('#bodyAttachmentMenu');
  const plusToggle=document.querySelector('#bodyPlusToggle');
  const previewPanel=document.querySelector('#bodySendPreview');
  const pendingVisual=document.querySelector('#bodyPendingVisual');
  const pendingInfo=document.querySelector('#bodyPendingInfo');
  const privacyField=document.querySelector('#bodyImagePrivacy');
  const videoInfo=document.querySelector('#bodyVideoInfo');
  const confirmSend=document.querySelector('#bodyConfirmSend');
  let uploadKind='image',pendingFile=null,pendingKind=null,pendingURL='';
  const setMenu=(open)=>{if(!attachMenu)return;attachMenu.hidden=!open;plusToggle?.setAttribute('aria-expanded',String(open));};
  plusToggle?.addEventListener('click',()=>setMenu(attachMenu.hidden));
  document.addEventListener('click',e=>{if(attachMenu&&!attachMenu.hidden&&!e.target.closest('#bodyAttachmentMenu,#bodyPlusToggle'))setMenu(false);});
  const clearPending=()=>{if(pendingURL)URL.revokeObjectURL(pendingURL);pendingURL='';pendingFile=null;pendingKind=null;
    if(pendingVisual)pendingVisual.replaceChildren();if(previewPanel)previewPanel.hidden=true;
    if(picker)picker.value='';if(camera)camera.value='';if(confirmSend){confirmSend.disabled=true;confirmSend.textContent='Gönder';}
    document.querySelectorAll('input[name=bodySendMode]').forEach(el=>el.checked=false);
  };
  const showPending=(file,kind)=>{
    if(!file)return;clearPending();setMenu(false);
    pendingFile=file;pendingKind=kind;pendingURL=URL.createObjectURL(file);
    const isImage=kind==='image';
    privacyField.hidden=!isImage;videoInfo.hidden=kind!=='video';
    let media;
    if(isImage){media=document.createElement('img');media.alt='Seçilen fotoğrafın önizlemesi';media.src=pendingURL;}
    else if(kind==='video'){media=document.createElement('video');media.src=pendingURL;media.controls=true;media.preload='metadata';media.playsInline=true;}
    else{media=document.createElement('div');media.textContent='📎 '+file.name;media.className='aldz-file-preview';}
    pendingVisual.replaceChildren(media);
    pendingInfo.textContent=file.name+' · '+(file.size/1024/1024).toFixed(2)+' MB';
    confirmSend.disabled=isImage;previewPanel.hidden=false;
  };
  document.querySelectorAll('input[name=bodySendMode]').forEach(el=>el.addEventListener('change',()=>{if(pendingKind==='image')confirmSend.disabled=false;}));
  document.querySelector('#bodyCancelSend')?.addEventListener('click',clearPending);
  previewPanel?.addEventListener('click',e=>{if(e.target===previewPanel)clearPending();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!previewPanel?.hidden)clearPending();});
  document.querySelector('#attachImage')?.addEventListener('click',()=>{uploadKind='media';picker.accept='image/jpeg,image/png,image/webp,video/mp4,video/webm';picker.click();});
  document.querySelector('#attachFile')?.addEventListener('click',()=>{uploadKind='file';picker.accept='.pdf,.txt,.jpg,.jpeg,.png,.webp';picker.click();});
  picker?.addEventListener('change',()=>{const file=picker.files?.[0];if(!file)return;
    const kind=uploadKind==='file'?'file':file.type.startsWith('video/')?'video':'image';
    if(uploadKind==='media'&&!['image','video'].includes(kind)){notices('Yalnızca fotoğraf veya video seç.');picker.value='';return;}
    showPending(file,kind);
  });
  confirmSend?.addEventListener('click',async()=>{
    if(!pendingFile||!pendingKind)return;
    const selected=document.querySelector('input[name=bodySendMode]:checked');
    if(pendingKind==='image'&&!selected){notices('Normal veya tek görüntülemelik seçeneğini belirt.');return;}
    const file=pendingFile,kind=pendingKind,once=kind==='image'&&selected?.value==='once'?'1':'0';
    confirmSend.disabled=true;confirmSend.textContent='Gönderiliyor…';
    try{await send('message_action_v25.php',{action:'upload',kind,media:file,view_once:once});clearPending();notices('Medya gönderildi.');location.reload();}
    catch(e){notices(e.message);confirmSend.disabled=false;confirmSend.textContent='Gönder';}
  });
  // Use the actual live camera, not just a file picker. A picker remains the fallback.
  const cameraPanel=document.querySelector('#bodyCameraPanel');
  const cameraVideo=document.querySelector('#bodyLiveCamera');
  let cameraStream=null;
  const closeCamera=()=>{cameraStream?.getTracks().forEach(t=>t.stop());cameraStream=null;if(cameraVideo)cameraVideo.srcObject=null;if(cameraPanel)cameraPanel.hidden=true;};
  document.querySelector('#openCamera')?.addEventListener('click',async()=>{
    if(!navigator.mediaDevices?.getUserMedia){notices('Kamera için HTTPS veya localhost gerekir. Cihazının fotoğraf seçicisi açılıyor.');camera?.click();return;}
    try{cameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});cameraVideo.srcObject=cameraStream;cameraPanel.hidden=false;await cameraVideo.play();notices('Kamera hazır. Fotoğraf çekebilirsin.');}
    catch(e){closeCamera();notices('Kamera açılamadı: tarayıcı iznini kontrol et veya galeriyi kullan.');camera?.click();}
  });
  document.querySelector('#bodyCameraClose')?.addEventListener('click',closeCamera);
  document.querySelector('#bodyCameraCapture')?.addEventListener('click',async()=>{
    if(!cameraStream||!cameraVideo?.videoWidth)return notices('Kamera henüz hazır değil.');
    const canvas=document.createElement('canvas');const max=1600;const factor=Math.min(1,max/cameraVideo.videoWidth);canvas.width=Math.round(cameraVideo.videoWidth*factor);canvas.height=Math.round(cameraVideo.videoHeight*factor);
    canvas.getContext('2d').drawImage(cameraVideo,0,0,canvas.width,canvas.height);
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.9));
    closeCamera();if(!blob||blob.size<100)return notices('Fotoğraf kaydedilemedi.');
    showPending(new File([blob],'kamera.jpg',{type:'image/jpeg'}),'image');notices('Fotoğraf çekildi. Göndermeden önce görüntüleme türünü seç.');
  });
  const viewOncePanel=document.querySelector('#bodyOncePanel');const onceImg=document.querySelector('#bodyOnceImg');let onceURL='';
  const closeOnce=()=>{if(onceImg){onceImg.removeAttribute('src');}if(onceURL)URL.revokeObjectURL(onceURL);onceURL='';if(viewOncePanel)viewOncePanel.hidden=true;};
  document.querySelector('#bodyOnceClose')?.addEventListener('click',closeOnce);
  convo.addEventListener('click',async(e)=>{
    const link=e.target.closest('.view-once-link');if(!link)return;
    e.preventDefault();link.style.pointerEvents='none';
    try{const res=await fetch(link.href,{credentials:'same-origin',cache:'no-store'});if(!res.ok)throw new Error('Bu medya daha önce açılmış veya erişilemiyor.');const blob=await res.blob();if(!blob.type.startsWith('image/'))throw new Error('Geçersiz fotoğraf.');onceURL=URL.createObjectURL(blob);onceImg.src=onceURL;viewOncePanel.hidden=false;link.replaceWith(Object.assign(document.createElement('span'),{className:'view-once-expired',textContent:'Fotoğraf görüntülendi'}));}
    catch(err){notices(err.message);link.style.pointerEvents='';}
  });

  camera?.addEventListener('change',()=>{const file=camera.files?.[0];if(file)showPending(file,'image');});
  const stickerDrawer=document.querySelector('#stickerDrawer');
  document.querySelector('#showStickers')?.addEventListener('click',()=>{stickerDrawer.hidden=!stickerDrawer.hidden;});
  stickerDrawer?.addEventListener('click',async(e)=>{
    const button=e.target.closest('[data-sticker]');if(!button)return;
    try{await send('message_action_v25.php',{action:'sticker_send',sticker_id:button.dataset.sticker});location.reload();}
    catch(error){notices(error.message);}
  });
  document.querySelector('#newSticker')?.addEventListener('change',async(e)=>{
    const file=e.target.files?.[0];if(!file)return;
    try{await send('message_action_v25.php',{action:'sticker_create',name:file.name.replace(/\.[^.]+$/,''),media:file});location.reload();}
    catch(error){notices(error.message);}
  });
  // Record PCM audio directly to WAV. Unlike WebM chunks, WAV has an explicit sample count and duration.
  let audioStream=null,audioBlob=null,audioURL='',recordStarted=0,recordMs=0,recordingBusy=false;
  let audioContext=null,sourceNode=null,processorNode=null,silentNode=null,pcmParts=[],sampleCount=0,recActive=false,tick=null;
  const preview=document.querySelector('#voicePreview');const playback=document.querySelector('#voicePlayback');
  const recordButton=document.querySelector('#recordVoice');const sendVoiceButton=document.querySelector('#sendVoice');
  const elapsedDisplay=document.querySelector('#bodyVoiceDuration');
  const displayMs=(ms)=>{const secs=Math.max(0,Math.round(ms/1000));return `${Math.floor(secs/60)}:${String(secs%60).padStart(2,'0')}`;};
  const cleanupAudio=()=>{
    recActive=false;
    try{processorNode?.disconnect();sourceNode?.disconnect();silentNode?.disconnect();}catch(_){}
    processorNode=null;sourceNode=null;silentNode=null;
    audioStream?.getTracks().forEach(t=>t.stop());audioStream=null;
    if(audioContext){audioContext.close().catch(()=>{});audioContext=null;}
    if(tick){clearInterval(tick);tick=null;}
  };
  const resetOldAudio=()=>{if(audioURL)URL.revokeObjectURL(audioURL);audioURL='';audioBlob=null;recordMs=0;playback.pause();playback.removeAttribute('src');playback.load();preview.hidden=true;};
  const buildWav=(samples,srcRate,targetRate=16000)=>{
    const outputLength=Math.floor(samples.length*targetRate/srcRate);
    const buffer=new ArrayBuffer(44+outputLength*2),view=new DataView(buffer);
    const str=(p,s)=>{for(let i=0;i<s.length;i++)view.setUint8(p+i,s.charCodeAt(i));};
    str(0,'RIFF');view.setUint32(4,36+outputLength*2,true);str(8,'WAVE');str(12,'fmt ');
    view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);
    view.setUint32(24,targetRate,true);view.setUint32(28,targetRate*2,true);view.setUint16(32,2,true);view.setUint16(34,16,true);
    str(36,'data');view.setUint32(40,outputLength*2,true);
    for(let i=0;i<outputLength;i++){
      const pos=i*srcRate/targetRate,ix=Math.floor(pos),fraction=pos-ix;
      const one=samples[Math.min(ix,samples.length-1)]||0,two=samples[Math.min(ix+1,samples.length-1)]||0;
      const v=Math.max(-1,Math.min(1,one+(two-one)*fraction));
      view.setInt16(44+i*2,v<0?v*32768:v*32767,true);
    }
    return new Blob([buffer],{type:'audio/wav'});
  };
  const stopRecording=async()=>{
    if(!recActive||recordingBusy)return;
    recordingBusy=true;recordButton.disabled=true;recordButton.textContent='Kayıt hazırlanıyor…';
    const rate=audioContext?.sampleRate||48000;cleanupAudio();
    const all=new Float32Array(sampleCount);let offset=0;
    for(const part of pcmParts){all.set(part,offset);offset+=part.length;}
    pcmParts=[];sampleCount=0;
    audioBlob=buildWav(all,rate);
    recordMs=(all.length/rate)*1000;
    recordButton.disabled=false;recordButton.textContent='🎙 Ses kaydet';recordingBusy=false;
    if(audioBlob.size<5000||recordMs<500){audioBlob=null;notices('Ses kaydedilemedi. Mikrofon aygıtını kontrol et.');return;}
    if(audioBlob.size>4*1024*1024){audioBlob=null;notices('Ses kaydı 4 MB sınırını aşıyor. Daha kısa kayıt yap.');return;}
    audioURL=URL.createObjectURL(audioBlob);playback.src=audioURL;playback.load();preview.hidden=false;
    if(elapsedDisplay)elapsedDisplay.textContent='Kaydedilen süre: '+displayMs(recordMs);
    notices('Ses kaydı hazır. Önce dinleyip sonra gönderebilirsin.');
  };
  recordButton?.addEventListener('click',async()=>{
    if(recActive){await stopRecording();return;}
    if(recordingBusy)return;
    if(!navigator.mediaDevices?.getUserMedia || !(window.AudioContext||window.webkitAudioContext)){
      notices('Kayıt için Chrome/Edge/Firefox ve HTTPS veya localhost gereklidir.');return;
    }
    resetOldAudio();
    try{
      audioStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false});
      const Context=window.AudioContext||window.webkitAudioContext;
      audioContext=new Context();await audioContext.resume();
      sourceNode=audioContext.createMediaStreamSource(audioStream);
      processorNode=audioContext.createScriptProcessor(4096,1,1);
      silentNode=audioContext.createGain();silentNode.gain.value=0;
      pcmParts=[];sampleCount=0;recActive=true;
      processorNode.onaudioprocess=e=>{
        if(!recActive)return;
        const input=e.inputBuffer.getChannelData(0),copy=new Float32Array(input);
        pcmParts.push(copy);sampleCount+=copy.length;
        if(sampleCount/audioContext.sampleRate>=119)stopRecording();
      };
      sourceNode.connect(processorNode);processorNode.connect(silentNode);silentNode.connect(audioContext.destination);
      recordStarted=performance.now();recordButton.textContent='■ Kaydı durdur';notices('Ses kaydı sürüyor…');
      tick=setInterval(()=>{if(elapsedDisplay)elapsedDisplay.textContent='Kayıt: '+displayMs(performance.now()-recordStarted);},500);
    }catch(e){cleanupAudio();recordButton.disabled=false;notices('Mikrofon açılamadı. Mikrofon iznini ve ses girişini kontrol et.');}
  });
  sendVoiceButton?.addEventListener('click',async()=>{
    if(recActive||recordingBusy||!audioBlob||audioBlob.size<5000)return notices('Gönderilebilecek ses kaydı bulunamadı.');
    sendVoiceButton.disabled=true;notices('Ses gönderiliyor…');
    try{await send('message_action_v25.php',{action:'voice',media:new File([audioBlob],'sesli-mesaj.wav',{type:'audio/wav'}),duration_ms:String(Math.round(recordMs))});location.reload();}
    catch(e){notices(e.message);sendVoiceButton.disabled=false;}
  });
  document.querySelector('#cancelVoice')?.addEventListener('click',resetOldAudio);
  const tray=document.querySelector('#reactionTray');let reactionMessage=0;
  convo.addEventListener('click',(e)=>{
    const button=e.target.closest('.chat-react');if(!button)return;
    reactionMessage=Number(button.dataset.react);tray.hidden=false;
    const pos=button.getBoundingClientRect();tray.style.position='fixed';tray.style.top=Math.min(innerHeight-80,pos.bottom+5)+'px';tray.style.left=Math.max(5,Math.min(innerWidth-260,pos.left-150))+'px';
  });
  tray?.addEventListener('click',async(e)=>{
    const button=e.target.closest('[data-emoji]');if(!button||!reactionMessage)return;
    tray.hidden=true;
    try{await send('message_action_v25.php',{action:'react',message_id:reactionMessage,emoji:button.dataset.emoji});location.reload();}catch(error){notices(error.message);}
  });
  // Calls: WebRTC peer connection with DB-based polling signaling (works on HTTPS/localhost).
  const callPanel=document.querySelector('#callPanel');const callState=document.querySelector('#callState');
  const localVideo=document.querySelector('#localCallVideo');const remoteVideo=document.querySelector('#remoteCallVideo');const remoteAudio=document.querySelector('#remoteCallAudio');
  let callId=0,callKind='audio',pc=null,localStream=null,lastSignal=0,activeCall=false,remoteCandidates=[],savedOffer=null;
  const callInfo=(t)=>{if(callState)callState.textContent=t;};
  const callSend=async (data)=>send('message_call_v25.php',data);
  const setPanel=(visible)=>{callPanel.hidden=!visible;};
  const closeStreams=()=>{
    if(pc){pc.onicecandidate=null;pc.close();pc=null;}
    if(localStream)localStream.getTracks().forEach(t=>t.stop());localStream=null;
    localVideo.srcObject=null;remoteVideo.srcObject=null;remoteAudio.srcObject=null;
    activeCall=false;callId=0;lastSignal=0;remoteCandidates=[];savedOffer=null;
    setPanel(false);
  };
  const createPeer=async()=>{
    if(pc)return;
    // STUN enables some peer-to-peer networks; production use requires an authenticated TURN server.
    pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
    pc.onicecandidate=(e)=>{if(e.candidate&&callId)callSend({action:'signal',call_id:callId,signal_type:'ice',payload:JSON.stringify(e.candidate)}).catch(()=>{});};
    pc.ontrack=(e)=>{remoteVideo.srcObject=e.streams[0];remoteAudio.srcObject=e.streams[0];};
    pc.onconnectionstatechange=()=>{if(pc&&['failed','disconnected'].includes(pc.connectionState))callInfo('Bağlantı kesildi. Aramayı yeniden deneyebilirsin.');};
    localStream=await navigator.mediaDevices.getUserMedia({audio:true,video:callKind==='video'});
    localStream.getTracks().forEach(track=>pc.addTrack(track,localStream));
    localVideo.srcObject=callKind==='video'?localStream:null;
    localVideo.hidden=callKind!=='video';remoteVideo.hidden=callKind!=='video';remoteAudio.hidden=callKind==='video';
  };
  const flushIce=async()=>{if(!pc?.remoteDescription)return;for(const c of remoteCandidates.splice(0)){try{await pc.addIceCandidate(c);}catch(_){}}};
  const handleSignal=async(sig)=>{
    if(!pc && (sig.signal_type==='ice'||sig.signal_type==='answer'))return;
    const value=JSON.parse(sig.payload);
    if(sig.signal_type==='offer'){
      if(!pc){savedOffer=value;return;}
      if(!pc.remoteDescription){await pc.setRemoteDescription(value);await flushIce();const answer=await pc.createAnswer();await pc.setLocalDescription(answer);await callSend({action:'signal',call_id:callId,signal_type:'answer',payload:JSON.stringify(answer)});callInfo('Bağlanıyor…');}
    }else if(sig.signal_type==='answer'){
      if(pc && !pc.remoteDescription){await pc.setRemoteDescription(value);await flushIce();callInfo('Arama bağlantısı kuruluyor…');}
    }else if(sig.signal_type==='ice'){
      if(pc?.remoteDescription){try{await pc.addIceCandidate(value);}catch(_){}}else remoteCandidates.push(value);
    }
  };
  const accept=document.querySelector('#acceptCall');const decline=document.querySelector('#declineCall');
  document.querySelectorAll('[data-call]').forEach(button=>button.addEventListener('click',async()=>{
    if(callId)return;
    if(!navigator.mediaDevices?.getUserMedia||typeof RTCPeerConnection==='undefined'){notices('Arama için HTTPS/localhost ve WebRTC destekleyen bir tarayıcı gerekli.');return;}
    callKind=button.dataset.call;setPanel(true);callInfo('Mikrofon/kamera izni isteniyor…');
    try{
      // Obtain permissions BEFORE initiating an actual ring.
      await createPeer();const result=await callSend({action:'start',kind:callKind});callId=Number(result.call_id);activeCall=true;
      const offer=await pc.createOffer();await pc.setLocalDescription(offer);await callSend({action:'signal',call_id:callId,signal_type:'offer',payload:JSON.stringify(offer)});
      callInfo('Karşı taraf aranıyor…');
    }catch(e){callInfo(e.message);closeStreams();notices(e.message);}
  }));
  accept?.addEventListener('click',async()=>{
    try{await createPeer();await callSend({action:'accept',call_id:callId});accept.hidden=true;decline.hidden=true;callInfo('Arama bağlanıyor…');if(savedOffer){const offer=savedOffer;savedOffer=null;await pc.setRemoteDescription(offer);await flushIce();const answer=await pc.createAnswer();await pc.setLocalDescription(answer);await callSend({action:'signal',call_id:callId,signal_type:'answer',payload:JSON.stringify(answer)});}}
    catch(e){notices(e.message);callInfo(e.message);}
  });
  decline?.addEventListener('click',async()=>{if(callId)await callSend({action:'decline',call_id:callId}).catch(()=>{});closeStreams();});
  document.querySelector('#hangupCall')?.addEventListener('click',async()=>{if(callId)await callSend({action:'end',call_id:callId}).catch(()=>{});closeStreams();});
  const poll=async()=>{
    if(document.hidden||!navigator.onLine)return;
    try{
      const res=await fetch('message_call_v25.php?chat='+encodeURIComponent(chat)+'&since='+encodeURIComponent(lastSignal),{credentials:'same-origin',cache:'no-store'});
      if(!res.ok)return;const data=await res.json();const call=data.call;
      if(!call){if(callId)closeStreams();return;}
      if(callId && Number(call.id)!==callId)return;
      if(!callId){
        if(Number(call.callee_id)!==Number(data.mine))return;
        callId=Number(call.id);callKind=call.kind;lastSignal=0;setPanel(true);callInfo('Gelen '+(callKind==='video'?'görüntülü':'sesli')+' arama');accept.hidden=false;decline.hidden=false;
      }
      if(call.status==='accepted' && Number(call.caller_id)===Number(data.mine))callInfo('Görüşme başlıyor…');
      if(Array.isArray(data.signals))for(const sig of data.signals){lastSignal=Math.max(lastSignal,Number(sig.id));if(Number(sig.sender_id)!==Number(data.mine))await handleSignal(sig);}
    }catch(e){if(callId)callInfo('Bağlantı kontrol ediliyor…');}
  };
  setInterval(poll,2500);poll();
  window.addEventListener('pagehide',()=>{closeStreams();cleanupAudio();closeCamera();closeOnce();});
})();
