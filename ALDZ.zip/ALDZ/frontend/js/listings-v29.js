(()=>{'use strict';
const form=document.getElementById('bodyListingForm');if(!form)return;
const province=document.getElementById('bodyListingProvince');
const submit=form.querySelector('button[type="submit"]');
const kind=form.querySelector('[name="type"]');
// Formun kategoriye göre farklı zorunlu alanları her gönderimde doğrulanır.
form.addEventListener('submit',event=>{
  if(!province?.value){event.preventDefault();province?.focus();province?.reportValidity();return;}
  const required=[...form.querySelectorAll('[required]')].filter(el=>!el.disabled && !el.closest('[hidden]'));
  const first=required.find(el=>!el.checkValidity());
  if(first){event.preventDefault();first.scrollIntoView({behavior:'smooth',block:'center'});first.focus();first.reportValidity();return;}
  if(submit){submit.disabled=true;submit.textContent='İlan kaydediliyor…';}
});
const notice=document.getElementById('listingSaveNotice');
if(notice){notice.scrollIntoView({block:'center'});}
})();
