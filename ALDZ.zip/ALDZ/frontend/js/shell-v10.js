(()=>{
 const menu=document.getElementById('accountMenu'),trigger=document.getElementById('userToggle');
 const close=()=>{if(menu){menu.hidden=true;trigger?.setAttribute('aria-expanded','false');}};
 trigger?.addEventListener('click',(e)=>{e.stopPropagation();const open=menu.hidden;menu.hidden=!open;trigger.setAttribute('aria-expanded',String(open));});
 document.addEventListener('click',e=>{if(menu&&!menu.hidden&&!menu.contains(e.target)&&!trigger?.contains(e.target))close();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
 const panel=document.getElementById('createEvent');
 const reveal=()=>{if(!panel)return;panel.open=true;panel.scrollIntoView({behavior:'smooth',block:'start'});};
 if(location.hash==='#createEvent')requestAnimationFrame(reveal);
 document.querySelectorAll('[data-create-event]').forEach(a=>a.addEventListener('click',e=>{
   if(panel){e.preventDefault();history.replaceState(null,'','#createEvent');reveal();}
 }));
})();
