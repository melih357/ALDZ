<?php
declare(strict_types=1);
require_once __DIR__.'/../private/social_helpers.php';
$me=body_require_login();$mid=(int)$me['id'];$db=body_db();
if($_SERVER['REQUEST_METHOD']!=='POST'||!body_valid_csrf()){http_response_code(403);exit('Geçersiz istek.');}
$action=(string)($_POST['action']??'');$id=(int)($_POST['room_id']??0);$dest='communities.php'.($id?'?room='.$id:'');
try{
 if($action==='create'){
  $name=trim((string)($_POST['name']??''));$description=trim((string)($_POST['description']??''));$mode=(string)($_POST['mode']??'all');
  if(mb_strlen($name)<4||mb_strlen($name)>100||mb_strlen($description)<10||mb_strlen($description)>1000||!in_array($mode,['all','admins'],true))throw new RuntimeException('Topluluk bilgilerini kontrol et.');
  $db->beginTransaction();$q=$db->prepare('INSERT INTO body_communities(owner_id,name,description,age_band,mode) VALUES(?,?,?,?,?)');$q->execute([$mid,$name,$description,$me['age_band'],$mode]);$id=(int)$db->lastInsertId();
  $db->prepare("INSERT INTO body_community_members(community_id,user_id,role) VALUES(?,?,'owner')")->execute([$id,$mid]);$db->commit();$dest='communities.php?room='.$id;
 }else{
  $q=$db->prepare("SELECT c.*,u.status AS owner_status FROM body_communities c JOIN users u ON u.id=c.owner_id WHERE c.id=?");$q->execute([$id]);$room=$q->fetch();
  if(!$room||$room['owner_status']!=='active'||$room['age_band']!==$me['age_band']||!social_can_view((int)$room['owner_id'],$mid))throw new RuntimeException('Topluluk erişimine izin verilmiyor.');
  $q=$db->prepare('SELECT role FROM body_community_members WHERE community_id=? AND user_id=?');$q->execute([$id,$mid]);$role=$q->fetchColumn()?:null;
  if($action==='join'){
   if($role)throw new RuntimeException('Zaten üyesin.');
   $db->prepare("INSERT INTO body_community_members(community_id,user_id,role) VALUES(?,?,'member')")->execute([$id,$mid]);
  }elseif($action==='leave'){
   if(!$role||$role==='owner')throw new RuntimeException('Topluluk kurucusu ayrılamaz.');
   $db->prepare('DELETE FROM body_community_members WHERE community_id=? AND user_id=?')->execute([$id,$mid]);
  }elseif($action==='message'){
   if(!$role||($room['mode']==='admins'&&!in_array($role,['owner','admin'],true)))throw new RuntimeException('Bu odada mesaj gönderme iznin yok.');
   $message=trim((string)($_POST['body']??''));if(!$message||mb_strlen($message)>2000)throw new RuntimeException('Mesaj en fazla 2000 karakter olmalı.');
   $db->prepare('INSERT INTO body_community_messages(community_id,sender_id,body) VALUES(?,?,?)')->execute([$id,$mid,$message]);
  }elseif($action==='mode'){
   if($role!=='owner')throw new RuntimeException('Sadece kurucu sohbet modunu değiştirebilir.');
   $mode=(string)($_POST['mode']??'');if(!in_array($mode,['all','admins'],true))throw new RuntimeException('Geçersiz sohbet modu.');
   $db->prepare('UPDATE body_communities SET mode=? WHERE id=? AND owner_id=?')->execute([$mode,$id,$mid]);
  }elseif($action==='role'){
   if($role!=='owner')throw new RuntimeException('Sadece kurucu yönetici atayabilir.');
   $target=(int)($_POST['user_id']??0);$newRole=(string)($_POST['role']??'');if($target===$mid||!in_array($newRole,['admin','member'],true))throw new RuntimeException('Geçersiz üye.');
   $q=$db->prepare("UPDATE body_community_members SET role=? WHERE community_id=? AND user_id=? AND role IN ('admin','member')");$q->execute([$newRole,$id,$target]);if(!$q->rowCount())throw new RuntimeException('Üye bulunamadı.');
  }else throw new RuntimeException('Bilinmeyen işlem.');
 }
 $_SESSION['body_community_flash']='İşlem tamamlandı.';
}catch(Throwable $e){if($db->inTransaction())$db->rollBack();error_log('ALDZ community: '.$e->getMessage());$_SESSION['body_community_flash']='İşlem yapılamadı: '.($e instanceof PDOException?'Veritabanı güncellemesini kontrol et.':$e->getMessage());}
body_redirect($dest);
