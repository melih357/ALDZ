<?php
declare(strict_types=1);
require_once __DIR__.'/../private/auth.php';
$me=body_require_login();$db=body_db();$mid=(int)$me['id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!body_valid_csrf()){http_response_code(403);exit('İstek doğrulanamadı.');}
 if(($_POST['action']??'')==='all_read')$db->prepare('UPDATE notifications SET read_at=NOW() WHERE user_id=? AND read_at IS NULL')->execute([$mid]);
 body_redirect('notifications.php');
}
$q=$db->prepare('SELECT id,type,title,body,created_at,read_at FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100');$q->execute([$mid]);$notes=$q->fetchAll();
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Bildirimler — ALDZ</title><link rel="stylesheet" href="css/social-v2.css"><link rel="stylesheet" href="css/aldz-v7.css"><link rel="stylesheet" href="css/shell-v13.css?v=23"><link rel="stylesheet" href="css/aldz-v23.css?v=23"><link rel="stylesheet" href="css/aldz-v27.css?v=27"><link rel="stylesheet" href="css/aldz-i18n-v39.css?v=39"></head><body class="aldz-app social-page"><?php require __DIR__.'/shell.php'; ?>
<main class="container"><section class="panel"><div class="aldz-heading"><h1>Bildirimler</h1><form method="post"><input type="hidden" name="csrf" value="<?=body_e(body_csrf())?>"><input type="hidden" name="action" value="all_read"><button type="submit">Tümünü Okundu İşaretle</button></form></div><?php if(!$notes):?><p>Henüz bildirimin yok.</p><?php endif;?><?php foreach($notes as $n):?><article class="aldz-notification <?=empty($n['read_at'])?'unread':''?>"><b><?=body_e($n['title'])?></b><p><?=body_e((string)$n['body'])?></p><small><?=body_e((string)$n['created_at'])?></small></article><?php endforeach;?></section></main><script src="js/shared-nav.js?v=16" defer></script><script src="js/shell-v10.js?v=13" defer></script><script src="js/aldz-i18n-v39.js?v=39" defer></script></body></html>
