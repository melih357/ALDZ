# ALDZ V12 Değişiklikleri

- `frontend/shell.php`: Keşfet, Profil, Ayarlar, Mesajlar, Bildirimler, kullanıcı arama ve ana sayfada aynı üst çubuk ve sol menü kullanılıyor.
- `frontend/css/shell-v10.css`: sabit modern üst çubuk, masaüstü kompakt menü, mobil drawer, tutarlı butonlar ve profil menüsü.
- `frontend/js/shell-v10.js`: kullanıcı menüsünü yönetir, etkinlik oluşturma bağlantıları formu açar, `#createEvent` adresini destekler.
- `frontend/event_action.php`: Etkinlik tarihi İstanbul saat diliminde yorumlanır, geçersiz tarih kontrolü, anlaşılan hata bildirimi ve başarısız kayıtta formu yeniden açma eklendi.
- `frontend/index.php`: eski üst çubuk/menü yinelenmeleri çıkarıldı; etkinlik formu bağlantısı iyileştirildi; 3. ve 4. kampanya görselleri değiştirildi.
- `frontend/sw.js`: önbellek sürümü yenilendi.

## Doğrulama
PHP syntax, JS syntax, arşiv bütünlüğü ve ana sayfa HTTP 200 kontrolü yapıldı. Yerel MySQL bulunmadığından gerçek veritabanına INSERT testi ve oturum açmış tarayıcı testleri yapılmadı. Tam çalışan üretim sürümü değildir.


V12 ek düzeltme: Ana sayfa slider görselleri tamamen yenilendi. Düşük çözünürlüklü iki görsel kaldırıldı ve son iki slaytta tekrar eden benzer görseller yerine dört ayrı yüksek çözünürlüklü görsel kullanıldı.


V12 ek güncelleme: Menü, üst çubuk ve hesap açılır menüsündeki karakter tabanlı simgeler kaldırıldı; yerlerine modern SVG ikon seti uygulandı. Mesajlar, Bildirimler, Profilim ve Ayarlar simgeleri yenilendi.
