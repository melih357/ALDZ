# Güvenlik kontrol listesi (kapalı test)

- [ ] `APP_DEBUG=false` ile staging testi
- [ ] HTTPS ve Secure/HttpOnly/SameSite cookie ayarları
- [ ] Yaşın doğum tarihinden sunucuda hesaplanması ve 13 yaş altının reddi
- [ ] Her sorguda yaş bandı izolasyonu
- [ ] Cinsiyet tercihi için hem keşif hem başvuru sunucu kontrolü
- [ ] CSRF, rate limiting, XSS çıktı kaçışlama ve SQL injection testleri
- [ ] Parola sıfırlama token süresi ve tek kullanımlılık
- [ ] Personel 2FA ve yedek kodların güvenli saklanması
- [ ] Yüklenen görseller için MIME, boyut, içerik ve dosya adı kontrolü
- [ ] Mesaj ve bildirimlerde yetkilendirme; hassas içerik loglamama
- [ ] Moderasyon kararları ve itiraz yetki matrisi
- [ ] Yedekleme/geri yükleme provası
- [ ] KVKK ve çocuk güvenliği bakımından uzman incelemesi

Bu kontrol listesi hukuki görüş veya güvenlik sertifikası değildir.
